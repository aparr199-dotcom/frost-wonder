import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  AlertTriangle,
  Archive,
  Bell,
  Calendar,
  Check,
  CheckCircle2,
  Clock,
  Copy,
  Download,
  Edit3,
  ExternalLink,
  Maximize2,
  Monitor,
  Plus,
  RefreshCw,
  Sparkles,
  Volume2,
  VolumeX,
} from 'lucide-react';
import {
  CountdownState,
  HolidayMilestone,
  MilestoneReminderRecord,
  WallpaperResolutionId,
} from './types/holiday';
import {
  calculateChristmasCountdown,
  calculateMilestoneTimeRemaining,
  FESTIVE_MESSAGES,
  generateMilestoneIcsContent,
  getChronologicalLockScreenMilestones,
  WALLPAPER_RESOLUTIONS,
} from './utils/holidayLogic';
import { GENERATED_ASSETS, getInitialMilestones } from './data/seedData';
import { soundEngine } from './utils/soundEngine';
import { SnowfallCanvas } from './components/SnowfallCanvas';
import { EnchantedSnowGlobe } from './components/EnchantedSnowGlobe';
import { ScreenSaverModal } from './components/ScreenSaverModal';
import { OfflineIndicator } from './components/PWAInstallButton';
import { renderLockScreenToCanvas } from './utils/lockScreenWallpaperRenderer';

const STORAGE_KEYS = {
  milestones: 'frost_wonder_lockscreen_v2_milestones',
  targetYearOverride: 'frost_wonder_lockscreen_v2_target_year',
  milestoneCount: 'frost_wonder_lockscreen_v2_milestone_count',
};

const PUBLIC_SHARE_URL =
  'https://ais-pre-if5nuq52nlb7vahb7q7v2v-458633164632.us-east5.run.app';

const HANDSHAKE_PROJECT_TITLE =
  'Frost & Wonder: An Enchanted Christmas Countdown Lock Screen for macOS';

const HANDSHAKE_FIRST_PERSON_DESCRIPTION = `For the Handshake "Your Deadline, Your Design: Create a Countdown Lock Screen" challenge, I designed and engineered Frost & Wonder—a minimalist, cinematic macOS Christmas countdown lock-screen experience built around a December 25, 2026 deadline.

• Visual Centerpiece & Mac Clock Safe-Zone Engineering: The design centers on an original interactive 3D-style snow globe housing an illuminated winter Ferris wheel, warm-lit alpine castle towers, snow-laden evergreens, and a midnight-blue porcelain pedestal with champagne-gold botanical filigree, set against a glowing ice palace and drifting snowfall. The top third of the composition is deliberately reserved for the macOS Sonoma/Sequoia system clock so the time and date remain effortless to read at a glance.
• High-Contrast Christmas & Milestone Countdowns: Below the snow globe sit a large, tabular-numeral countdown to December 25, 2026 and four concise, chronological preparation milestone countdowns (Tree & Winter Lights on Nov 29, Holiday Shipping Cutoff on Dec 14, Wrapping & Ribbon Night on Dec 21, and Christmas Eve Final Staging on Dec 24).
• High-Resolution Static Wallpaper Export + Live Countdown Experience: Users can export a real high-resolution Mac lock-screen wallpaper PNG in accurately labeled 2560 × 1440 (QHD / 1440p) or 3840 × 2160 (True 4K UHD). Because a static PNG wallpaper captures a countdown snapshot at export time and cannot update automatically, Frost & Wonder pairs the static wallpaper exporter with a separate Full-Screen Live Countdown mode and a native Swift/WidgetKit macOS project.
• AI-Assisted Backward Planning & Optional Verified Reminders: Using Gemini backward planning from December 25, 2026, the app explains how one major holiday deadline was broken into four calm, achievable checkpoints (including an 11-day ground-shipping buffer), and offers optional verified .ICS Apple Calendar reminder exports with embedded VALARM triggers.`;

interface AiRationaleStep {
  stepNumber: number;
  title: string;
  targetDate: string;
  daysBeforeChristmas: number;
  whyChosen: string;
}

const DEFAULT_AI_RATIONALE_STEPS: AiRationaleStep[] = [
  {
    stepNumber: 1,
    title: 'Tree & Winter Lights Evening',
    targetDate: '2026-11-29T17:00',
    daysBeforeChristmas: 26,
    whyChosen:
      'Placed on the final Sunday of November (26 days before Christmas) to set the holiday atmosphere and finalize gift plans before December shipping traffic peaks.',
  },
  {
    stepNumber: 2,
    title: 'Holiday Shipping Cutoff',
    targetDate: '2026-12-14T20:00',
    daysBeforeChristmas: 11,
    whyChosen:
      'Chosen by working 11 days backward from December 25 to build a safe ground-shipping buffer and eliminate last-minute delivery stress.',
  },
  {
    stepNumber: 3,
    title: 'Wrapping & Ribbon Night',
    targetDate: '2026-12-21T20:00',
    daysBeforeChristmas: 4,
    whyChosen:
      'Scheduled 4 days before Christmas—after parcels have arrived—so wrapping, ribbons, and cards become an unhurried winter evening ritual.',
  },
  {
    stepNumber: 4,
    title: 'Christmas Eve Hearth & Magic',
    targetDate: '2026-12-24T21:00',
    daysBeforeChristmas: 1,
    whyChosen:
      'Leaves Christmas Eve completely free of errands so the final evening is dedicated strictly to family traditions and staging under the tree.',
  },
];

function loadFromStorage<T>(key: string, fallback: T): T {
  if (typeof window === 'undefined') return fallback;
  try {
    const raw = window.localStorage.getItem(key);
    if (!raw) return fallback;
    return JSON.parse(raw) as T;
  } catch {
    return fallback;
  }
}

export default function App() {
  const [now, setNow] = useState<Date>(() => new Date());
  const [snowEnabled, setSnowEnabled] = useState<boolean>(true);
  const [isMusicPlaying, setIsMusicPlaying] = useState<boolean>(false);
  const [simulateChristmasMorning, setSimulateChristmasMorning] =
    useState<boolean>(false);
  const [showMacClockPreviewOnStage, setShowMacClockPreviewOnStage] =
    useState<boolean>(true);
  const [globeSwirlTrigger, setGlobeSwirlTrigger] = useState<number>(0);

  const [targetYearOverride, setTargetYearOverride] = useState<number | null>(
    () => loadFromStorage<number | null>(STORAGE_KEYS.targetYearOverride, null)
  );
  const [milestoneDisplayCount, setMilestoneDisplayCount] = useState<3 | 4>(
    () => loadFromStorage<3 | 4>(STORAGE_KEYS.milestoneCount, 4)
  );
  const [milestones, setMilestones] = useState<HolidayMilestone[]>(() =>
    loadFromStorage<HolidayMilestone[]>(
      STORAGE_KEYS.milestones,
      getInitialMilestones(new Date().getFullYear())
    )
  );

  // Full-Screen Separate Live Countdown Experience
  const [liveDisplayOpen, setLiveDisplayOpen] = useState<boolean>(() => {
    if (typeof window === 'undefined') return false;
    const params = new URLSearchParams(window.location.search);
    return params.get('screensaver') === '1' || params.get('live') === '1';
  });

  // Inline milestone editing modal state
  const [editingMilestone, setEditingMilestone] =
    useState<HolidayMilestone | null>(null);
  const [isAddingMilestone, setIsAddingMilestone] = useState<boolean>(false);
  const [draftTitle, setDraftTitle] = useState<string>('');
  const [draftDate, setDraftDate] = useState<string>('2026-12-14T20:00');
  const [draftCategory, setDraftCategory] = useState<string>('Key Checkpoint');
  const [draftNotes, setDraftNotes] = useState<string>('');

  // High-Resolution Lock-Screen Wallpaper Studio state
  const [selectedResolution, setSelectedResolution] =
    useState<WallpaperResolutionId>('qhd_2560x1440');
  const [previewWithMacClock, setPreviewWithMacClock] =
    useState<boolean>(true);
  const [wallpaperDownloadMsg, setWallpaperDownloadMsg] = useState<
    string | null
  >(null);
  const [coverDownloadMsg, setCoverDownloadMsg] = useState<string | null>(null);
  const [copiedField, setCopiedField] = useState<string | null>(null);

  const wallpaperPreviewCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const coverPreviewCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const heroImageRef = useRef<HTMLImageElement | null>(null);
  const [heroImageReady, setHeroImageReady] = useState<boolean>(false);

  // AI-Assisted Deadline Plan state
  const [aiSummary, setAiSummary] = useState<string>(
    'By working backward from December 25, 2026, the countdown lock screen turns a single high-pressure holiday date into four calm, chronological milestones—anchoring an 11-day ground-shipping buffer on December 14 so wrapping night (Dec 21) and Christmas Eve (Dec 24) stay completely unhurried.'
  );
  const [aiSteps, setAiSteps] = useState<AiRationaleStep[]>(
    DEFAULT_AI_RATIONALE_STEPS
  );
  const [customFocus, setCustomFocus] = useState<string>(
    'Calm, minimalist Christmas with early shipping cutoff'
  );
  const [isGeneratingAi, setIsGeneratingAi] = useState<boolean>(false);
  const [aiStatusBanner, setAiStatusBanner] = useState<{
    type: 'success' | 'info';
    text: string;
  } | null>(null);

  // Optional Milestone Reminders state (never claims scheduled unless verified)
  const [leadTimeHours, setLeadTimeHours] = useState<number>(24);
  const [verifiedReminders, setVerifiedReminders] = useState<
    MilestoneReminderRecord[]
  >([]);
  const [reminderStatus, setReminderStatus] = useState<{
    type: 'verified' | 'unverified';
    text: string;
  }>({
    type: 'unverified',
    text: 'No reminders scheduled yet. Export a verified .ICS calendar alert for macOS Calendar/Reminders or verify Browser Notification permission below.',
  });

  // Live 1-second clock tick
  useEffect(() => {
    const timer = window.setInterval(() => {
      setNow(new Date());
    }, 1000);
    return () => window.clearInterval(timer);
  }, []);

  // Preload Ice Palace background artwork for crisp canvas wallpaper export
  useEffect(() => {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => {
      heroImageRef.current = img;
      setHeroImageReady(true);
    };
    img.src = GENERATED_ASSETS.heroIcePalace;
  }, []);

  // Persist milestones & preferences
  useEffect(() => {
    try {
      window.localStorage.setItem(
        STORAGE_KEYS.milestones,
        JSON.stringify(milestones)
      );
    } catch {}
  }, [milestones]);

  useEffect(() => {
    try {
      window.localStorage.setItem(
        STORAGE_KEYS.targetYearOverride,
        JSON.stringify(targetYearOverride)
      );
    } catch {}
  }, [targetYearOverride]);

  useEffect(() => {
    try {
      window.localStorage.setItem(
        STORAGE_KEYS.milestoneCount,
        JSON.stringify(milestoneDisplayCount)
      );
    } catch {}
  }, [milestoneDisplayCount]);

  const countdown: CountdownState = useMemo(
    () =>
      calculateChristmasCountdown(now, {
        targetYearOverride,
        simulateChristmasMorning,
      }),
    [now, targetYearOverride, simulateChristmasMorning]
  );

  // Strictly chronological 3 or 4 milestones for the Lock Screen
  const visibleMilestones = useMemo(
    () =>
      getChronologicalLockScreenMilestones(
        milestones,
        countdown.targetYear,
        milestoneDisplayCount
      ),
    [milestones, countdown.targetYear, milestoneDisplayCount]
  );

  // Sync browser title with live countdown
  useEffect(() => {
    if (countdown.isChristmasMorning) {
      document.title = '🎄 Merry Christmas! — Frost & Wonder Lock Screen';
    } else {
      document.title = `🎄 ${countdown.days}d ${countdown.hours}h to Christmas — Frost & Wonder`;
    }
  }, [countdown.days, countdown.hours, countdown.isChristmasMorning]);

  // Render live previews of the Mac Lock-Screen Wallpaper & Handshake Cover Image
  useEffect(() => {
    if (wallpaperPreviewCanvasRef.current) {
      renderLockScreenToCanvas({
        canvas: wallpaperPreviewCanvasRef.current,
        width: 1280,
        height: 720,
        countdown,
        milestones,
        now,
        heroImage: heroImageRef.current,
        includeSimulatedMacClockOverlay: previewWithMacClock,
        isHandshakeCoverImage: false,
        milestoneCount: milestoneDisplayCount,
      });
    }
    if (coverPreviewCanvasRef.current) {
      renderLockScreenToCanvas({
        canvas: coverPreviewCanvasRef.current,
        width: 1280,
        height: 720,
        countdown,
        milestones,
        now,
        heroImage: heroImageRef.current,
        includeSimulatedMacClockOverlay: true,
        isHandshakeCoverImage: true,
        milestoneCount: milestoneDisplayCount,
      });
    }
  }, [
    countdown,
    milestones,
    now,
    previewWithMacClock,
    heroImageReady,
    milestoneDisplayCount,
  ]);

  const handleToggleMusic = () => {
    const playing = soundEngine.toggleSoundtrack();
    setIsMusicPlaying(playing);
  };

  const handleToggleMilestoneComplete = (id: string) => {
    setMilestones((prev) =>
      prev.map((m) => (m.id === id ? { ...m, completed: !m.completed } : m))
    );
    soundEngine.playSparkleChime();
  };

  const openEditMilestone = (ms: HolidayMilestone) => {
    setEditingMilestone(ms);
    setIsAddingMilestone(false);
    setDraftTitle(ms.title);
    setDraftDate(ms.targetDate);
    setDraftCategory(ms.category);
    setDraftNotes(ms.notes || '');
  };

  const openAddMilestone = () => {
    setEditingMilestone(null);
    setIsAddingMilestone(true);
    setDraftTitle('');
    setDraftDate(`${countdown.targetYear}-12-18T18:00`);
    setDraftCategory(`Step 0${visibleMilestones.length + 1} · Custom`);
    setDraftNotes('');
  };

  const handleSaveMilestoneModal = (e: React.FormEvent) => {
    e.preventDefault();
    if (!draftTitle.trim()) return;
    if (editingMilestone) {
      setMilestones((prev) =>
        prev.map((m) =>
          m.id === editingMilestone.id
            ? {
                ...m,
                title: draftTitle.trim(),
                targetDate: draftDate,
                category: draftCategory.trim() || 'Holiday Milestone',
                notes: draftNotes.trim(),
              }
            : m
        )
      );
    } else if (isAddingMilestone) {
      const newMs: HolidayMilestone = {
        id: `ms-custom-${Date.now()}`,
        title: draftTitle.trim(),
        targetDate: draftDate,
        icon: 'star',
        category: draftCategory.trim() || 'Holiday Milestone',
        completed: false,
        notes: draftNotes.trim(),
        order: milestones.length,
      };
      setMilestones((prev) => [...prev, newMs]);
    }
    setEditingMilestone(null);
    setIsAddingMilestone(false);
    soundEngine.playSparkleChime();
  };

  // Download High-Resolution Mac Lock-Screen Wallpaper PNG (2560x1440 QHD or 3840x2160 True 4K UHD)
  const handleDownloadWallpaperPng = (
    resId: WallpaperResolutionId = selectedResolution
  ) => {
    const spec = WALLPAPER_RESOLUTIONS[resId];
    const exportCanvas = document.createElement('canvas');
    renderLockScreenToCanvas({
      canvas: exportCanvas,
      width: spec.width,
      height: spec.height,
      countdown,
      milestones,
      now,
      heroImage: heroImageRef.current,
      // Export clean top clock zone by default unless user explicitly wants simulated clock baked in
      includeSimulatedMacClockOverlay: false,
      isHandshakeCoverImage: false,
      milestoneCount: milestoneDisplayCount,
    });

    const link = document.createElement('a');
    const resTag = resId === 'uhd_3840x2160' ? '3840x2160-4K-UHD' : '2560x1440-QHD';
    link.download = `Frost-and-Wonder-Mac-Lock-Screen-${countdown.targetYear}-${resTag}.png`;
    link.href = exportCanvas.toDataURL('image/png');
    link.click();

    setWallpaperDownloadMsg(
      `Downloaded ${spec.shortLabel} Mac Lock-Screen Wallpaper PNG (${spec.width} × ${spec.height}px) with top 32% macOS clock safe zone preserved and ${visibleMilestones.length} chronological milestones.`
    );
    soundEngine.playSparkleChime();
  };

  // Download 16:9 Handshake Project Cover Image PNG
  const handleDownloadHandshakeCoverPng = () => {
    const exportCanvas = document.createElement('canvas');
    renderLockScreenToCanvas({
      canvas: exportCanvas,
      width: 2560,
      height: 1440,
      countdown,
      milestones,
      now,
      heroImage: heroImageRef.current,
      includeSimulatedMacClockOverlay: true,
      isHandshakeCoverImage: true,
      milestoneCount: milestoneDisplayCount,
    });

    const link = document.createElement('a');
    link.download = `Frost-and-Wonder-Handshake-Cover-Image-2560x1440.png`;
    link.href = exportCanvas.toDataURL('image/png');
    link.click();

    setCoverDownloadMsg(
      'Downloaded Handshake Project Cover Image (.PNG, 2560 × 1440 16:9) showcasing the countdown lock-screen design.'
    );
    soundEngine.playSparkleChime();
  };

  // Tailor Milestones with Gemini AI Backward Planning
  const handlePersonalizeWithGemini = async () => {
    setIsGeneratingAi(true);
    setAiStatusBanner(null);
    try {
      const response = await fetch('/api/backward-plan', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          targetYear: countdown.targetYear,
          daysRemaining: countdown.days,
          milestoneCount: milestoneDisplayCount,
          customFocus,
        }),
      });
      const data = await response.json();
      if (!response.ok || data.error) {
        setAiStatusBanner({
          type: 'info',
          text:
            data.error ||
            'Using built-in backward-planned Christmas milestone schedule.',
        });
        return;
      }

      if (Array.isArray(data.phases) && data.phases.length >= 3) {
        const sliced = data.phases.slice(0, 4);
        const updatedSteps: AiRationaleStep[] = sliced.map(
          (p: Record<string, unknown>, idx: number) => {
            const fallback =
              DEFAULT_AI_RATIONALE_STEPS[idx] ||
              DEFAULT_AI_RATIONALE_STEPS[DEFAULT_AI_RATIONALE_STEPS.length - 1];
            return {
              stepNumber: idx + 1,
              title:
                typeof p.title === 'string' && p.title.trim()
                  ? p.title.trim()
                  : fallback.title,
              targetDate:
                typeof p.targetDate === 'string' &&
                !Number.isNaN(new Date(p.targetDate).getTime())
                  ? p.targetDate
                  : fallback.targetDate,
              daysBeforeChristmas:
                typeof p.daysBeforeChristmas === 'number'
                  ? p.daysBeforeChristmas
                  : fallback.daysBeforeChristmas,
              whyChosen:
                typeof p.objective === 'string' && p.objective.trim()
                  ? p.objective.trim()
                  : fallback.whyChosen,
            };
          }
        );

        setAiSteps(updatedSteps);
        if (typeof data.aiMethodologySummary === 'string') {
          setAiSummary(data.aiMethodologySummary);
        }

        // Sync directly to the Lock-Screen milestones in chronological order
        const icons: HolidayMilestone['icon'][] = [
          'tree',
          'shopping',
          'gift',
          'sleigh',
        ];
        const newMilestones: HolidayMilestone[] = updatedSteps
          .map((s, idx) => ({
            id: `ms-ai-${idx + 1}`,
            title: s.title,
            targetDate: s.targetDate,
            icon: icons[idx % icons.length],
            category: `Step 0${idx + 1} · AI Backward Plan`,
            completed: false,
            notes: s.whyChosen,
            order: idx,
          }))
          .sort(
            (a, b) =>
              new Date(a.targetDate).getTime() -
              new Date(b.targetDate).getTime()
          );
        setMilestones(newMilestones);
        setAiStatusBanner({
          type: 'success',
          text: `Gemini AI tailored your ${updatedSteps.length} lock-screen milestones backward from December 25, ${countdown.targetYear} and updated the lock screen!`,
        });
        soundEngine.playSparkleChime();
      }
    } catch {
      setAiStatusBanner({
        type: 'info',
        text: 'Showing verified 4-step backward-planned lock-screen milestone schedule.',
      });
    } finally {
      setIsGeneratingAi(false);
    }
  };

  const handleApplyDefaultAiPlanToLockScreen = () => {
    setMilestones(getInitialMilestones(countdown.targetYear));
    setAiSteps(DEFAULT_AI_RATIONALE_STEPS);
    setAiStatusBanner({
      type: 'success',
      text: `Restored the 4 signature backward-planned Christmas milestones onto your Lock Screen.`,
    });
    soundEngine.playSparkleChime();
  };

  // Optional Verified .ICS Calendar Reminder Export
  const handleExportIcsReminder = (targetList: HolidayMilestone[]) => {
    if (targetList.length === 0) return;
    const icsContent = generateMilestoneIcsContent(targetList, leadTimeHours);
    if (!icsContent.includes('BEGIN:VALARM')) return;

    const blob = new Blob([icsContent], {
      type: 'text/calendar;charset=utf-8',
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    const slug =
      targetList.length === 1
        ? targetList[0].title.toLowerCase().replace(/[^a-z0-9]+/g, '-')
        : `all-${targetList.length}-lockscreen-milestones`;
    a.download = `Frost-and-Wonder-Reminder-${slug}.ics`;
    a.click();
    URL.revokeObjectURL(url);

    const timestamp = new Date().toLocaleTimeString([], {
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
    });
    const newRecords: MilestoneReminderRecord[] = targetList.map((m) => ({
      milestoneId: m.id,
      milestoneTitle: m.title,
      targetDate: m.targetDate,
      leadTimeHours,
      channel: 'ics_calendar',
      verifiedAt: timestamp,
    }));

    setVerifiedReminders((prev) => {
      const remaining = prev.filter(
        (r) => !newRecords.some((nr) => nr.milestoneId === r.milestoneId)
      );
      return [...remaining, ...newRecords];
    });

    setReminderStatus({
      type: 'verified',
      text: `Verified RFC 5545 .ICS calendar file exported (${targetList.length} milestone${
        targetList.length > 1 ? 's' : ''
      } with -PT${leadTimeHours}H VALARM trigger) at ${timestamp}. Open the downloaded .ics file to add to macOS Calendar.`,
    });
    soundEngine.playSparkleChime();
  };

  // Honest Browser Notification Permission & Test
  const handleVerifyBrowserNotification = async (ms: HolidayMilestone) => {
    if (typeof window === 'undefined' || !('Notification' in window)) {
      setReminderStatus({
        type: 'unverified',
        text: 'Browser Notification API is unavailable in this environment. No browser alert was scheduled — use the verified .ICS Apple Calendar export instead.',
      });
      return;
    }

    try {
      let permission = Notification.permission;
      if (permission === 'default') {
        permission = await Notification.requestPermission();
      }
      if (permission !== 'granted') {
        setReminderStatus({
          type: 'unverified',
          text: `Browser Notification permission is "${permission}". No browser reminder is scheduled. Click "Export .ICS Alert" to schedule a verified macOS Calendar reminder.`,
        });
        return;
      }

      const notif = new Notification('🎄 Frost & Wonder Lock-Screen Reminder', {
        body: `Verified reminder for "${ms.title}" (${new Date(
          ms.targetDate
        ).toLocaleDateString()}).`,
      });
      notif.close();

      const timestamp = new Date().toLocaleTimeString([], {
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
      });
      setVerifiedReminders((prev) => [
        ...prev.filter((r) => r.milestoneId !== ms.id),
        {
          milestoneId: ms.id,
          milestoneTitle: ms.title,
          targetDate: ms.targetDate,
          leadTimeHours,
          channel: 'browser_notification',
          verifiedAt: timestamp,
        },
      ]);
      setReminderStatus({
        type: 'verified',
        text: `Verified Browser Notification permission ("granted") for "${ms.title}" at ${timestamp}.`,
      });
    } catch {
      setReminderStatus({
        type: 'unverified',
        text: 'Browser notifications are restricted inside this preview frame. No browser reminder was scheduled — use the verified .ICS Apple Calendar export.',
      });
    }
  };

  const handleCopyText = async (key: string, value: string) => {
    try {
      await navigator.clipboard.writeText(value);
      setCopiedField(key);
      window.setTimeout(() => setCopiedField(null), 3000);
    } catch {}
  };

  const nextUpcomingMilestone = useMemo(
    () => visibleMilestones.find((m) => !m.completed) || visibleMilestones[0],
    [visibleMilestones]
  );

  const formattedMacDate = now.toLocaleDateString('en-US', {
    weekday: 'long',
    month: 'long',
    day: 'numeric',
  });
  const formattedMacTime = now.toLocaleTimeString('en-US', {
    hour: 'numeric',
    minute: '2-digit',
    hour12: true,
  }).replace(/\s?[AP]M$/i, '');

  return (
    <div id="top" className="min-h-screen bg-[#050b1a] text-slate-100">
      {/* Gentle Animated Snowfall Layer */}
      <SnowfallCanvas
        intensity={countdown.magicIntensity}
        isChristmasMorning={countdown.isChristmasMorning}
        enabled={snowEnabled}
      />

      {/* Minimalist, Luxurious 3-Zone Top Bar */}
      <header className="sticky top-0 z-30 flex items-center justify-between gap-6 border-b border-sky-200/15 bg-[#050b1a]/85 px-6 py-3.5 backdrop-blur-2xl">
        <a
          href="#top"
          className="font-serif-display text-2xl font-bold tracking-tight text-white whitespace-nowrap shrink-0"
        >
          Frost &amp; Wonder
        </a>

        <nav
          aria-label="Lock Screen Sections"
          className="flex items-center gap-5 sm:gap-8 text-xs sm:text-sm font-medium text-slate-300 overflow-x-auto"
        >
          <a
            href="#lock-screen-stage"
            className="py-1 text-white transition hover:text-amber-200 whitespace-nowrap shrink-0"
          >
            Lock-Screen Stage
          </a>
          <a
            href="#wallpaper-studio"
            className="py-1 transition hover:text-white whitespace-nowrap shrink-0"
          >
            Mac Wallpaper Export
          </a>
          <a
            href="#ai-deadline-plan"
            className="py-1 transition hover:text-white whitespace-nowrap shrink-0"
          >
            AI Deadline Plan &amp; Reminders
          </a>
          <a
            href="#handshake-submission"
            className="py-1 transition hover:text-white whitespace-nowrap shrink-0"
          >
            Submission Kit
          </a>
        </nav>

        <div className="flex items-center gap-2.5 shrink-0">
          <button
            type="button"
            onClick={() => handleDownloadWallpaperPng(selectedResolution)}
            className="inline-flex items-center gap-1.5 rounded-xl bg-amber-300 px-4 py-2 text-xs font-semibold text-slate-950 shadow-sm transition hover:bg-amber-200 whitespace-nowrap shrink-0"
          >
            <Download className="h-3.5 w-3.5" />
            Download Mac Wallpaper (.PNG)
          </button>
        </div>
      </header>

      <main className="relative z-20 mx-auto max-w-7xl space-y-14 px-4 py-6 sm:px-6 lg:px-8">
        {/* =====================================================================
            HERO STAGE: THE ENCHANTED MAC CHRISTMAS COUNTDOWN LOCK SCREEN
           ===================================================================== */}
        <section
          id="lock-screen-stage"
          aria-label="Enchanted Christmas Lock Screen Centerpiece"
          data-testid="lock-screen-hero-stage"
          className="relative overflow-hidden rounded-[2rem] border border-sky-200/25 bg-[#060f24] shadow-[0_30px_90px_rgba(2,8,24,0.85)]"
        >
          {/* Coordinated Winter Background: Enchanted Ice Palace + Aurora + Contrast Scrim */}
          <div className="absolute inset-0">
            <img
              src={GENERATED_ASSETS.heroIcePalace}
              alt="Enchanted Ice Palace in the Winter Kingdom"
              referrerPolicy="no-referrer"
              className="h-full w-full object-cover object-center opacity-70 transition-opacity duration-700"
            />
            <div className="absolute inset-0 bg-gradient-to-b from-[#040a1a]/75 via-[#07142e]/45 to-[#040918]/95" />
            <div className="animate-aurora pointer-events-none absolute -top-20 left-1/4 h-80 w-1/2 rounded-full bg-gradient-to-r from-sky-400/20 via-indigo-400/15 to-amber-200/15 blur-3xl" />
          </div>

          {/* Subtle Lock-Screen Ambient Controls Strip */}
          <div className="relative z-10 flex flex-wrap items-center justify-between gap-3 border-b border-white/10 bg-slate-950/45 px-5 py-2.5 text-xs backdrop-blur-md">
            <div className="flex items-center gap-2 text-sky-200">
              <Sparkles className="h-3.5 w-3.5 text-amber-300" />
              <span className="font-medium">
                macOS Christmas Countdown Lock-Screen Design · Target Deadline:{' '}
                <strong className="text-white">
                  December 25, {countdown.targetYear}
                </strong>
              </span>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <button
                type="button"
                onClick={() =>
                  setShowMacClockPreviewOnStage((prev) => !prev)
                }
                aria-pressed={showMacClockPreviewOnStage}
                className={`inline-flex items-center gap-1.5 rounded-lg border px-2.5 py-1 text-xs font-medium transition whitespace-nowrap shrink-0 ${
                  showMacClockPreviewOnStage
                    ? 'border-sky-300/40 bg-sky-400/15 text-sky-100'
                    : 'border-white/15 bg-slate-900/70 text-slate-300 hover:text-white'
                }`}
              >
                <Monitor className="h-3.5 w-3.5" />
                {showMacClockPreviewOnStage
                  ? 'Mac Clock Safe-Zone: Shown'
                  : 'Mac Clock Safe-Zone: Hidden'}
              </button>

              <div
                role="group"
                aria-label="Number of Milestone Countdowns"
                className="inline-flex items-center rounded-lg border border-white/15 bg-slate-900/75 p-0.5"
              >
                {([3, 4] as const).map((count) => (
                  <button
                    key={count}
                    type="button"
                    onClick={() => setMilestoneDisplayCount(count)}
                    className={`rounded-md px-2.5 py-0.5 text-xs font-semibold transition ${
                      milestoneDisplayCount === count
                        ? 'bg-amber-300 text-slate-950'
                        : 'text-slate-300 hover:text-white'
                    }`}
                  >
                    {count} Milestones
                  </button>
                ))}
              </div>

              <button
                type="button"
                onClick={handleToggleMusic}
                aria-pressed={isMusicPlaying}
                className="inline-flex items-center gap-1.5 rounded-lg border border-white/15 bg-slate-900/75 px-2.5 py-1 text-xs font-medium text-slate-200 hover:text-white whitespace-nowrap shrink-0"
              >
                {isMusicPlaying ? (
                  <>
                    <Volume2 className="h-3.5 w-3.5 text-amber-300" />
                    Music On
                  </>
                ) : (
                  <>
                    <VolumeX className="h-3.5 w-3.5 text-slate-400" />
                    Celesta Music
                  </>
                )}
              </button>

              <button
                type="button"
                onClick={() => setSnowEnabled((s) => !s)}
                aria-pressed={snowEnabled}
                className="inline-flex items-center gap-1.5 rounded-lg border border-white/15 bg-slate-900/75 px-2.5 py-1 text-xs font-medium text-slate-200 hover:text-white whitespace-nowrap shrink-0"
              >
                <Sparkles className="h-3.5 w-3.5 text-sky-300" />
                {snowEnabled ? 'Snow On' : 'Snow Paused'}
              </button>

              <button
                type="button"
                onClick={() => setLiveDisplayOpen(true)}
                className="inline-flex items-center gap-1.5 rounded-lg border border-sky-300/40 bg-sky-400/15 px-2.5 py-1 text-xs font-semibold text-sky-100 hover:bg-sky-400/25 whitespace-nowrap shrink-0"
              >
                <Maximize2 className="h-3.5 w-3.5" />
                Full-Screen Live Mode
              </button>
            </div>
          </div>

          <div className="relative z-10 px-5 pt-6 pb-8 sm:px-10 sm:pt-8 sm:pb-10">
            {/* MAC SYSTEM CLOCK SAFE ZONE (Leaves Dedicated Top Space for macOS Lock Screen Clock) */}
            <div
              data-testid="mac-clock-safe-zone"
              className="mx-auto mb-6 flex min-h-[108px] max-w-xl flex-col items-center justify-center rounded-2xl border border-dashed border-sky-200/20 bg-slate-950/25 px-6 py-3 text-center backdrop-blur-sm"
            >
              {showMacClockPreviewOnStage ? (
                <>
                  <div className="text-xs font-semibold tracking-wide text-sky-100/90 sm:text-sm">
                    {formattedMacDate}
                  </div>
                  <div className="font-sans text-5xl font-bold tracking-tight text-white drop-shadow-[0_4px_24px_rgba(0,0,0,0.65)] sm:text-6xl">
                    {formattedMacTime}
                  </div>
                  <div className="mt-1 text-[11px] text-sky-200/80">
                    macOS System Clock Safe Zone — Reserved unobstructed space at top of Lock Screen
                  </div>
                </>
              ) : (
                <div className="py-4 text-xs font-medium text-sky-200/85">
                  Top 32% Unobstructed macOS System Clock Safe Zone (Ready for Native Mac Lock-Screen Clock)
                </div>
              )}
            </div>

            {/* VISUAL CENTERPIECE: ONE STUNNING ENCHANTED SNOW GLOBE + LARGE CHRISTMAS COUNTDOWN */}
            <div className="grid grid-cols-1 items-center gap-8 lg:grid-cols-12">
              {/* Left/Center Column: The Signature Enchanted Snow Globe */}
              <div className="lg:col-span-5">
                <EnchantedSnowGlobe
                  countdown={countdown}
                  externalSwirlTrigger={globeSwirlTrigger}
                />
              </div>

              {/* Right Column: Large, Easy-to-Read Countdown to Christmas Day */}
              <div className="space-y-6 text-center lg:col-span-7 lg:text-left">
                <div>
                  <div className="inline-flex items-center gap-2 rounded-lg border border-amber-300/35 bg-slate-950/75 px-3 py-1 text-xs font-semibold tracking-wider text-amber-200">
                    <span>
                      ✨ TARGET DEADLINE · DECEMBER 25, {countdown.targetYear}
                    </span>
                  </div>

                  <h1 className="font-serif-display mt-3 text-4xl font-semibold tracking-tight text-white sm:text-6xl">
                    {countdown.isChristmasMorning
                      ? 'Merry Christmas Morning!'
                      : `Countdown to Christmas Day`}
                  </h1>

                  <p className="mt-2 max-w-2xl text-sm text-slate-200 sm:text-base">
                    {countdown.isChristmasMorning
                      ? 'The winter kingdom is glowing in celebration—Christmas Day has arrived!'
                      : `“${FESTIVE_MESSAGES[0]}”`}
                  </p>
                </div>

                {/* Large, High-Contrast Tabular Countdown Cards */}
                <div
                  data-testid="main-christmas-countdown"
                  className="grid grid-cols-2 gap-3.5 sm:grid-cols-4 sm:gap-4"
                >
                  {[
                    {
                      label: 'DAYS',
                      value: countdown.days,
                      sub: `Until Dec 25, ${countdown.targetYear}`,
                      accent: 'border-sky-300/40 text-white',
                    },
                    {
                      label: 'HOURS',
                      value: countdown.hours,
                      sub: 'Remaining Today',
                      accent: 'border-sky-200/25 text-white',
                    },
                    {
                      label: 'MINUTES',
                      value: countdown.minutes,
                      sub: countdown.magicStageLabel,
                      accent: 'border-sky-200/25 text-white',
                    },
                    {
                      label: 'SECONDS',
                      value: countdown.seconds,
                      sub: 'Live Ticking Pulse',
                      accent: 'border-amber-300/45 text-amber-200',
                    },
                  ].map((unit) => (
                    <div
                      key={unit.label}
                      className={`rounded-2xl border bg-slate-950/80 px-4 py-5 text-center shadow-xl backdrop-blur-xl ${unit.accent}`}
                    >
                      <div className="font-mono-tabular text-4xl font-bold tracking-tight sm:text-6xl">
                        {String(unit.value).padStart(2, '0')}
                      </div>
                      <div className="mt-2 text-xs font-bold tracking-widest text-sky-300">
                        {unit.label}
                      </div>
                      <div className="mt-1 truncate text-[11px] text-slate-400">
                        {unit.sub}
                      </div>
                    </div>
                  ))}
                </div>

                {/* Quick Actions Beneath Main Countdown */}
                <div className="flex flex-wrap items-center justify-center gap-3 lg:justify-start">
                  <a
                    href="#wallpaper-studio"
                    className="inline-flex items-center gap-2 rounded-xl bg-amber-300 px-5 py-2.5 text-xs font-semibold text-slate-950 shadow-md transition hover:bg-amber-200"
                  >
                    <Download className="h-4 w-4" />
                    Export High-Res Mac Lock-Screen Wallpaper
                  </a>

                  <button
                    type="button"
                    onClick={() => setLiveDisplayOpen(true)}
                    className="inline-flex items-center gap-2 rounded-xl border border-sky-300/40 bg-sky-400/15 px-4 py-2.5 text-xs font-semibold text-sky-100 transition hover:bg-sky-400/25"
                  >
                    <Maximize2 className="h-4 w-4" />
                    Launch Separate Live Countdown
                  </button>

                  <button
                    type="button"
                    onClick={() =>
                      setSimulateChristmasMorning((prev) => !prev)
                    }
                    aria-pressed={simulateChristmasMorning}
                    className={`rounded-xl border px-3.5 py-2.5 text-xs font-medium transition ${
                      simulateChristmasMorning
                        ? 'border-amber-300 bg-amber-300/20 text-amber-100'
                        : 'border-white/15 bg-slate-950/75 text-slate-300 hover:text-white'
                    }`}
                  >
                    {simulateChristmasMorning
                      ? 'Exit Christmas Morning Preview'
                      : 'Preview Christmas Morning'}
                  </button>
                </div>
              </div>
            </div>

            {/* THREE OR FOUR SMALL, ELEGANT MILESTONE COUNTDOWNS (STRICT CHRONOLOGICAL ORDER) */}
            <div className="mt-10 border-t border-sky-200/20 pt-7">
              <div className="mb-4 flex flex-col justify-between gap-2 sm:flex-row sm:items-center">
                <div>
                  <span className="text-xs font-bold tracking-wider text-amber-200 uppercase">
                    Chronological Lock-Screen Milestones ({visibleMilestones.length} Steps to December 25, {countdown.targetYear})
                  </span>
                  <p className="text-xs text-slate-300">
                    Ordered chronologically from late November to Christmas Eve. Click any milestone to mark complete or customize its date.
                  </p>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={openAddMilestone}
                    className="inline-flex items-center gap-1.5 rounded-xl border border-sky-200/25 bg-slate-950/80 px-3 py-1.5 text-xs font-medium text-sky-100 hover:border-sky-300/50 hover:text-white"
                  >
                    <Plus className="h-3.5 w-3.5" />
                    Customize / Add Milestone
                  </button>
                </div>
              </div>

              <div
                data-testid="chronological-milestone-cards"
                className={`grid grid-cols-1 gap-3.5 sm:grid-cols-2 ${
                  milestoneDisplayCount === 3
                    ? 'lg:grid-cols-3'
                    : 'lg:grid-cols-4'
                }`}
              >
                {visibleMilestones.map((ms, index) => {
                  const rem = calculateMilestoneTimeRemaining(
                    ms.targetDate,
                    now
                  );
                  const parsedDate = new Date(ms.targetDate);
                  const dateBadge = Number.isNaN(parsedDate.getTime())
                    ? 'Dec 2026'
                    : parsedDate.toLocaleDateString('en-US', {
                        month: 'short',
                        day: 'numeric',
                      });

                  return (
                    <article
                      key={ms.id}
                      data-testid={`lockscreen-milestone-${index + 1}`}
                      className={`group flex flex-col justify-between rounded-2xl border p-4 backdrop-blur-xl transition ${
                        ms.completed
                          ? 'border-emerald-400/45 bg-emerald-950/35'
                          : 'border-sky-200/25 bg-slate-950/80 hover:border-sky-300/50'
                      }`}
                    >
                      <div>
                        <div className="flex items-center justify-between gap-2 text-xs">
                          <span className="font-mono-tabular font-bold text-sky-300">
                            STEP 0{index + 1} · {dateBadge.toUpperCase()}
                          </span>
                          <span
                            className={`font-mono-tabular font-bold ${
                              ms.completed
                                ? 'text-emerald-300'
                                : 'text-amber-200'
                            }`}
                          >
                            {ms.completed
                              ? '✓ COMPLETED'
                              : rem.formattedLabel}
                          </span>
                        </div>

                        <h2 className="font-serif-display mt-2 text-xl font-semibold text-white">
                          {ms.title}
                        </h2>

                        {ms.notes && (
                          <p className="mt-1 line-clamp-2 text-xs leading-relaxed text-slate-300">
                            {ms.notes}
                          </p>
                        )}
                      </div>

                      <div className="mt-3 flex items-center justify-between gap-2 border-t border-white/10 pt-2.5 text-[11px]">
                        <button
                          type="button"
                          onClick={() => handleToggleMilestoneComplete(ms.id)}
                          className={`inline-flex items-center gap-1 font-semibold transition ${
                            ms.completed
                              ? 'text-emerald-300 hover:text-emerald-200'
                              : 'text-sky-200 hover:text-white'
                          }`}
                        >
                          <CheckCircle2 className="h-3.5 w-3.5" />
                          {ms.completed ? 'Completed' : 'Mark Complete'}
                        </button>

                        <button
                          type="button"
                          onClick={() => openEditMilestone(ms)}
                          className="inline-flex items-center gap-1 text-slate-400 hover:text-white"
                        >
                          <Edit3 className="h-3 w-3" />
                          Edit
                        </button>
                      </div>
                    </article>
                  );
                })}
              </div>
            </div>
          </div>
        </section>

        {/* =====================================================================
            SECTION 2: DOWNLOADABLE HIGH-RESOLUTION MAC LOCK-SCREEN WALLPAPER
            & SEPARATE LIVE COUNTDOWN EXPERIENCE
           ===================================================================== */}
        <section
          id="wallpaper-studio"
          aria-label="Downloadable High-Resolution Mac Lock-Screen Wallpaper Studio"
          data-testid="wallpaper-export-studio"
          className="rounded-[2rem] border border-sky-200/20 bg-slate-900/75 p-6 shadow-2xl backdrop-blur-xl sm:p-10"
        >
          <div className="flex flex-col justify-between gap-4 border-b border-sky-200/15 pb-6 lg:flex-row lg:items-end">
            <div>
              <div className="inline-flex items-center gap-2 text-xs font-semibold tracking-wider text-amber-200 uppercase">
                <Monitor className="h-4 w-4 text-amber-300" />
                <span>
                  Downloadable Mac Lock-Screen Wallpaper · Native 16:9 High-DPI Export
                </span>
              </div>
              <h2 className="font-serif-display mt-1 text-3xl font-semibold text-white sm:text-4xl">
                Mac Lock-Screen Wallpaper &amp; Live Countdown Studio
              </h2>
              <p className="mt-1 max-w-3xl text-sm text-slate-300">
                Export your custom Christmas countdown lock screen in accurately labeled{' '}
                <strong>2560 × 1440 (QHD / 1440p)</strong> or{' '}
                <strong>3840 × 2160 (True 4K UHD)</strong> PNG formats, engineered with an unobstructed top 32% safe zone for the macOS system clock.
              </p>
            </div>

            <div className="flex flex-wrap items-center gap-2.5">
              <button
                type="button"
                onClick={() => setPreviewWithMacClock((prev) => !prev)}
                className="rounded-xl border border-sky-200/25 bg-slate-950 px-3.5 py-2 text-xs font-medium text-sky-100 hover:border-sky-300/50"
              >
                {previewWithMacClock
                  ? 'Previewing with Mac 9:41 Clock Overlay'
                  : 'Previewing Clean Wallpaper Export'}
              </button>
            </div>
          </div>

          <div className="mt-8 grid grid-cols-1 gap-8 lg:grid-cols-12 lg:items-start">
            {/* Live High-Resolution Lock-Screen Canvas Preview */}
            <div className="space-y-3 lg:col-span-7">
              <div className="overflow-hidden rounded-2xl border border-sky-200/30 bg-slate-950 shadow-2xl">
                <canvas
                  ref={wallpaperPreviewCanvasRef}
                  data-testid="lock-screen-wallpaper-canvas"
                  aria-label="Live preview of the downloadable Mac Lock-Screen Wallpaper featuring the Enchanted Ice Palace, the Ferris Wheel and Alpine Palace Snow Globe, the December 25, 2026 countdown snapshot, and chronological Christmas milestones."
                  className="aspect-video w-full object-contain"
                />
              </div>
              <div className="flex flex-wrap items-center justify-between gap-2 text-xs text-slate-400">
                <span>
                  Top 32% reserved for macOS Sonoma / Sequoia Lock-Screen Clock · Zero text overlap
                </span>
                <span className="font-mono-tabular text-sky-200">
                  {WALLPAPER_RESOLUTIONS[selectedResolution].shortLabel}
                </span>
              </div>
            </div>

            {/* Resolution Selector, Download Button & Static vs. Live Explanation */}
            <div className="space-y-5 lg:col-span-5">
              <div className="rounded-2xl border border-sky-200/20 bg-slate-950/85 p-5">
                <span className="block text-xs font-bold tracking-wider text-sky-300 uppercase">
                  1. Select Accurate Mac Wallpaper Resolution
                </span>
                <p className="mt-1 text-xs text-slate-300">
                  Choose standard QHD (1440p) or true 4K UHD (2160p). 2560 × 1440 is accurately labeled as QHD / 1440p and never mislabeled as 4K.
                </p>

                <div className="mt-3.5 space-y-2.5">
                  {(
                    Object.keys(WALLPAPER_RESOLUTIONS) as WallpaperResolutionId[]
                  ).map((resKey) => {
                    const spec = WALLPAPER_RESOLUTIONS[resKey];
                    const isSelected = selectedResolution === resKey;
                    return (
                      <button
                        key={spec.id}
                        type="button"
                        onClick={() => setSelectedResolution(spec.id)}
                        data-testid={`resolution-option-${spec.id}`}
                        className={`flex w-full items-center justify-between rounded-xl border p-3.5 text-left transition ${
                          isSelected
                            ? 'border-amber-300 bg-amber-300/15 text-white'
                            : 'border-slate-800 bg-slate-900/80 text-slate-300 hover:border-slate-700'
                        }`}
                      >
                        <div>
                          <div className="text-xs font-bold text-white">
                            {spec.shortLabel}
                          </div>
                          <div className="text-[11px] text-slate-400">
                            {spec.technicalLabel}
                          </div>
                        </div>
                        <span className="font-mono-tabular text-xs font-semibold text-amber-200">
                          {spec.width} × {spec.height}
                        </span>
                      </button>
                    );
                  })}
                </div>

                <button
                  type="button"
                  onClick={() => handleDownloadWallpaperPng(selectedResolution)}
                  data-testid="download-wallpaper-btn"
                  className="mt-4 inline-flex w-full items-center justify-center gap-2 rounded-xl bg-amber-300 px-5 py-3 text-xs font-bold text-slate-950 shadow-lg transition hover:bg-amber-200"
                >
                  <Download className="h-4 w-4" />
                  Download {WALLPAPER_RESOLUTIONS[selectedResolution].shortLabel} Wallpaper (.PNG)
                </button>

                {wallpaperDownloadMsg && (
                  <p
                    role="status"
                    className="mt-3 text-xs font-medium text-emerald-300"
                  >
                    ✓ {wallpaperDownloadMsg}
                  </p>
                )}
              </div>

              {/* Honest Architectural Explanation: Static PNG Snapshot vs. Live Dynamic Countdown */}
              <div
                data-testid="static-vs-live-explanation"
                className="rounded-2xl border border-amber-300/30 bg-slate-950/90 p-5 text-xs leading-relaxed text-slate-200"
              >
                <div className="flex items-center gap-2 font-bold text-amber-200">
                  <Sparkles className="h-4 w-4 text-amber-300" />
                  <span>
                    Static Wallpaper Snapshot vs. Live Countdown Experience
                  </span>
                </div>
                <p className="mt-2 text-slate-300">
                  <strong className="text-white">Static PNG Wallpaper:</strong>{' '}
                  macOS Lock Screen wallpaper images (<code>.PNG</code>) are static graphics. Your downloaded wallpaper captures an accurate high-resolution snapshot of the countdown and your {visibleMilestones.length} chronological milestones at export time—it does not tick automatically on its own.
                </p>
                <p className="mt-2 text-slate-300">
                  <strong className="text-white">
                    Separate Live Countdown Experience:
                  </strong>{' '}
                  For a real-time ticking countdown with animated snowfall, launch the{' '}
                  <strong className="text-sky-200">
                    Full-Screen Live Countdown Display
                  </strong>{' '}
                  in your browser or build the included native Swift/WidgetKit macOS companion project.
                </p>

                <div className="mt-3.5 flex flex-wrap items-center gap-2.5">
                  <button
                    type="button"
                    onClick={() => setLiveDisplayOpen(true)}
                    className="inline-flex items-center gap-1.5 rounded-xl bg-sky-300 px-3.5 py-2 text-xs font-semibold text-slate-950 transition hover:bg-sky-200"
                  >
                    <Maximize2 className="h-3.5 w-3.5" />
                    Launch Separate Live Full-Screen Countdown
                  </button>

                  <a
                    href="/Frost-and-Wonder-macOS-Project.zip"
                    download="Frost-and-Wonder-macOS-Project.zip"
                    className="inline-flex items-center gap-1.5 rounded-xl border border-sky-300/35 bg-sky-400/10 px-3.5 py-2 text-xs font-semibold text-sky-100 hover:bg-sky-400/20"
                  >
                    <Download className="h-3.5 w-3.5" />
                    Native macOS Swift/WidgetKit Project (.ZIP)
                  </a>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* =====================================================================
            SECTION 3: SIMPLE AI-ASSISTED DEADLINE PLAN & OPTIONAL REMINDERS
           ===================================================================== */}
        <section
          id="ai-deadline-plan"
          aria-label="Simple AI-Assisted Deadline Plan and Optional Milestone Reminders"
          data-testid="ai-deadline-plan-section"
          className="rounded-[2rem] border border-sky-200/20 bg-slate-900/75 p-6 shadow-2xl backdrop-blur-xl sm:p-10"
        >
          <div className="grid grid-cols-1 gap-8 lg:grid-cols-12">
            {/* Left 7 Columns: How the Milestones Were Chosen (Gemini Backward Planning) */}
            <div className="space-y-6 lg:col-span-7">
              <div>
                <div className="inline-flex items-center gap-2 text-xs font-semibold tracking-wider text-amber-200 uppercase">
                  <Sparkles className="h-4 w-4 text-amber-300" />
                  <span>
                    AI-Assisted Backward Planning · Working Backward from Dec 25, {countdown.targetYear}
                  </span>
                </div>
                <h2 className="font-serif-display mt-1 text-3xl font-semibold text-white sm:text-4xl">
                  How Your Lock-Screen Milestones Were Chosen
                </h2>
                <p className="mt-2 text-sm leading-relaxed text-slate-200">
                  {aiSummary}
                </p>
              </div>

              {/* 4 Concise Backward-Planned Rationale Cards */}
              <div className="grid grid-cols-1 gap-3.5 sm:grid-cols-2">
                {aiSteps.slice(0, milestoneDisplayCount).map((step) => {
                  const dateLabel = new Date(
                    step.targetDate
                  ).toLocaleDateString('en-US', {
                    month: 'short',
                    day: 'numeric',
                  });
                  return (
                    <div
                      key={step.stepNumber}
                      className="rounded-2xl border border-sky-200/15 bg-slate-950/80 p-4"
                    >
                      <div className="flex items-center justify-between text-xs">
                        <span className="font-mono-tabular font-bold text-sky-300">
                          STEP 0{step.stepNumber} · {dateLabel.toUpperCase()}
                        </span>
                        <span className="font-mono-tabular text-amber-200">
                          T-{step.daysBeforeChristmas} Days
                        </span>
                      </div>
                      <h3 className="font-serif-display mt-1.5 text-xl font-semibold text-white">
                        {step.title}
                      </h3>
                      <p className="mt-1 text-xs leading-relaxed text-slate-300">
                        {step.whyChosen}
                      </p>
                    </div>
                  );
                })}
              </div>

              {/* Simple Gemini AI Personalization Bar */}
              <div className="rounded-2xl border border-amber-300/30 bg-slate-950/85 p-4">
                <label
                  htmlFor="gemini-focus-input"
                  className="block text-xs font-semibold text-amber-200"
                >
                  Personalize Lock-Screen Milestones with Gemini AI
                </label>
                <p className="mt-0.5 text-xs text-slate-400">
                  Describe your holiday style and Gemini will generate a tailored backward plan from December 25, {countdown.targetYear} and update your lock screen.
                </p>
                <div className="mt-3 flex flex-col gap-2.5 sm:flex-row">
                  <input
                    id="gemini-focus-input"
                    type="text"
                    value={customFocus}
                    onChange={(e) => setCustomFocus(e.target.value)}
                    placeholder="e.g., Handmade gifts & early family travel"
                    className="w-full rounded-xl border border-slate-700 bg-slate-900 px-3.5 py-2 text-xs text-white placeholder:text-slate-500 focus:border-sky-400 focus:outline-none"
                  />
                  <button
                    type="button"
                    disabled={isGeneratingAi}
                    onClick={handlePersonalizeWithGemini}
                    className="inline-flex items-center justify-center gap-1.5 rounded-xl bg-amber-300 px-4 py-2 text-xs font-semibold text-slate-950 transition hover:bg-amber-200 disabled:opacity-50 whitespace-nowrap shrink-0"
                  >
                    <RefreshCw
                      className={`h-3.5 w-3.5 ${
                        isGeneratingAi ? 'animate-spin' : ''
                      }`}
                    />
                    {isGeneratingAi ? 'Planning...' : 'Ask Gemini AI'}
                  </button>
                  <button
                    type="button"
                    onClick={handleApplyDefaultAiPlanToLockScreen}
                    className="rounded-xl border border-slate-700 bg-slate-900 px-3 py-2 text-xs font-medium text-slate-300 hover:text-white whitespace-nowrap shrink-0"
                  >
                    Reset Default Plan
                  </button>
                </div>

                {aiStatusBanner && (
                  <p
                    role="status"
                    className="mt-2.5 text-xs font-medium text-emerald-300"
                  >
                    {aiStatusBanner.text}
                  </p>
                )}
              </div>
            </div>

            {/* Right 5 Columns: Optional Reminders for Important Milestones */}
            <div
              data-testid="optional-milestone-reminders"
              className="flex flex-col justify-between rounded-2xl border border-sky-200/20 bg-slate-950/85 p-5 sm:p-6 lg:col-span-5"
            >
              <div>
                <div className="flex items-center gap-2 text-xs font-semibold tracking-wider text-sky-300 uppercase">
                  <Bell className="h-4 w-4 text-amber-300" />
                  <span>Optional Milestone Reminders</span>
                </div>
                <h3 className="font-serif-display mt-1 text-2xl font-semibold text-white">
                  Verified macOS Calendar &amp; Alert Setup
                </h3>
                <p className="mt-1 text-xs leading-relaxed text-slate-300">
                  Download an RFC 5545 <code>.ICS</code> calendar file with an embedded{' '}
                  <code>VALARM</code> reminder for macOS Calendar, or verify browser notifications. Reminders are never shown as scheduled until created and verified.
                </p>

                <div className="mt-4 flex flex-wrap items-center justify-between gap-2 rounded-xl border border-slate-800 bg-slate-900/80 p-3 text-xs">
                  <div className="flex items-center gap-1.5 text-slate-300">
                    <Clock className="h-3.5 w-3.5 text-sky-300" />
                    <label htmlFor="lead-time-select">Alert Lead Time:</label>
                  </div>
                  <select
                    id="lead-time-select"
                    value={leadTimeHours}
                    onChange={(e) => setLeadTimeHours(Number(e.target.value))}
                    className="rounded-lg border border-slate-700 bg-slate-950 px-2.5 py-1 text-xs text-white"
                  >
                    <option value={2}>2 Hours Before</option>
                    <option value={24}>24 Hours Before (1 Day)</option>
                    <option value={48}>48 Hours Before (2 Days)</option>
                    <option value={168}>1 Week Before</option>
                  </select>
                </div>

                {/* Honest Reminder Verification Banner */}
                <div
                  role="status"
                  data-testid="reminder-verification-status"
                  className={`mt-3.5 flex items-start gap-2 rounded-xl border p-3 text-xs ${
                    reminderStatus.type === 'verified'
                      ? 'border-emerald-400/40 bg-emerald-950/40 text-emerald-200'
                      : 'border-slate-800 bg-slate-900/90 text-slate-300'
                  }`}
                >
                  {reminderStatus.type === 'verified' ? (
                    <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-emerald-300" />
                  ) : (
                    <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0 text-amber-300" />
                  )}
                  <span>{reminderStatus.text}</span>
                </div>

                {/* Per-Milestone Reminder List */}
                <div className="mt-4 space-y-2.5">
                  {visibleMilestones.map((ms) => {
                    const verified = verifiedReminders.find(
                      (r) => r.milestoneId === ms.id
                    );
                    const dateStr = new Date(ms.targetDate).toLocaleDateString(
                      'en-US',
                      { month: 'short', day: 'numeric' }
                    );
                    return (
                      <div
                        key={ms.id}
                        className="flex flex-wrap items-center justify-between gap-2 rounded-xl border border-slate-800 bg-slate-900/75 px-3.5 py-2.5 text-xs"
                      >
                        <div>
                          <div className="font-semibold text-white">
                            {ms.title}
                          </div>
                          <div className="text-[11px] text-slate-400">
                            {dateStr} ·{' '}
                            {verified ? (
                              <span className="font-semibold text-emerald-300">
                                ✓ Verified ({verified.channel === 'ics_calendar' ? '.ICS' : 'Browser'})
                              </span>
                            ) : (
                              <span>Not Scheduled</span>
                            )}
                          </div>
                        </div>

                        <div className="flex items-center gap-1.5">
                          <button
                            type="button"
                            onClick={() => handleExportIcsReminder([ms])}
                            className="rounded-lg border border-sky-300/35 bg-sky-400/15 px-2.5 py-1 text-[11px] font-semibold text-sky-100 hover:bg-sky-400/25"
                          >
                            .ICS Alert
                          </button>
                          <button
                            type="button"
                            onClick={() => handleVerifyBrowserNotification(ms)}
                            className="rounded-lg border border-slate-700 bg-slate-950 px-2.5 py-1 text-[11px] text-slate-300 hover:text-white"
                          >
                            Test Alert
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              <button
                type="button"
                onClick={() => handleExportIcsReminder(visibleMilestones)}
                className="mt-4 inline-flex w-full items-center justify-center gap-2 rounded-xl bg-sky-300 px-4 py-2.5 text-xs font-bold text-slate-950 transition hover:bg-sky-200"
              >
                <Calendar className="h-4 w-4" />
                Export All {visibleMilestones.length} Milestones to macOS Calendar (.ICS)
              </button>
            </div>
          </div>
        </section>

        {/* =====================================================================
            SECTION 4: HANDSHAKE SUBMISSION PACKAGE & PRESERVED FULL BACKUP
           ===================================================================== */}
        <section
          id="handshake-submission"
          aria-label="Handshake Competition Submission Package and Preserved Project Backup"
          data-testid="handshake-submission-package"
          className="rounded-[2rem] border border-amber-300/25 bg-slate-900/75 p-6 shadow-2xl backdrop-blur-xl sm:p-10"
        >
          <div className="flex flex-col justify-between gap-4 border-b border-sky-200/15 pb-6 lg:flex-row lg:items-end">
            <div>
              <div className="inline-flex items-center gap-2 text-xs font-semibold tracking-wider text-amber-200 uppercase">
                <Sparkles className="h-4 w-4 text-amber-300" />
                <span>
                  Ready-to-Submit Handshake Challenge Deliverables
                </span>
              </div>
              <h2 className="font-serif-display mt-1 text-3xl font-semibold text-white sm:text-4xl">
                Handshake Submission Kit &amp; Full Project Backup
              </h2>
              <p className="mt-1 max-w-3xl text-sm text-slate-300">
                Everything needed for the Handshake &ldquo;Your Deadline, Your Design: Create a Countdown Lock Screen&rdquo; submission form—plus your preserved complete backup of the full Family Gift-Management Edition.
              </p>
            </div>

            <a
              href="/Frost-and-Wonder-Full-Family-Planner-Backup.zip"
              download="Frost-and-Wonder-Full-Family-Planner-Backup.zip"
              data-testid="download-full-backup-zip"
              className="inline-flex items-center gap-2 rounded-xl border border-emerald-400/40 bg-emerald-950/50 px-4 py-2.5 text-xs font-semibold text-emerald-200 transition hover:bg-emerald-950/80 whitespace-nowrap shrink-0"
            >
              <Archive className="h-4 w-4 text-emerald-300" />
              Download Preserved Full Gift-Planner Backup (.ZIP)
            </a>
          </div>

          <div className="mt-8 grid grid-cols-1 gap-8 lg:grid-cols-12">
            {/* Left 6 Columns: 16:9 Handshake Cover Image Preview & Download */}
            <div className="space-y-4 lg:col-span-6">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold tracking-wider text-amber-200 uppercase">
                  1. Handshake Project Cover Image (16:9 Lock-Screen Design)
                </span>
                <span className="font-mono-tabular text-xs text-slate-400">
                  2560 × 1440 PNG
                </span>
              </div>

              <div className="overflow-hidden rounded-2xl border border-amber-300/35 bg-slate-950 shadow-xl">
                <canvas
                  ref={coverPreviewCanvasRef}
                  data-testid="handshake-cover-image-canvas"
                  aria-label="Handshake Project Cover Image showing the actual countdown lock-screen design"
                  className="aspect-video w-full object-contain"
                />
              </div>

              <button
                type="button"
                onClick={handleDownloadHandshakeCoverPng}
                data-testid="download-cover-image-btn"
                className="inline-flex w-full items-center justify-center gap-2 rounded-xl bg-amber-300 px-5 py-3 text-xs font-bold text-slate-950 shadow-md transition hover:bg-amber-200"
              >
                <Download className="h-4 w-4" />
                Download Handshake Project Cover Image (.PNG)
              </button>

              {coverDownloadMsg && (
                <p role="status" className="text-xs font-medium text-emerald-300">
                  ✓ {coverDownloadMsg}
                </p>
              )}
            </div>

            {/* Right 6 Columns: Copyable Title, Shareable Public URL, and First-Person Description */}
            <div className="space-y-4 lg:col-span-6">
              {/* Project Title */}
              <div className="rounded-2xl border border-slate-800 bg-slate-950/85 p-4">
                <div className="flex items-center justify-between gap-2">
                  <span className="text-xs font-bold text-sky-300 uppercase">
                    2. Official Project Title
                  </span>
                  <button
                    type="button"
                    onClick={() =>
                      handleCopyText('title', HANDSHAKE_PROJECT_TITLE)
                    }
                    className="inline-flex items-center gap-1 rounded-lg border border-slate-700 bg-slate-900 px-2.5 py-1 text-xs font-medium text-slate-200 hover:text-white"
                  >
                    {copiedField === 'title' ? (
                      <>
                        <Check className="h-3.5 w-3.5 text-emerald-300" />
                        Copied
                      </>
                    ) : (
                      <>
                        <Copy className="h-3.5 w-3.5" />
                        Copy Title
                      </>
                    )}
                  </button>
                </div>
                <p className="mt-1.5 text-sm font-semibold text-white">
                  {HANDSHAKE_PROJECT_TITLE}
                </p>
              </div>

              {/* Shareable Public Project Link (Zero Login Required) */}
              <div className="rounded-2xl border border-slate-800 bg-slate-950/85 p-4">
                <div className="flex items-center justify-between gap-2">
                  <span className="text-xs font-bold text-sky-300 uppercase">
                    3. Shareable Public Project Link (No Sign-In Required)
                  </span>
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => handleCopyText('url', PUBLIC_SHARE_URL)}
                      className="inline-flex items-center gap-1 rounded-lg border border-slate-700 bg-slate-900 px-2.5 py-1 text-xs font-medium text-slate-200 hover:text-white"
                    >
                      {copiedField === 'url' ? (
                        <>
                          <Check className="h-3.5 w-3.5 text-emerald-300" />
                          Copied URL
                        </>
                      ) : (
                        <>
                          <Copy className="h-3.5 w-3.5" />
                          Copy Link
                        </>
                      )}
                    </button>
                    <a
                      href={PUBLIC_SHARE_URL}
                      target="_blank"
                      rel="noreferrer"
                      className="inline-flex items-center gap-1 rounded-lg border border-sky-300/35 bg-sky-400/15 px-2.5 py-1 text-xs font-semibold text-sky-100 hover:bg-sky-400/25"
                    >
                      <ExternalLink className="h-3.5 w-3.5" />
                      Open
                    </a>
                  </div>
                </div>
                <p
                  data-testid="public-project-url"
                  className="font-mono-tabular mt-1.5 break-all text-xs text-amber-200"
                >
                  {PUBLIC_SHARE_URL}
                </p>
                <p className="mt-1 text-[11px] text-emerald-300">
                  ✓ Verified public access: Judges can explore the interactive snow globe, export the lock-screen wallpaper, and test AI backward planning immediately with zero login gates.
                </p>
              </div>

              {/* First-Person Competition Description */}
              <div className="rounded-2xl border border-slate-800 bg-slate-950/85 p-4">
                <div className="flex items-center justify-between gap-2">
                  <span className="text-xs font-bold text-sky-300 uppercase">
                    4. First-Person Handshake Submission Description
                  </span>
                  <button
                    type="button"
                    onClick={() =>
                      handleCopyText('desc', HANDSHAKE_FIRST_PERSON_DESCRIPTION)
                    }
                    className="inline-flex items-center gap-1 rounded-lg border border-slate-700 bg-slate-900 px-2.5 py-1 text-xs font-medium text-slate-200 hover:text-white"
                  >
                    {copiedField === 'desc' ? (
                      <>
                        <Check className="h-3.5 w-3.5 text-emerald-300" />
                        Copied Description
                      </>
                    ) : (
                      <>
                        <Copy className="h-3.5 w-3.5" />
                        Copy Description
                      </>
                    )}
                  </button>
                </div>
                <pre className="mt-2 max-h-40 overflow-y-auto whitespace-pre-wrap font-sans text-xs leading-relaxed text-slate-300">
                  {HANDSHAKE_FIRST_PERSON_DESCRIPTION}
                </pre>
              </div>
            </div>
          </div>
        </section>
      </main>

      {/* Milestone Customize / Add Modal */}
      {(editingMilestone || isAddingMilestone) && (
        <div
          role="dialog"
          aria-modal="true"
          aria-label="Customize Lock-Screen Milestone"
          className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 p-4 backdrop-blur-md"
        >
          <form
            onSubmit={handleSaveMilestoneModal}
            className="w-full max-w-md space-y-4 rounded-3xl border border-sky-200/25 bg-slate-900 p-6 shadow-2xl"
          >
            <h3 className="font-serif-display text-2xl font-semibold text-white">
              {editingMilestone
                ? 'Edit Lock-Screen Milestone'
                : 'Add Lock-Screen Milestone'}
            </h3>

            <div>
              <label
                htmlFor="ms-title-input"
                className="block text-xs font-semibold text-sky-200"
              >
                Milestone Title
              </label>
              <input
                id="ms-title-input"
                type="text"
                required
                value={draftTitle}
                onChange={(e) => setDraftTitle(e.target.value)}
                className="mt-1 w-full rounded-xl border border-slate-700 bg-slate-950 px-3 py-2 text-xs text-white"
              />
            </div>

            <div>
              <label
                htmlFor="ms-date-input"
                className="block text-xs font-semibold text-sky-200"
              >
                Target Date &amp; Time
              </label>
              <input
                id="ms-date-input"
                type="datetime-local"
                required
                value={draftDate}
                onChange={(e) => setDraftDate(e.target.value)}
                className="mt-1 w-full rounded-xl border border-slate-700 bg-slate-950 px-3 py-2 text-xs text-white"
              />
            </div>

            <div>
              <label
                htmlFor="ms-notes-input"
                className="block text-xs font-semibold text-sky-200"
              >
                Why Chosen / Notes
              </label>
              <textarea
                id="ms-notes-input"
                rows={2}
                value={draftNotes}
                onChange={(e) => setDraftNotes(e.target.value)}
                className="mt-1 w-full rounded-xl border border-slate-700 bg-slate-950 px-3 py-2 text-xs text-white"
              />
            </div>

            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => {
                  setEditingMilestone(null);
                  setIsAddingMilestone(false);
                }}
                className="rounded-xl border border-slate-700 bg-slate-950 px-4 py-2 text-xs font-medium text-slate-300 hover:text-white"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="rounded-xl bg-amber-300 px-4 py-2 text-xs font-bold text-slate-950 hover:bg-amber-200"
              >
                Save Milestone
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Quiet Editorial Footer */}
      <footer className="relative z-20 mt-16 border-t border-sky-200/15 bg-slate-950/85 px-6 py-8 text-xs text-slate-400">
        <div className="mx-auto flex max-w-7xl flex-col items-center justify-between gap-4 sm:flex-row">
          <div>
            <span className="font-serif-display text-base font-semibold text-white">
              Frost &amp; Wonder
            </span>{' '}
            · Enchanted Christmas Countdown Lock Screen for macOS · Target Deadline: December 25, {countdown.targetYear}
          </div>

          <div className="flex flex-wrap items-center gap-4">
            <button
              type="button"
              onClick={() => setLiveDisplayOpen(true)}
              className="text-sky-200 hover:underline"
            >
              Launch Full-Screen Live Countdown
            </button>
            <span aria-hidden="true">·</span>
            <a
              href="/Frost-and-Wonder-Full-Family-Planner-Backup.zip"
              download="Frost-and-Wonder-Full-Family-Planner-Backup.zip"
              className="text-emerald-300 hover:underline"
            >
              Full Gift-Planner Backup (.ZIP)
            </a>
          </div>
        </div>
      </footer>

      {/* Separate Full-Screen Live Countdown Experience */}
      <ScreenSaverModal
        isOpen={liveDisplayOpen}
        onClose={() => setLiveDisplayOpen(false)}
        countdown={countdown}
        nextMilestone={nextUpcomingMilestone}
        isMusicPlaying={isMusicPlaying}
        onToggleMusic={handleToggleMusic}
      />

      <OfflineIndicator />
    </div>
  );
}
