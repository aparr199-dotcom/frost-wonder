/**
 * Original Web Audio API Celesta & Winter Music Box Synthesizer.
 * Generates royalty-free, original crystalline winter melodies and UI chimes.
 */
class WinterSoundEngine {
  private ctx: AudioContext | null = null;
  private isPlayingMusic = false;
  private loopTimer: number | null = null;
  private noteIndex = 0;

  // Original enchanting pentatonic/lydian winter celesta sequence (frequencies in Hz)
  private readonly melodyNotes = [
    523.25, // C5
    659.25, // E5
    783.99, // G5
    987.77, // B5
    1046.5, // C6
    987.77, // B5
    783.99, // G5
    659.25, // E5
    587.33, // D5
    739.99, // F#5
    880.0,  // A5
    1174.66,// D6
    1046.5, // C6
    880.0,  // A5
    783.99, // G5
    659.25, // E5
  ];

  private ensureContext(): AudioContext | null {
    if (typeof window === 'undefined') return null;
    if (!this.ctx) {
      const AudioCtx =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext: typeof AudioContext })
          .webkitAudioContext;
      if (AudioCtx) {
        this.ctx = new AudioCtx();
      }
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume().catch(() => {});
    }
    return this.ctx;
  }

  public playCelestaNote(freq: number, duration = 1.6, volume = 0.045) {
    const ctx = this.ensureContext();
    if (!ctx) return;

    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const harmonic = ctx.createOscillator();
    const gain = ctx.createGain();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(freq, now);

    // Subtle bell overtone
    harmonic.type = 'triangle';
    harmonic.frequency.setValueAtTime(freq * 2, now);

    const harmonicGain = ctx.createGain();
    harmonicGain.gain.setValueAtTime(volume * 0.25, now);
    harmonicGain.gain.exponentialRampToValueAtTime(0.0001, now + duration * 0.5);

    gain.gain.setValueAtTime(0.001, now);
    gain.gain.linearRampToValueAtTime(volume, now + 0.03);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + duration);

    osc.connect(gain);
    harmonic.connect(harmonicGain);
    harmonicGain.connect(gain);
    gain.connect(ctx.destination);

    osc.start(now);
    harmonic.start(now);
    osc.stop(now + duration);
    harmonic.stop(now + duration);
  }

  public playSparkleChime() {
    const chord = [783.99, 987.77, 1174.66, 1567.98];
    chord.forEach((freq, idx) => {
      window.setTimeout(() => {
        this.playCelestaNote(freq, 0.9, 0.035);
      }, idx * 70);
    });
  }

  public startSoundtrack() {
    if (this.isPlayingMusic) return;
    this.ensureContext();
    this.isPlayingMusic = true;
    this.noteIndex = 0;

    const tick = () => {
      if (!this.isPlayingMusic) return;
      const freq = this.melodyNotes[this.noteIndex % this.melodyNotes.length];
      this.playCelestaNote(freq, 2.1, 0.035);
      if (this.noteIndex % 4 === 0) {
        this.playCelestaNote(freq * 0.5, 3.0, 0.02);
      }
      this.noteIndex++;
      this.loopTimer = window.setTimeout(tick, 680);
    };

    tick();
  }

  public stopSoundtrack() {
    this.isPlayingMusic = false;
    if (this.loopTimer !== null) {
      clearTimeout(this.loopTimer);
      this.loopTimer = null;
    }
  }

  public toggleSoundtrack(): boolean {
    if (this.isPlayingMusic) {
      this.stopSoundtrack();
      return false;
    } else {
      this.startSoundtrack();
      return true;
    }
  }
}

export const soundEngine = new WinterSoundEngine();
