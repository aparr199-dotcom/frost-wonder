import { CountdownState, HolidayMilestone } from '../types/holiday';
import {
  calculateMilestoneTimeRemaining,
  getChronologicalLockScreenMilestones,
} from './holidayLogic';

export interface RenderLockScreenOptions {
  canvas: HTMLCanvasElement;
  width: number;
  height: number;
  countdown: CountdownState;
  milestones: HolidayMilestone[];
  now: Date;
  heroImage: HTMLImageElement | null;
  /**
   * When true (for live UI preview or Handshake Cover Image), renders the macOS Lock Screen clock
   * in the top safe zone to demonstrate zero overlap. When false (for actual Mac wallpaper PNG use),
   * leaves the top clock safe zone clear for the real macOS Sonoma/Sequoia system clock.
   */
  includeSimulatedMacClockOverlay: boolean;
  /**
   * When true, adds a subtle top-center Handshake Showcase header badge for the project cover card.
   */
  isHandshakeCoverImage?: boolean;
  /**
   * Number of small chronological milestone countdown cards to display (3 or 4, defaults to 4).
   */
  milestoneCount?: 3 | 4 | 5;
}

export function renderLockScreenToCanvas(options: RenderLockScreenOptions): void {
  const {
    canvas,
    width,
    height,
    countdown,
    milestones,
    now,
    heroImage,
    includeSimulatedMacClockOverlay,
    isHandshakeCoverImage = false,
    milestoneCount = 4,
  } = options;

  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext('2d');
  if (!ctx) return;

  const scale = width / 2560; // Base coordinate system designed at 2560x1440 (16:9)

  ctx.save();

  // 1. Background Artwork: Enchanted Ice Palace or deep winter twilight gradient fallback
  if (heroImage && heroImage.complete && heroImage.naturalWidth > 0) {
    ctx.drawImage(heroImage, 0, 0, width, height);
  } else {
    const fallbackGrad = ctx.createLinearGradient(0, 0, 0, height);
    fallbackGrad.addColorStop(0, '#040a1a');
    fallbackGrad.addColorStop(0.45, '#0b1e40');
    fallbackGrad.addColorStop(1, '#030714');
    ctx.fillStyle = fallbackGrad;
    ctx.fillRect(0, 0, width, height);
  }

  // 2. Measured Contrast Scrim (preserves Palace glow in upper-middle while guaranteeing 4.5:1+ contrast)
  const scrim = ctx.createLinearGradient(0, 0, 0, height);
  scrim.addColorStop(0, 'rgba(4, 10, 24, 0.58)');
  scrim.addColorStop(0.32, 'rgba(6, 13, 30, 0.24)');
  scrim.addColorStop(0.55, 'rgba(6, 13, 30, 0.74)');
  scrim.addColorStop(1, 'rgba(3, 8, 20, 0.95)');
  ctx.fillStyle = scrim;
  ctx.fillRect(0, 0, width, height);

  // Subtle aurora glow behind palace
  const aurora = ctx.createRadialGradient(
    width * 0.5,
    height * 0.34,
    40 * scale,
    width * 0.5,
    height * 0.34,
    850 * scale
  );
  aurora.addColorStop(0, 'rgba(56, 189, 248, 0.24)');
  aurora.addColorStop(0.5, 'rgba(167, 139, 250, 0.14)');
  aurora.addColorStop(1, 'rgba(7, 13, 31, 0)');
  ctx.fillStyle = aurora;
  ctx.fillRect(0, 0, width, height);

  // 3. Delicate drifting snowflakes & star crystals across the lock screen sky
  for (let i = 0; i < 110; i++) {
    const fx = ((i * 233 + 97) % 2560) * scale;
    const fy = ((i * 317 + 53) % 1440) * scale;
    const fr = ((i % 3) + 1.4) * scale;
    ctx.fillStyle =
      i % 7 === 0
        ? 'rgba(253, 224, 71, 0.48)'
        : i % 3 === 0
        ? 'rgba(186, 230, 253, 0.52)'
        : 'rgba(255, 255, 255, 0.42)';
    ctx.beginPath();
    ctx.arc(fx, fy, fr, 0, Math.PI * 2);
    ctx.fill();
  }

  // 4. TOP 32% MAC SYSTEM CLOCK SAFE ZONE (0 to 460px at 1440p)
  if (includeSimulatedMacClockOverlay) {
    ctx.save();
    ctx.textAlign = 'center';
    ctx.fillStyle = 'rgba(226, 232, 240, 0.92)';
    ctx.font = `600 ${Math.round(34 * scale)}px -apple-system, BlinkMacSystemFont, "Plus Jakarta Sans", sans-serif`;
    const dateLabel = now.toLocaleDateString('en-US', {
      weekday: 'long',
      month: 'long',
      day: 'numeric',
    });
    ctx.fillText(dateLabel, width * 0.5, 130 * scale);

    ctx.fillStyle = 'rgba(255, 255, 255, 0.96)';
    ctx.font = `700 ${Math.round(168 * scale)}px -apple-system, BlinkMacSystemFont, "Plus Jakarta Sans", sans-serif`;
    ctx.fillText('9:41', width * 0.5, 288 * scale);

    if (isHandshakeCoverImage) {
      ctx.fillStyle = 'rgba(15, 23, 42, 0.85)';
      ctx.strokeStyle = 'rgba(253, 224, 71, 0.65)';
      ctx.lineWidth = 2 * scale;
      ctx.beginPath();
      ctx.roundRect(
        width * 0.5 - 410 * scale,
        330 * scale,
        820 * scale,
        48 * scale,
        24 * scale
      );
      ctx.fill();
      ctx.stroke();

      ctx.fillStyle = '#fde68a';
      ctx.font = `600 ${Math.round(20 * scale)}px "Plus Jakarta Sans", sans-serif`;
      ctx.fillText(
        'FROST & WONDER · MAC LOCK-SCREEN COUNTDOWN & MILESTONE ARCHITECT',
        width * 0.5,
        361 * scale
      );
    }
    ctx.restore();
  } else {
    // Subtle top-right watermark leaving the center clock zone 100% unobstructed
    ctx.save();
    ctx.textAlign = 'right';
    ctx.fillStyle = 'rgba(186, 230, 253, 0.65)';
    ctx.font = `600 ${Math.round(18 * scale)}px "Plus Jakarta Sans", sans-serif`;
    ctx.fillText(
      `FROST & WONDER · DECEMBER 25, ${countdown.targetYear} EDITION`,
      width - 110 * scale,
      64 * scale
    );
    ctx.restore();
  }

  // 5. MAIN LOWER-MIDDLE LOCK SCREEN CONSOLE (Starts at Y = 585 * scale, well below macOS clock)
  const panelX = 120 * scale;
  const panelY = 585 * scale;
  const panelW = 2320 * scale;
  const panelH = 745 * scale;

  const glassGrad = ctx.createLinearGradient(panelX, panelY, panelX, panelY + panelH);
  glassGrad.addColorStop(0, 'rgba(9, 20, 44, 0.88)');
  glassGrad.addColorStop(1, 'rgba(4, 10, 24, 0.95)');
  ctx.fillStyle = glassGrad;
  ctx.strokeStyle = 'rgba(186, 230, 253, 0.44)';
  ctx.lineWidth = 2.5 * scale;
  ctx.beginPath();
  ctx.roundRect(panelX, panelY, panelW, panelH, 38 * scale);
  ctx.fill();
  ctx.stroke();

  // Inner subtle champagne border highlight
  ctx.strokeStyle = 'rgba(253, 224, 71, 0.24)';
  ctx.lineWidth = 1.2 * scale;
  ctx.beginPath();
  ctx.roundRect(
    panelX + 10 * scale,
    panelY + 10 * scale,
    panelW - 20 * scale,
    panelH - 20 * scale,
    30 * scale
  );
  ctx.stroke();

  // 6. LEFT COLUMN OF CONSOLE: SIGNATURE SNOW GLOBE (Ferris Wheel, Warm-Lit Palace Village & Ornate Navy-Gold Filigree Base)
  const globeCx = panelX + 275 * scale;
  const globeCy = panelY + 195 * scale;
  const globeR = 148 * scale;

  // Outer halo of snow globe
  const globeHalo = ctx.createRadialGradient(
    globeCx,
    globeCy,
    globeR * 0.4,
    globeCx,
    globeCy,
    globeR * 1.25
  );
  globeHalo.addColorStop(0, 'rgba(56, 189, 248, 0.32)');
  globeHalo.addColorStop(0.6, 'rgba(14, 165, 233, 0.16)');
  globeHalo.addColorStop(1, 'rgba(7, 13, 31, 0)');
  ctx.fillStyle = globeHalo;
  ctx.beginPath();
  ctx.arc(globeCx, globeCy, globeR * 1.25, 0, Math.PI * 2);
  ctx.fill();

  // Clip inside crystal dome
  ctx.save();
  ctx.beginPath();
  ctx.arc(globeCx, globeCy, globeR, 0, Math.PI * 2);
  ctx.clip();

  const domeSky = ctx.createRadialGradient(
    globeCx,
    globeCy - 10 * scale,
    12 * scale,
    globeCx,
    globeCy,
    globeR
  );
  domeSky.addColorStop(0, '#0ea5e9');
  domeSky.addColorStop(0.45, '#0369a1');
  domeSky.addColorStop(1, '#031226');
  ctx.fillStyle = domeSky;
  ctx.fillRect(globeCx - globeR, globeCy - globeR, globeR * 2, globeR * 2);

  const horizonY = globeCy + 44 * scale;

  // Illuminated Winter Ferris Wheel inside the Snow Globe
  const wheelCx = globeCx - 18 * scale;
  const wheelCy = horizonY - 64 * scale;
  const wheelR = 54 * scale;

  ctx.strokeStyle = 'rgba(240, 249, 255, 0.88)';
  ctx.lineWidth = 1.6 * scale;
  ctx.beginPath();
  ctx.arc(wheelCx, wheelCy, wheelR, 0, Math.PI * 2);
  ctx.stroke();

  ctx.beginPath();
  ctx.arc(wheelCx, wheelCy, wheelR * 0.72, 0, Math.PI * 2);
  ctx.stroke();

  for (let i = 0; i < 14; i++) {
    const angle = (i * Math.PI * 2) / 14;
    const gx = wheelCx + Math.cos(angle) * wheelR;
    const gy = wheelCy + Math.sin(angle) * wheelR;
    ctx.strokeStyle = 'rgba(224, 242, 254, 0.75)';
    ctx.lineWidth = 1 * scale;
    ctx.beginPath();
    ctx.moveTo(wheelCx, wheelCy);
    ctx.lineTo(gx, gy);
    ctx.stroke();

    ctx.fillStyle = '#fde047';
    ctx.beginPath();
    ctx.arc(gx, gy, 2.8 * scale, 0, Math.PI * 2);
    ctx.fill();
  }

  ctx.fillStyle = '#fef08a';
  ctx.beginPath();
  ctx.arc(wheelCx, wheelCy, 5 * scale, 0, Math.PI * 2);
  ctx.fill();

  // Snow-covered pine trees on left & right of globe interior
  [
    { dx: -94, w: 38, h: 68 },
    { dx: -72, w: 42, h: 78 },
    { dx: 74, w: 42, h: 78 },
    { dx: 96, w: 36, h: 66 },
  ].forEach((t) => {
    const tx = globeCx + t.dx * scale;
    const ty = horizonY + 4 * scale;
    const tw = t.w * scale;
    const th = t.h * scale;
    ctx.fillStyle = '#0c2e33';
    ctx.beginPath();
    ctx.moveTo(tx - tw / 2, ty);
    ctx.lineTo(tx, ty - th);
    ctx.lineTo(tx + tw / 2, ty);
    ctx.closePath();
    ctx.fill();

    ctx.fillStyle = '#e0f2fe';
    ctx.beginPath();
    ctx.moveTo(tx - tw * 0.36, ty - th * 0.38);
    ctx.lineTo(tx, ty - th);
    ctx.lineTo(tx + tw * 0.36, ty - th * 0.38);
    ctx.closePath();
    ctx.fill();
  });

  // Warm-Lit Alpine Palace Towers & Cottages inside globe
  const drawMiniVillageTower = (dx: number, w: number, h: number, roofH: number) => {
    const bx = globeCx + dx * scale;
    const bw = w * scale;
    const bh = h * scale;
    const br = roofH * scale;
    const topY = horizonY - bh;

    const wallGrad = ctx.createLinearGradient(bx - bw / 2, topY, bx + bw / 2, horizonY);
    wallGrad.addColorStop(0, '#f8fafc');
    wallGrad.addColorStop(0.5, '#fed7aa');
    wallGrad.addColorStop(1, '#fb923c');
    ctx.fillStyle = wallGrad;
    ctx.strokeStyle = '#e0f2fe';
    ctx.lineWidth = 1.1 * scale;
    ctx.beginPath();
    ctx.rect(bx - bw / 2, topY, bw, bh);
    ctx.fill();
    ctx.stroke();

    ctx.fillStyle = '#38bdf8';
    ctx.beginPath();
    ctx.moveTo(bx - bw / 2 - 3 * scale, topY);
    ctx.lineTo(bx, topY - br);
    ctx.lineTo(bx + bw / 2 + 3 * scale, topY);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();

    // Glowing golden windows
    ctx.fillStyle = '#fef08a';
    ctx.beginPath();
    ctx.roundRect(
      bx - 3.5 * scale,
      horizonY - bh * 0.68,
      7 * scale,
      12 * scale,
      3 * scale
    );
    ctx.roundRect(
      bx - 4.5 * scale,
      horizonY - 18 * scale,
      9 * scale,
      16 * scale,
      4 * scale
    );
    ctx.fill();
  };

  drawMiniVillageTower(-44, 24, 24, 12);
  drawMiniVillageTower(-20, 20, 44, 18);
  drawMiniVillageTower(4, 30, 40, 14);
  drawMiniVillageTower(26, 22, 66, 22);
  drawMiniVillageTower(48, 28, 82, 24);

  // Luminous cyan-blue snowbowl base inside globe
  const bowlGrad = ctx.createLinearGradient(
    globeCx,
    horizonY - 4 * scale,
    globeCx,
    globeCy + globeR
  );
  bowlGrad.addColorStop(0, '#ffffff');
  bowlGrad.addColorStop(0.22, '#bae6fd');
  bowlGrad.addColorStop(0.55, '#0ea5e9');
  bowlGrad.addColorStop(1, '#082f49');
  ctx.fillStyle = bowlGrad;
  ctx.fillRect(
    globeCx - globeR,
    horizonY,
    globeR * 2,
    globeR
  );

  // Swirling snow particles inside globe
  for (let s = 0; s < 55; s++) {
    const angle = s * 1.7;
    const dist = ((s * 19) % 130) * scale;
    const sx = globeCx + Math.cos(angle) * dist;
    const sy = globeCy + Math.sin(angle * 1.3) * dist * 0.85;
    ctx.fillStyle = s % 5 === 0 ? '#fef08a' : '#ffffff';
    ctx.beginPath();
    ctx.arc(sx, sy, ((s % 3) + 1.5) * scale, 0, Math.PI * 2);
    ctx.fill();
  }

  // Thick crescent glass highlight arc
  ctx.strokeStyle = 'rgba(255, 255, 255, 0.5)';
  ctx.lineWidth = 5 * scale;
  ctx.lineCap = 'round';
  ctx.beginPath();
  ctx.arc(globeCx, globeCy, globeR - 10 * scale, Math.PI * 1.05, Math.PI * 1.45);
  ctx.stroke();
  ctx.restore();

  // Outer crystal rim of globe
  ctx.strokeStyle = 'rgba(224, 242, 254, 0.75)';
  ctx.lineWidth = 2.5 * scale;
  ctx.beginPath();
  ctx.arc(globeCx, globeCy, globeR, 0, Math.PI * 2);
  ctx.stroke();

  // Ornate Midnight-Blue Porcelain & Gold Filigree Pedestal Base
  const neckY = globeCy + globeR - 12 * scale;
  const baseBottomY = neckY + 66 * scale;
  const pedGrad = ctx.createLinearGradient(
    globeCx - 130 * scale,
    neckY,
    globeCx + 130 * scale,
    baseBottomY
  );
  pedGrad.addColorStop(0, '#040b1c');
  pedGrad.addColorStop(0.3, '#0c2147');
  pedGrad.addColorStop(0.5, '#1d4ed8');
  pedGrad.addColorStop(0.75, '#0c2147');
  pedGrad.addColorStop(1, '#020617');
  ctx.fillStyle = pedGrad;
  ctx.strokeStyle = '#fbbf24';
  ctx.lineWidth = 1.8 * scale;
  ctx.beginPath();
  ctx.moveTo(globeCx - 104 * scale, neckY);
  ctx.quadraticCurveTo(globeCx, neckY + 10 * scale, globeCx + 104 * scale, neckY);
  ctx.lineTo(globeCx + 132 * scale, baseBottomY);
  ctx.quadraticCurveTo(globeCx, baseBottomY + 14 * scale, globeCx - 132 * scale, baseBottomY);
  ctx.closePath();
  ctx.fill();
  ctx.stroke();

  // Gold filigree vine scroll & nameplate text on pedestal
  ctx.textAlign = 'center';
  ctx.fillStyle = '#fde68a';
  ctx.font = `700 ${Math.round(13 * scale)}px "Plus Jakarta Sans", sans-serif`;
  ctx.fillText(
    `✦ FROST & WONDER · ${countdown.targetYear} ✦`,
    globeCx,
    neckY + 40 * scale
  );

  // 7. RIGHT COLUMN OF CONSOLE: DECEMBER 25, 2026 DEADLINE & COUNTDOWN SNAPSHOT
  const rightX = panelX + 510 * scale;
  const rightW = panelW - 565 * scale;

  ctx.textAlign = 'left';
  ctx.fillStyle = '#7dd3fc';
  ctx.font = `700 ${Math.round(20 * scale)}px "Plus Jakarta Sans", sans-serif`;
  ctx.fillText(
    '✨ THE MAGIC OF CHRISTMAS IS ALMOST HERE · TARGET DEADLINE: DECEMBER 25, 2026',
    rightX,
    panelY + 66 * scale
  );

  ctx.fillStyle = '#ffffff';
  ctx.font = `700 ${Math.round(52 * scale)}px "Cormorant Garamond", Georgia, serif`;
  ctx.fillText(
    `Frost & Wonder Christmas Countdown · Dec 25, ${countdown.targetYear}`,
    rightX,
    panelY + 126 * scale
  );

  const exportDateStr = now.toLocaleDateString('en-US', {
    month: 'short',
    day: 'numeric',
    year: 'numeric',
  });
  ctx.fillStyle = 'rgba(253, 230, 138, 0.92)';
  ctx.font = `500 ${Math.round(18 * scale)}px "Plus Jakarta Sans", sans-serif`;
  ctx.fillText(
    `Lock-Screen Countdown Snapshot (Exported ${exportDateStr}) · Live Dynamic Timer Active in App & Mac Widget`,
    rightX,
    panelY + 162 * scale
  );

  // 4 High-Contrast Tabular Countdown Cards
  const cards = [
    {
      value: String(countdown.days).padStart(2, '0'),
      label: 'DAYS REMAINING',
      sub: 'Until Dec 25, 2026',
      accent: '#38bdf8',
    },
    {
      value: String(countdown.hours).padStart(2, '0'),
      label: 'HOURS',
      sub: 'Snapshot Value',
      accent: '#a78bfa',
    },
    {
      value: String(countdown.minutes).padStart(2, '0'),
      label: 'MINUTES',
      sub: `Stage ${countdown.magicIntensity}/5 Glow`,
      accent: '#38bdf8',
    },
    {
      value: 'DEC 25',
      label: `${countdown.targetYear} DEADLINE`,
      sub: `${countdown.seasonProgressPercent}% Season Complete`,
      accent: '#fde047',
    },
  ];

  const cardGap = 24 * scale;
  const cardW = (rightW - cardGap * 3) / 4;
  const cardY = panelY + 190 * scale;
  const cardH = 178 * scale;

  cards.forEach((c, idx) => {
    const cxCard = rightX + idx * (cardW + cardGap);
    ctx.fillStyle = 'rgba(15, 23, 42, 0.88)';
    ctx.strokeStyle =
      idx === 3 ? 'rgba(253, 224, 71, 0.55)' : 'rgba(125, 211, 252, 0.32)';
    ctx.lineWidth = 2 * scale;
    ctx.beginPath();
    ctx.roundRect(cxCard, cardY, cardW, cardH, 22 * scale);
    ctx.fill();
    ctx.stroke();

    ctx.textAlign = 'center';
    ctx.fillStyle = idx === 3 ? '#fef08a' : '#ffffff';
    ctx.font = `700 ${Math.round(64 * scale)}px "JetBrains Mono", monospace`;
    ctx.fillText(c.value, cxCard + cardW / 2, cardY + 84 * scale);

    ctx.fillStyle = c.accent;
    ctx.font = `700 ${Math.round(16 * scale)}px "Plus Jakarta Sans", sans-serif`;
    ctx.fillText(c.label, cxCard + cardW / 2, cardY + 122 * scale);

    ctx.fillStyle = 'rgba(203, 213, 225, 0.9)';
    ctx.font = `500 ${Math.round(15 * scale)}px "Plus Jakarta Sans", sans-serif`;
    ctx.fillText(c.sub, cxCard + cardW / 2, cardY + 152 * scale);
  });

  // 8. BOTTOM ROW OF CONSOLE: 3 OR 4 CHRONOLOGICAL CHRISTMAS PREPARATION MILESTONES
  const chronologicalMilestones = getChronologicalLockScreenMilestones(
    milestones,
    countdown.targetYear,
    milestoneCount
  );

  const msSectionY = panelY + 412 * scale;

  ctx.textAlign = 'left';
  ctx.fillStyle = '#fde68a';
  ctx.font = `700 ${Math.round(19 * scale)}px "Plus Jakarta Sans", sans-serif`;
  ctx.fillText(
    `CHRONOLOGICAL CHRISTMAS MILESTONE COUNTDOWNS (${chronologicalMilestones.length} KEY STEPS TO DECEMBER 25, ${countdown.targetYear})`,
    panelX + 52 * scale,
    msSectionY
  );

  const msCardY = msSectionY + 24 * scale;
  const msCardH = 268 * scale;
  const msTotalW = panelW - 104 * scale;
  const msGap = 20 * scale;
  const msCount = Math.max(1, chronologicalMilestones.length);
  const msCardW = (msTotalW - msGap * (msCount - 1)) / msCount;

  chronologicalMilestones.forEach((ms, index) => {
    const mx = panelX + 52 * scale + index * (msCardW + msGap);
    const rem = calculateMilestoneTimeRemaining(ms.targetDate, now);
    const parsedDate = new Date(ms.targetDate);
    const dateBadge = Number.isNaN(parsedDate.getTime())
      ? 'Dec 2026'
      : parsedDate.toLocaleDateString('en-US', {
          month: 'short',
          day: 'numeric',
        });

    ctx.fillStyle = ms.completed
      ? 'rgba(6, 46, 38, 0.78)'
      : 'rgba(15, 23, 42, 0.9)';
    ctx.strokeStyle = ms.completed
      ? 'rgba(52, 211, 153, 0.55)'
      : 'rgba(125, 211, 252, 0.34)';
    ctx.lineWidth = 2 * scale;
    ctx.beginPath();
    ctx.roundRect(mx, msCardY, msCardW, msCardH, 22 * scale);
    ctx.fill();
    ctx.stroke();

    ctx.textAlign = 'left';
    ctx.fillStyle = '#7dd3fc';
    ctx.font = `700 ${Math.round(16 * scale)}px "JetBrains Mono", monospace`;
    ctx.fillText(
      `STEP 0${index + 1} · ${dateBadge.toUpperCase()}`,
      mx + 22 * scale,
      msCardY + 42 * scale
    );

    ctx.textAlign = 'right';
    ctx.fillStyle = ms.completed ? '#6ee7b7' : '#fde047';
    ctx.font = `700 ${Math.round(15 * scale)}px "JetBrains Mono", monospace`;
    ctx.fillText(
      ms.completed ? '✓ COMPLETED' : rem.formattedLabel.toUpperCase(),
      mx + msCardW - 22 * scale,
      msCardY + 42 * scale
    );

    ctx.strokeStyle = 'rgba(148, 163, 184, 0.22)';
    ctx.lineWidth = 1 * scale;
    ctx.beginPath();
    ctx.moveTo(mx + 22 * scale, msCardY + 60 * scale);
    ctx.lineTo(mx + msCardW - 22 * scale, msCardY + 60 * scale);
    ctx.stroke();

    ctx.textAlign = 'left';
    ctx.fillStyle = 'rgba(196, 181, 253, 0.95)';
    ctx.font = `600 ${Math.round(15 * scale)}px "Plus Jakarta Sans", sans-serif`;
    ctx.fillText(ms.category.toUpperCase(), mx + 22 * scale, msCardY + 92 * scale);

    ctx.fillStyle = '#ffffff';
    ctx.font = `700 ${Math.round(25 * scale)}px "Cormorant Garamond", Georgia, serif`;
    const words = ms.title.split(' ');
    let line1 = '';
    let line2 = '';
    for (const word of words) {
      const testLine = line1 ? `${line1} ${word}` : word;
      if (ctx.measureText(testLine).width < msCardW - 44 * scale) {
        line1 = testLine;
      } else {
        line2 = line2 ? `${line2} ${word}` : word;
      }
    }
    ctx.fillText(line1, mx + 22 * scale, msCardY + 132 * scale);
    if (line2) {
      ctx.fillText(line2, mx + 22 * scale, msCardY + 162 * scale);
    }

    const rawNote =
      ms.notes || 'Scheduled Christmas preparation checkpoint.';
    const shortNote =
      rawNote.length > 54 ? `${rawNote.slice(0, 51)}...` : rawNote;
    ctx.fillStyle = 'rgba(203, 213, 225, 0.85)';
    ctx.font = `400 ${Math.round(15 * scale)}px "Plus Jakarta Sans", sans-serif`;
    ctx.fillText(shortNote, mx + 22 * scale, msCardY + 232 * scale);
  });

  ctx.restore();
}
