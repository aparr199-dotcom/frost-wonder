import React, { useEffect } from 'react';
import { Minimize2, Sparkles, Volume2, VolumeX } from 'lucide-react';
import { CountdownState, HolidayMilestone } from '../types/holiday';
import { GENERATED_ASSETS } from '../data/seedData';
import { FESTIVE_MESSAGES } from '../utils/holidayLogic';

interface ScreenSaverModalProps {
  isOpen: boolean;
  onClose: () => void;
  countdown: CountdownState;
  nextMilestone?: HolidayMilestone;
  isMusicPlaying: boolean;
  onToggleMusic: () => void;
}

export const ScreenSaverModal: React.FC<ScreenSaverModalProps> = ({
  isOpen,
  onClose,
  countdown,
  nextMilestone,
  isMusicPlaying,
  onToggleMusic,
}) => {
  useEffect(() => {
    if (!isOpen) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const handleEnterBrowserFullscreen = () => {
    if (document.fullscreenElement) {
      document.exitFullscreen().catch(() => {});
    } else {
      document.documentElement.requestFullscreen?.().catch(() => {});
    }
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="Animated Christmas Screen Saver and Full-Screen Holiday Display"
      className="fixed inset-0 z-50 flex flex-col justify-between overflow-hidden bg-[#050b1a] p-6 sm:p-12"
    >
      {/* Background Ice Palace & Aurora */}
      <div className="absolute inset-0">
        <img
          src={GENERATED_ASSETS.heroIcePalace}
          alt="Enchanted Ice Palace Screen Saver Background"
          referrerPolicy="no-referrer"
          className="h-full w-full object-cover opacity-60"
          onError={(e) => {
            e.currentTarget.style.display = 'none';
          }}
        />
        <div className="absolute inset-0 bg-gradient-to-t from-[#050b1a] via-[#050b1a]/55 to-[#050b1a]/80" />
        <div className="animate-aurora pointer-events-none absolute left-1/4 top-12 h-96 w-1/2 rounded-full bg-gradient-to-r from-sky-400/25 via-purple-400/25 to-amber-300/20 blur-3xl" />
      </div>

      {/* Top Bar */}
      <div className="relative z-10 flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-2 text-xs text-sky-200">
          <Sparkles className="h-4 w-4 text-amber-300" />
          <span>
            Frost &amp; Wonder Ambient Screen Saver Display (Distinct from macOS System Lock Screen)
          </span>
        </div>

        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={onToggleMusic}
            className="inline-flex items-center gap-1.5 rounded-xl border border-sky-200/25 bg-slate-950/75 px-3.5 py-2 text-xs font-medium text-sky-100 hover:bg-slate-900"
          >
            {isMusicPlaying ? (
              <>
                <Volume2 className="h-3.5 w-3.5 text-amber-300" />
                Celesta Audio On
              </>
            ) : (
              <>
                <VolumeX className="h-3.5 w-3.5 text-slate-400" />
                Play Celesta Audio
              </>
            )}
          </button>

          <button
            type="button"
            onClick={handleEnterBrowserFullscreen}
            className="rounded-xl border border-sky-200/25 bg-slate-950/75 px-3.5 py-2 text-xs font-medium text-slate-200 hover:bg-slate-900"
          >
            Toggle OS Fullscreen
          </button>

          <button
            type="button"
            onClick={onClose}
            className="inline-flex items-center gap-1.5 rounded-xl bg-sky-300 px-4 py-2 text-xs font-semibold text-slate-950 hover:bg-sky-200"
          >
            <Minimize2 className="h-3.5 w-3.5" />
            Exit Screen Saver
          </button>
        </div>
      </div>

      {/* Centerpiece Ambient Countdown */}
      <div className="relative z-10 my-auto mx-auto max-w-4xl text-center">
        <p className="text-base font-medium tracking-wide text-sky-200 sm:text-xl">
          {countdown.isChristmasMorning
            ? '🎄 Merry Christmas! The Magic Has Arrived!'
            : '✨ The Magic of Christmas Is Almost Here ✨'}
        </p>

        <h2 className="font-serif-display mt-3 text-5xl font-semibold text-white sm:text-7xl">
          {countdown.isChristmasMorning
            ? 'Joy to the Winter Kingdom'
            : `Christmas ${countdown.targetYear}`}
        </h2>

        <div className="mt-10 grid grid-cols-2 gap-4 sm:grid-cols-4 sm:gap-6">
          {[
            { label: 'DAYS', value: countdown.days },
            { label: 'HOURS', value: countdown.hours },
            { label: 'MINUTES', value: countdown.minutes },
            { label: 'SECONDS', value: countdown.seconds },
          ].map((u) => (
            <div
              key={u.label}
              className="rounded-3xl border border-sky-200/25 bg-slate-950/70 px-6 py-8 backdrop-blur-2xl"
            >
              <div className="font-mono-tabular text-5xl font-bold text-white sm:text-7xl">
                {String(u.value).padStart(2, '0')}
              </div>
              <div className="mt-2 text-xs font-semibold tracking-widest text-amber-200">
                {u.label}
              </div>
            </div>
          ))}
        </div>

        <p className="font-serif-display mx-auto mt-8 max-w-2xl text-xl italic text-slate-200 sm:text-2xl">
          “{FESTIVE_MESSAGES[0]}”
        </p>
      </div>

      {/* Bottom Ambient Footer */}
      <div className="relative z-10 flex flex-wrap items-center justify-between gap-4 border-t border-white/10 pt-4 text-xs text-slate-300">
        <div>
          {nextMilestone ? (
            <span>
              Next Family Milestone:{' '}
              <strong className="text-sky-200">{nextMilestone.title}</strong>
            </span>
          ) : (
            <span>All Season Milestones Complete</span>
          )}
        </div>
        <div>Press ESC or click Exit Screen Saver to return to workspace</div>
      </div>
    </div>
  );
};
