import React, { useEffect, useState } from 'react';
import {
  ChevronLeft,
  ChevronRight,
  Database,
  Edit3,
  Eye,
  EyeOff,
  ExternalLink,
  Gift,
  Plus,
  Search,
  ShieldCheck,
  Sparkles,
  Trash2,
  UserPlus,
} from 'lucide-react';
import {
  ChildProfile,
  GIFT_STAGES,
  GiftCategory,
  GiftItem,
  GiftPriority,
  GiftStage,
} from '../types/holiday';
import {
  calculateChildGiftStats,
  formatSecretSantaGift,
  getAdjacentGiftStage,
} from '../utils/holidayLogic';
import { AVATAR_METADATA } from '../data/seedData';

interface FamilyGiftManagerProps {
  childrenProfiles: ChildProfile[];
  gifts: GiftItem[];
  secretSantaMode: boolean;
  onToggleSecretSanta: () => void;
  onAddChild: (child: Omit<ChildProfile, 'id'>) => void;
  onUpdateChild: (child: ChildProfile) => void;
  onDeleteChild: (id: string) => void;
  onAddGift: (gift: Omit<GiftItem, 'id'>) => void;
  onUpdateGift: (gift: GiftItem) => void;
  onDeleteGift: (id: string) => void;
  onOpenVaultBackup?: () => void;
  onStartJudgeDemo?: () => void;
}

const GIFT_CATEGORIES: GiftCategory[] = [
  'Toys & Games',
  'Books & Learning',
  'Tech & Electronics',
  'Winter Apparel',
  'Creative & Arts',
  'Outdoor & Sports',
  'Keepsake & Magic',
  'Family Shared',
];

export const FamilyGiftManager: React.FC<FamilyGiftManagerProps> = ({
  childrenProfiles,
  gifts,
  secretSantaMode,
  onToggleSecretSanta,
  onAddChild,
  onUpdateChild,
  onDeleteChild,
  onAddGift,
  onUpdateGift,
  onDeleteGift,
  onOpenVaultBackup,
  onStartJudgeDemo,
}) => {
  const [selectedChildId, setSelectedChildId] = useState<string>(
    childrenProfiles[0]?.id || 'all'
  );
  const [stageFilter, setStageFilter] = useState<GiftStage | 'ALL'>('ALL');
  const [stockingFilter, setStockingFilter] = useState<
    'all' | 'under-tree' | 'stocking'
  >('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [confirmDeleteChild, setConfirmDeleteChild] = useState(false);
  const [confirmDeleteGiftId, setConfirmDeleteGiftId] = useState<string | null>(
    null
  );

  useEffect(() => {
    if (childrenProfiles.length === 0) {
      if (selectedChildId !== 'all') setSelectedChildId('all');
      return;
    }
    if (
      selectedChildId !== 'all' &&
      !childrenProfiles.some((c) => c.id === selectedChildId)
    ) {
      setSelectedChildId(childrenProfiles[0].id);
    }
  }, [childrenProfiles, selectedChildId]);

  // Child Modal State
  const [showChildModal, setShowChildModal] = useState(false);
  const [editingChild, setEditingChild] = useState<ChildProfile | null>(null);
  const [childName, setChildName] = useState('');
  const [childNickname, setChildNickname] = useState('');
  const [childAvatar, setChildAvatar] = useState<
    'owl' | 'fox' | 'stag' | 'penguin'
  >('owl');
  const [childBudget, setChildBudget] = useState('450');
  const [childWishlistText, setChildWishlistText] = useState('');
  const [childFormError, setChildFormError] = useState('');

  // Quick Wishlist Input
  const [newWishItem, setNewWishItem] = useState('');

  // Gift Modal State
  const [showGiftModal, setShowGiftModal] = useState(false);
  const [editingGift, setEditingGift] = useState<GiftItem | null>(null);
  const [giftChildId, setGiftChildId] = useState<string>(
    childrenProfiles[0]?.id || 'household'
  );
  const [giftName, setGiftName] = useState('');
  const [giftCategory, setGiftCategory] =
    useState<GiftCategory>('Toys & Games');
  const [giftStore, setGiftStore] = useState('');
  const [giftEstimated, setGiftEstimated] = useState('50');
  const [giftActual, setGiftActual] = useState('0');
  const [giftPriority, setGiftPriority] = useState<GiftPriority>('High');
  const [giftPurchaseDate, setGiftPurchaseDate] = useState('');
  const [giftDeliveryDate, setGiftDeliveryDate] = useState('');
  const [giftNotes, setGiftNotes] = useState('');
  const [giftStatus, setGiftStatus] = useState<GiftStage>('PLANNED');
  const [giftStocking, setGiftStocking] = useState(false);
  const [giftPhotoUrl, setGiftPhotoUrl] = useState('');
  const [giftFormError, setGiftFormError] = useState('');

  const activeChild = childrenProfiles.find((c) => c.id === selectedChildId);
  const activeChildStats = activeChild
    ? calculateChildGiftStats(activeChild, gifts)
    : null;

  // Open Add Child
  const handleOpenAddChild = () => {
    setEditingChild(null);
    setChildName('');
    setChildNickname('');
    setChildAvatar('owl');
    setChildBudget('400');
    setChildWishlistText('');
    setChildFormError('');
    setConfirmDeleteChild(false);
    setShowChildModal(true);
  };

  // Open Edit Child
  const handleOpenEditChild = (child: ChildProfile) => {
    setEditingChild(child);
    setChildName(child.name);
    setChildNickname(child.nickname);
    setChildAvatar(child.avatarId);
    setChildBudget(String(child.budget));
    setChildWishlistText(child.wishlistNotes.join('\n'));
    setChildFormError('');
    setConfirmDeleteChild(false);
    setShowChildModal(true);
  };

  const handleSaveChild = (e: React.FormEvent) => {
    e.preventDefault();
    if (!childName.trim()) {
      setChildFormError('Please enter a name for the profile.');
      return;
    }
    const parsedBudget = Number(childBudget);
    if (Number.isNaN(parsedBudget) || parsedBudget < 0) {
      setChildFormError('Please enter a valid positive budget.');
      return;
    }

    const wishlistNotes = childWishlistText
      .split('\n')
      .map((line) => line.trim())
      .filter(Boolean);

    if (editingChild) {
      onUpdateChild({
        ...editingChild,
        name: childName.trim(),
        nickname: childNickname.trim() || 'Winter Star',
        avatarId: childAvatar,
        budget: parsedBudget,
        wishlistNotes,
      });
    } else {
      onAddChild({
        name: childName.trim(),
        nickname: childNickname.trim() || 'Winter Explorer',
        avatarId: childAvatar,
        budget: parsedBudget,
        wishlistNotes,
      });
    }

    setShowChildModal(false);
  };

  const handleAddWishlistNote = (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeChild || !newWishItem.trim()) return;
    onUpdateChild({
      ...activeChild,
      wishlistNotes: [...activeChild.wishlistNotes, newWishItem.trim()],
    });
    setNewWishItem('');
  };

  const handleRemoveWishlistNote = (idx: number) => {
    if (!activeChild) return;
    onUpdateChild({
      ...activeChild,
      wishlistNotes: activeChild.wishlistNotes.filter((_, i) => i !== idx),
    });
  };

  const handleConvertWishToGift = (wishText: string) => {
    if (!activeChild) return;
    onAddGift({
      childId: activeChild.id,
      name: wishText,
      category: 'Keepsake & Magic',
      storeOrLink: '',
      estimatedPrice: 45,
      actualSpent: 0,
      priority: 'High',
      purchaseDate: '',
      expectedDeliveryDate: '',
      notes: 'Converted from personalized Christmas wishlist.',
      status: 'WISH LIST',
      isStockingStuffer: false,
    });
  };

  // Gift Modal Handlers
  const handleOpenAddGift = (defaultChildId?: string) => {
    setEditingGift(null);
    setGiftChildId(
      defaultChildId && defaultChildId !== 'all'
        ? defaultChildId
        : childrenProfiles[0]?.id || 'household'
    );
    setGiftName('');
    setGiftCategory('Toys & Games');
    setGiftStore('');
    setGiftEstimated('60');
    setGiftActual('0');
    setGiftPriority('High');
    setGiftPurchaseDate('');
    setGiftDeliveryDate('');
    setGiftNotes('');
    setGiftStatus('PLANNED');
    setGiftStocking(false);
    setGiftPhotoUrl('');
    setGiftFormError('');
    setShowGiftModal(true);
  };

  const handleOpenEditGift = (gift: GiftItem) => {
    setEditingGift(gift);
    setGiftChildId(gift.childId);
    setGiftName(gift.name);
    setGiftCategory(gift.category);
    setGiftStore(gift.storeOrLink);
    setGiftEstimated(String(gift.estimatedPrice));
    setGiftActual(String(gift.actualSpent));
    setGiftPriority(gift.priority);
    setGiftPurchaseDate(gift.purchaseDate);
    setGiftDeliveryDate(gift.expectedDeliveryDate);
    setGiftNotes(gift.notes);
    setGiftStatus(gift.status);
    setGiftStocking(gift.isStockingStuffer);
    setGiftPhotoUrl(gift.photoUrl || '');
    setGiftFormError('');
    setShowGiftModal(true);
  };

  const handleSaveGift = (e: React.FormEvent) => {
    e.preventDefault();
    if (!giftName.trim()) {
      setGiftFormError('Please enter a gift name.');
      return;
    }
    const est = Number(giftEstimated);
    const act = Number(giftActual);
    if (Number.isNaN(est) || est < 0 || Number.isNaN(act) || act < 0) {
      setGiftFormError('Prices must be valid non-negative numbers.');
      return;
    }

    const payload: Omit<GiftItem, 'id'> = {
      childId: giftChildId,
      name: giftName.trim(),
      category: giftCategory,
      storeOrLink: giftStore.trim(),
      estimatedPrice: est,
      actualSpent: act,
      priority: giftPriority,
      purchaseDate: giftPurchaseDate,
      expectedDeliveryDate: giftDeliveryDate,
      notes: giftNotes.trim(),
      status: giftStatus,
      isStockingStuffer: giftStocking,
      photoUrl: giftPhotoUrl.trim() || undefined,
    };

    if (editingGift) {
      onUpdateGift({
        ...payload,
        id: editingGift.id,
      });
    } else {
      onAddGift(payload);
    }

    setShowGiftModal(false);
  };

  const handleStepGiftStage = (gift: GiftItem, direction: 'next' | 'prev') => {
    const nextStage = getAdjacentGiftStage(gift.status, direction);
    const updatedActual =
      nextStage === 'PURCHASED' && gift.actualSpent === 0
        ? gift.estimatedPrice
        : gift.actualSpent;
    onUpdateGift({
      ...gift,
      status: nextStage,
      actualSpent: updatedActual,
    });
  };

  // Filtered Gifts
  const visibleGifts = gifts.filter((g) => {
    if (selectedChildId !== 'all' && g.childId !== selectedChildId) {
      return false;
    }
    if (stageFilter !== 'ALL' && g.status !== stageFilter) {
      return false;
    }
    if (stockingFilter === 'stocking' && !g.isStockingStuffer) {
      return false;
    }
    if (stockingFilter === 'under-tree' && g.isStockingStuffer) {
      return false;
    }
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      return (
        g.name.toLowerCase().includes(q) ||
        g.category.toLowerCase().includes(q) ||
        g.storeOrLink.toLowerCase().includes(q)
      );
    }
    return true;
  });

  return (
    <div className="space-y-8">
      {/* Header & Secret Santa Cloak Control */}
      <div className="flex flex-col justify-between gap-4 border-b border-sky-200/15 pb-6 lg:flex-row lg:items-center">
        <div>
          <p className="text-xs font-medium text-sky-300">
            North Pole Workshop &amp; Profiles
          </p>
          <h1 className="font-serif-display mt-1 text-3xl font-semibold text-white sm:text-4xl">
            Family Gift Manager
          </h1>
          <p className="mt-1 text-sm text-slate-300">
            Curate personalized wishlists, track every parcel from wishlist to wrapping paper, and safeguard surprises.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <button
            type="button"
            onClick={onToggleSecretSanta}
            aria-pressed={secretSantaMode}
            className={`inline-flex items-center gap-2 rounded-xl border px-4 py-2.5 text-xs font-semibold transition whitespace-nowrap shrink-0 ${
              secretSantaMode
                ? 'border-amber-300 bg-amber-300 text-slate-950'
                : 'border-sky-200/30 bg-slate-900/80 text-sky-100 hover:bg-slate-800'
            }`}
          >
            {secretSantaMode ? (
              <>
                <EyeOff className="h-4 w-4" />
                Secret Santa Mode Active (Spoilers Hidden)
              </>
            ) : (
              <>
                <Eye className="h-4 w-4" />
                Activate Secret Santa Mode
              </>
            )}
          </button>

          <button
            type="button"
            onClick={handleOpenAddChild}
            className="inline-flex items-center gap-2 rounded-xl border border-sky-200/30 bg-slate-900/80 px-4 py-2.5 text-xs font-medium text-slate-100 transition hover:bg-slate-800 whitespace-nowrap shrink-0"
          >
            <UserPlus className="h-4 w-4 text-sky-300" />
            Add Child Profile
          </button>

          <button
            type="button"
            onClick={() => handleOpenAddGift(selectedChildId)}
            className="inline-flex items-center gap-2 rounded-xl bg-sky-300 px-4 py-2.5 text-xs font-semibold text-slate-950 transition hover:bg-sky-200 whitespace-nowrap shrink-0"
          >
            <Plus className="h-4 w-4" />
            Add Gift Entry
          </button>
        </div>
      </div>

      {/* Welcoming Private Family Setup Banner when Vault starts empty */}
      {childrenProfiles.length === 0 && (
        <div
          data-testid="empty-family-welcome"
          className="rounded-3xl border border-sky-300/30 bg-gradient-to-br from-slate-900/95 via-[#0c1a3a]/90 to-slate-950/95 p-8 shadow-2xl backdrop-blur-xl"
        >
          <div className="mx-auto max-w-3xl text-center">
            <div className="mx-auto inline-flex items-center gap-2 rounded-full border border-emerald-400/30 bg-emerald-950/40 px-3.5 py-1 text-xs font-semibold text-emerald-200">
              <ShieldCheck className="h-3.5 w-3.5 text-emerald-300" />
              Clean Private Family Workspace · Zero Pre-Loaded Fictional Data
            </div>
            <h2 className="font-serif-display mt-3 text-3xl font-semibold text-white sm:text-4xl">
              Welcome to Your Private Family Gift Vault
            </h2>
            <p className="mt-2 text-sm leading-relaxed text-slate-300">
              Your personal workspace starts completely clean so fictional demo children and sample gifts never mix with your real family’s holiday plans. Add your first family member below, restore a saved JSON backup, or launch Handshake Judge Demo Mode to explore a fictional showcase family.
            </p>
            <div className="mt-6 flex flex-wrap items-center justify-center gap-3">
              <button
                type="button"
                onClick={handleOpenAddChild}
                className="inline-flex items-center gap-2 rounded-xl bg-sky-300 px-5 py-2.5 text-xs font-semibold text-slate-950 shadow-sm transition hover:bg-sky-200"
              >
                <UserPlus className="h-4 w-4" />
                Add First Child Profile
              </button>
              <button
                type="button"
                onClick={() => handleOpenAddGift('household')}
                className="inline-flex items-center gap-2 rounded-xl border border-sky-200/30 bg-slate-900/85 px-4 py-2.5 text-xs font-semibold text-sky-100 transition hover:bg-slate-800"
              >
                <Plus className="h-4 w-4 text-sky-300" />
                Add Shared Household Gift
              </button>
              {onOpenVaultBackup && (
                <button
                  type="button"
                  onClick={onOpenVaultBackup}
                  className="inline-flex items-center gap-2 rounded-xl border border-slate-700 bg-slate-900/85 px-4 py-2.5 text-xs font-medium text-slate-200 transition hover:bg-slate-800"
                >
                  <Database className="h-4 w-4 text-amber-300" />
                  Restore From Backup (.JSON)
                </button>
              )}
              {onStartJudgeDemo && (
                <button
                  type="button"
                  onClick={onStartJudgeDemo}
                  className="inline-flex items-center gap-2 rounded-xl border border-amber-300/40 bg-amber-300/15 px-4 py-2.5 text-xs font-semibold text-amber-100 transition hover:bg-amber-300/25"
                >
                  <Sparkles className="h-4 w-4 text-amber-300" />
                  Explore Fictional Family in Judge Demo
                </button>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Children Profile Selector Cards */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {childrenProfiles.map((child) => {
          const stats = calculateChildGiftStats(child, gifts);
          const avatar = AVATAR_METADATA[child.avatarId] || AVATAR_METADATA.owl;
          const isSelected = selectedChildId === child.id;

          return (
            <div
              key={child.id}
              onClick={() => setSelectedChildId(child.id)}
              role="button"
              tabIndex={0}
              onKeyDown={(e) => {
                if (e.key === 'Enter' || e.key === ' ') {
                  e.preventDefault();
                  setSelectedChildId(child.id);
                }
              }}
              className={`cursor-pointer rounded-2xl border p-5 transition backdrop-blur-md ${
                isSelected
                  ? 'border-sky-300 bg-slate-900/90 shadow-lg'
                  : 'border-sky-200/15 bg-slate-900/55 hover:border-sky-200/35'
              }`}
            >
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-center gap-3">
                  <div className="h-14 w-14 shrink-0 overflow-hidden rounded-2xl border border-sky-200/30 bg-slate-800">
                    <img
                      src={avatar.image}
                      alt={`${child.name} winter avatar`}
                      referrerPolicy="no-referrer"
                      className="h-full w-full object-cover"
                      onError={(e) => {
                        e.currentTarget.style.display = 'none';
                      }}
                    />
                  </div>
                  <div>
                    <h2 className="font-serif-display text-2xl font-semibold text-white">
                      {child.name}
                    </h2>
                    <p className="text-xs text-sky-200/90">{child.nickname}</p>
                  </div>
                </div>

                <button
                  type="button"
                  aria-label={`Edit profile for ${child.name}`}
                  onClick={(e) => {
                    e.stopPropagation();
                    handleOpenEditChild(child);
                  }}
                  className="rounded-lg p-1.5 text-slate-400 hover:bg-slate-800 hover:text-white"
                >
                  <Edit3 className="h-3.5 w-3.5" />
                </button>
              </div>

              {/* Financial & Gift Counts */}
              <div className="mt-4 grid grid-cols-2 gap-2 border-t border-slate-800 pt-3 text-xs">
                <div>
                  <span className="text-slate-400">Budget</span>
                  <div className="font-mono-tabular font-semibold text-white">
                    {secretSantaMode ? '$•••' : `$${child.budget.toFixed(0)}`}
                  </div>
                </div>
                <div>
                  <span className="text-slate-400">Remaining</span>
                  <div
                    className={`font-mono-tabular font-semibold ${
                      stats.availableBudget < 0
                        ? 'text-rose-300'
                        : 'text-emerald-300'
                    }`}
                  >
                    {secretSantaMode
                      ? '$•••'
                      : `$${stats.availableBudget.toFixed(0)}`}
                  </div>
                </div>
              </div>

              <div className="mt-3 flex items-center justify-between text-xs text-slate-300">
                <span>
                  Planned:{' '}
                  <strong className="font-mono-tabular text-white">
                    {stats.plannedCount}
                  </strong>
                </span>
                <span aria-hidden="true">·</span>
                <span>
                  Purchased:{' '}
                  <strong className="font-mono-tabular text-white">
                    {stats.purchasedOrBeyondCount}
                  </strong>
                </span>
                <span aria-hidden="true">·</span>
                <span>
                  Wrapped:{' '}
                  <strong className="font-mono-tabular text-white">
                    {stats.wrappedOrReadyCount}
                  </strong>
                </span>
              </div>

              {/* Visual Preparation Progress Bar */}
              <div className="mt-3">
                <div className="flex items-center justify-between text-xs">
                  <span className="text-slate-400">Christmas Readiness</span>
                  <span className="font-mono-tabular font-semibold text-sky-200">
                    {stats.readinessPercent}%
                  </span>
                </div>
                <div className="mt-1.5 h-2 w-full overflow-hidden rounded-full bg-slate-950">
                  <div
                    className="h-full rounded-full bg-gradient-to-r from-sky-400 via-indigo-300 to-amber-300 transition-all duration-300"
                    style={{ width: `${Math.min(100, stats.readinessPercent)}%` }}
                  />
                </div>
              </div>
            </div>
          );
        })}

        {/* View All / Household Card */}
        <div
          onClick={() => setSelectedChildId('all')}
          role="button"
          tabIndex={0}
          onKeyDown={(e) => {
            if (e.key === 'Enter' || e.key === ' ') {
              e.preventDefault();
              setSelectedChildId('all');
            }
          }}
          className={`flex cursor-pointer flex-col justify-between rounded-2xl border p-5 transition backdrop-blur-md ${
            selectedChildId === 'all'
              ? 'border-amber-300 bg-slate-900/90 shadow-lg'
              : 'border-sky-200/15 bg-slate-900/55 hover:border-sky-200/35'
          }`}
        >
          <div>
            <div className="flex items-center gap-2 text-xs font-medium text-amber-200">
              <Sparkles className="h-4 w-4" />
              <span>Entire Family &amp; Shared</span>
            </div>
            <h2 className="font-serif-display mt-2 text-2xl font-semibold text-white">
              All Family Gifts
            </h2>
            <p className="mt-1 text-xs text-slate-300">
              View all children’s parcels alongside shared household Christmas gifts.
            </p>
          </div>

          <div className="mt-4 border-t border-slate-800 pt-3 text-xs text-slate-300">
            <div className="flex items-center justify-between">
              <span>Total Tracked Gifts</span>
              <span className="font-mono-tabular font-semibold text-white">
                {gifts.length}
              </span>
            </div>
            <div className="mt-1 flex items-center justify-between">
              <span>Stocking Stuffers</span>
              <span className="font-mono-tabular font-semibold text-amber-200">
                {gifts.filter((g) => g.isStockingStuffer).length}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Selected Child Detail & Wishlist Drawer */}
      {activeChild && activeChildStats && (
        <div className="grid grid-cols-1 gap-6 rounded-2xl border border-sky-200/20 bg-slate-900/65 p-6 backdrop-blur-md lg:grid-cols-3">
          {/* Left: Child Preparation & Budget Summary */}
          <div className="space-y-4 lg:col-span-2">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div>
                <h3 className="font-serif-display text-2xl font-semibold text-white">
                  {activeChild.name}’s Christmas Preparation Tracker
                </h3>
                <p className="text-xs text-slate-300">
                  {activeChild.nickname} · Individual Budget:{' '}
                  <span className="font-mono-tabular text-white">
                    {secretSantaMode
                      ? '$•••.••'
                      : `$${activeChild.budget.toFixed(2)}`}
                  </span>
                </p>
              </div>
              <div className="text-right text-xs">
                <span className="text-slate-400">Confirmed Spent: </span>
                <strong className="font-mono-tabular text-sky-200">
                  {secretSantaMode
                    ? '$•••.••'
                    : `$${activeChildStats.confirmedSpent.toFixed(2)}`}
                </strong>
                <span className="mx-2 text-slate-600">·</span>
                <span className="text-slate-400">Est. Remaining: </span>
                <strong className="font-mono-tabular text-amber-200">
                  {secretSantaMode
                    ? '$•••.••'
                    : `$${activeChildStats.estimatedRemaining.toFixed(2)}`}
                </strong>
              </div>
            </div>

            {/* 7-Stage Pipeline Breakdown */}
            <div className="grid grid-cols-2 gap-2 sm:grid-cols-4 lg:grid-cols-7">
              {GIFT_STAGES.map((stage) => {
                const count = gifts.filter(
                  (g) => g.childId === activeChild.id && g.status === stage
                ).length;
                return (
                  <button
                    key={stage}
                    type="button"
                    onClick={() =>
                      setStageFilter(stageFilter === stage ? 'ALL' : stage)
                    }
                    className={`rounded-xl border p-2.5 text-left transition ${
                      stageFilter === stage
                        ? 'border-sky-300 bg-sky-400/20'
                        : 'border-slate-800 bg-slate-950/60 hover:border-slate-700'
                    }`}
                  >
                    <div className="font-mono-tabular text-lg font-semibold text-white">
                      {count}
                    </div>
                    <div className="mt-0.5 truncate text-[11px] font-medium text-slate-300">
                      {stage}
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Right: Personalized Christmas Wishlist */}
          <div className="border-t border-slate-800 pt-4 lg:border-l lg:border-t-0 lg:pl-6 lg:pt-0">
            <h4 className="font-serif-display text-lg font-semibold text-white">
              {activeChild.name}’s Personalized Wishlist
            </h4>
            <p className="text-xs text-slate-400">
              Click “Plan” on any wish to turn it into a tracked gift item.
            </p>

            <ul className="mt-3 space-y-2">
              {activeChild.wishlistNotes.map((wish, index) => (
                <li
                  key={`${wish}-${index}`}
                  className="flex items-center justify-between gap-2 rounded-xl border border-slate-800/90 bg-slate-950/60 px-3 py-2 text-xs"
                >
                  <span className="truncate text-slate-200">
                    {secretSantaMode ? '••••• Secret Wish Item •••••' : wish}
                  </span>
                  <div className="flex items-center gap-1.5 shrink-0">
                    <button
                      type="button"
                      onClick={() => handleConvertWishToGift(wish)}
                      className="rounded-md bg-sky-400/20 px-2 py-1 text-[11px] font-medium text-sky-200 hover:bg-sky-400/30"
                    >
                      Plan Gift
                    </button>
                    <button
                      type="button"
                      aria-label={`Remove wish ${wish}`}
                      onClick={() => handleRemoveWishlistNote(index)}
                      className="text-slate-500 hover:text-rose-300"
                    >
                      ×
                    </button>
                  </div>
                </li>
              ))}
            </ul>

            <form onSubmit={handleAddWishlistNote} className="mt-3 flex gap-2">
              <input
                type="text"
                aria-label="New wishlist idea"
                value={newWishItem}
                onChange={(e) => setNewWishItem(e.target.value)}
                placeholder="Add a wish idea..."
                className="w-full rounded-xl border border-slate-700 bg-slate-950 px-3 py-1.5 text-xs text-white placeholder:text-slate-500 focus:border-sky-400 focus:outline-none"
              />
              <button
                type="submit"
                className="rounded-xl bg-slate-800 px-3 py-1.5 text-xs font-medium text-sky-200 hover:bg-slate-700 whitespace-nowrap shrink-0"
              >
                Add Wish
              </button>
            </form>
          </div>
        </div>
      )}

      {/* Filter & Search Toolbar */}
      <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-center">
        <div className="relative flex-1 max-w-md">
          <Search className="pointer-events-none absolute left-3.5 top-2.5 h-4 w-4 text-slate-400" />
          <input
            type="search"
            aria-label="Search gifts by name, store, or category"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search gifts, stores, or categories..."
            className="w-full rounded-xl border border-slate-800 bg-slate-900/90 py-2 pl-10 pr-4 text-xs text-white placeholder:text-slate-400 focus:border-sky-400 focus:outline-none"
          />
        </div>

        <div className="flex flex-wrap items-center gap-3">
          {/* Stocking Stuffer Filter */}
          <div
            role="group"
            aria-label="Filter by stocking stuffers"
            className="flex items-center gap-1 rounded-xl border border-slate-800 bg-slate-900/90 p-1"
          >
            {(
              [
                { id: 'all', label: 'All Parcels' },
                { id: 'under-tree', label: 'Under the Tree' },
                { id: 'stocking', label: 'Stocking Stuffers' },
              ] as const
            ).map((item) => (
              <button
                key={item.id}
                type="button"
                onClick={() => setStockingFilter(item.id)}
                className={`rounded-lg px-3 py-1.5 text-xs font-medium transition whitespace-nowrap shrink-0 ${
                  stockingFilter === item.id
                    ? 'bg-sky-400/20 text-sky-100'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {item.label}
              </button>
            ))}
          </div>

          <select
            aria-label="Filter by gift stage"
            value={stageFilter}
            onChange={(e) =>
              setStageFilter(e.target.value as GiftStage | 'ALL')
            }
            className="rounded-xl border border-slate-800 bg-slate-900/90 px-3.5 py-2 text-xs text-slate-200 focus:border-sky-400 focus:outline-none"
          >
            <option value="ALL">All 7 Stages</option>
            {GIFT_STAGES.map((st) => (
              <option key={st} value={st}>
                {st}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Add / Edit Child Modal */}
      {showChildModal && (
        <form
          onSubmit={handleSaveChild}
          className="rounded-2xl border border-sky-200/30 bg-slate-900/95 p-6 backdrop-blur-xl"
        >
          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-800 pb-4">
            <h3 className="font-serif-display text-2xl font-semibold text-white">
              {editingChild ? `Edit ${editingChild.name}'s Profile` : 'Add Child Profile'}
            </h3>
            {editingChild && (
              <div className="flex items-center gap-2">
                {!confirmDeleteChild ? (
                  <button
                    type="button"
                    onClick={() => setConfirmDeleteChild(true)}
                    className="text-xs font-medium text-rose-300 hover:text-rose-200"
                  >
                    Delete Profile
                  </button>
                ) : (
                  <div className="flex items-center gap-2 rounded-xl border border-rose-400/40 bg-rose-950/50 px-3 py-1.5 text-xs">
                    <span className="text-rose-200">
                      Delete {editingChild.name} &amp; assigned gifts?
                    </span>
                    <button
                      type="button"
                      onClick={() => {
                        onDeleteChild(editingChild.id);
                        setShowChildModal(false);
                        setConfirmDeleteChild(false);
                        setSelectedChildId('all');
                      }}
                      className="rounded-lg bg-rose-400 px-2.5 py-1 font-semibold text-slate-950 hover:bg-rose-300"
                    >
                      Confirm Delete
                    </button>
                    <button
                      type="button"
                      onClick={() => setConfirmDeleteChild(false)}
                      className="text-slate-300 hover:text-white"
                    >
                      Cancel
                    </button>
                  </div>
                )}
              </div>
            )}
          </div>

          {childFormError && (
            <p role="alert" className="mt-3 text-xs font-medium text-rose-300">
              {childFormError}
            </p>
          )}

          <div className="mt-4 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
            <div>
              <label
                htmlFor="child-name-input"
                className="block text-xs font-medium text-slate-300"
              >
                Name
              </label>
              <input
                id="child-name-input"
                type="text"
                value={childName}
                onChange={(e) => setChildName(e.target.value)}
                placeholder="e.g., Oliver"
                className="mt-1.5 w-full rounded-xl border border-slate-700 bg-slate-950 px-3.5 py-2 text-sm text-white"
              />
            </div>

            <div>
              <label
                htmlFor="child-nickname-input"
                className="block text-xs font-medium text-slate-300"
              >
                Winter Nickname
              </label>
              <input
                id="child-nickname-input"
                type="text"
                value={childNickname}
                onChange={(e) => setChildNickname(e.target.value)}
                placeholder="e.g., Sleigh Navigator"
                className="mt-1.5 w-full rounded-xl border border-slate-700 bg-slate-950 px-3.5 py-2 text-sm text-white"
              />
            </div>

            <div>
              <label
                htmlFor="child-avatar-select"
                className="block text-xs font-medium text-slate-300"
              >
                Winter Avatar
              </label>
              <select
                id="child-avatar-select"
                value={childAvatar}
                onChange={(e) =>
                  setChildAvatar(
                    e.target.value as 'owl' | 'fox' | 'stag' | 'penguin'
                  )
                }
                className="mt-1.5 w-full rounded-xl border border-slate-700 bg-slate-950 px-3.5 py-2 text-sm text-white"
              >
                <option value="owl">Snowy Owl</option>
                <option value="fox">Arctic Fox</option>
                <option value="stag">Silver Stag</option>
                <option value="penguin">Royal Penguin</option>
              </select>
            </div>

            <div>
              <label
                htmlFor="child-budget-input"
                className="block text-xs font-medium text-slate-300"
              >
                Individual Gift Budget ($)
              </label>
              <input
                id="child-budget-input"
                type="number"
                min="0"
                step="10"
                value={childBudget}
                onChange={(e) => setChildBudget(e.target.value)}
                className="font-mono-tabular mt-1.5 w-full rounded-xl border border-slate-700 bg-slate-950 px-3.5 py-2 text-sm text-white"
              />
            </div>
          </div>

          <div className="mt-4">
            <label
              htmlFor="child-wishlist-textarea"
              className="block text-xs font-medium text-slate-300"
            >
              Personalized Christmas Wishlist (one item per line)
            </label>
            <textarea
              id="child-wishlist-textarea"
              rows={3}
              value={childWishlistText}
              onChange={(e) => setChildWishlistText(e.target.value)}
              placeholder="Wooden telescope&#10;Velvet winter cape"
              className="mt-1.5 w-full rounded-xl border border-slate-700 bg-slate-950 p-3 text-xs text-white"
            />
          </div>

          <div className="mt-4 flex justify-end gap-3">
            <button
              type="button"
              onClick={() => setShowChildModal(false)}
              className="rounded-xl border border-slate-700 px-4 py-2 text-xs font-medium text-slate-300"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="rounded-xl bg-sky-300 px-5 py-2 text-xs font-semibold text-slate-950"
            >
              Save Profile
            </button>
          </div>
        </form>
      )}

      {/* Add / Edit Gift Entry Modal */}
      {showGiftModal && (
        <form
          onSubmit={handleSaveGift}
          className="rounded-2xl border border-sky-200/30 bg-slate-900/95 p-6 backdrop-blur-xl"
        >
          <div className="flex items-center justify-between border-b border-slate-800 pb-4">
            <h3 className="font-serif-display text-2xl font-semibold text-white">
              {editingGift ? 'Edit Gift Entry' : 'Add New Christmas Gift'}
            </h3>
            <button
              type="button"
              onClick={() => setShowGiftModal(false)}
              className="text-xs font-medium text-slate-400 hover:text-white"
            >
              Cancel
            </button>
          </div>

          {giftFormError && (
            <p role="alert" className="mt-3 text-xs font-medium text-rose-300">
              {giftFormError}
            </p>
          )}

          <div className="mt-4 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
            <div>
              <label
                htmlFor="gift-recipient-select"
                className="block text-xs font-medium text-slate-300"
              >
                Recipient
              </label>
              <select
                id="gift-recipient-select"
                value={giftChildId}
                onChange={(e) => setGiftChildId(e.target.value)}
                className="mt-1.5 w-full rounded-xl border border-slate-700 bg-slate-950 px-3.5 py-2 text-sm text-white"
              >
                {childrenProfiles.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.name}
                  </option>
                ))}
                <option value="household">Shared Household Gift</option>
              </select>
            </div>

            <div>
              <label
                htmlFor="gift-name-input"
                className="block text-xs font-medium text-slate-300"
              >
                Gift Name
              </label>
              <input
                id="gift-name-input"
                type="text"
                value={giftName}
                onChange={(e) => setGiftName(e.target.value)}
                placeholder="e.g., Starlight Refractor Telescope"
                className="mt-1.5 w-full rounded-xl border border-slate-700 bg-slate-950 px-3.5 py-2 text-sm text-white"
              />
            </div>

            <div>
              <label
                htmlFor="gift-category-select"
                className="block text-xs font-medium text-slate-300"
              >
                Category
              </label>
              <select
                id="gift-category-select"
                value={giftCategory}
                onChange={(e) =>
                  setGiftCategory(e.target.value as GiftCategory)
                }
                className="mt-1.5 w-full rounded-xl border border-slate-700 bg-slate-950 px-3.5 py-2 text-sm text-white"
              >
                {GIFT_CATEGORIES.map((cat) => (
                  <option key={cat} value={cat}>
                    {cat}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label
                htmlFor="gift-status-select"
                className="block text-xs font-medium text-slate-300"
              >
                Gift Stage
              </label>
              <select
                id="gift-status-select"
                value={giftStatus}
                onChange={(e) => setGiftStatus(e.target.value as GiftStage)}
                className="mt-1.5 w-full rounded-xl border border-slate-700 bg-slate-950 px-3.5 py-2 text-sm text-white"
              >
                {GIFT_STAGES.map((st) => (
                  <option key={st} value={st}>
                    {st}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label
                htmlFor="gift-estimated-input"
                className="block text-xs font-medium text-slate-300"
              >
                Estimated Price ($)
              </label>
              <input
                id="gift-estimated-input"
                type="number"
                min="0"
                step="0.01"
                value={giftEstimated}
                onChange={(e) => setGiftEstimated(e.target.value)}
                className="font-mono-tabular mt-1.5 w-full rounded-xl border border-slate-700 bg-slate-950 px-3.5 py-2 text-sm text-white"
              />
            </div>

            <div>
              <label
                htmlFor="gift-actual-input"
                className="block text-xs font-medium text-slate-300"
              >
                Actual Amount Spent ($)
              </label>
              <input
                id="gift-actual-input"
                type="number"
                min="0"
                step="0.01"
                value={giftActual}
                onChange={(e) => setGiftActual(e.target.value)}
                className="font-mono-tabular mt-1.5 w-full rounded-xl border border-slate-700 bg-slate-950 px-3.5 py-2 text-sm text-white"
              />
            </div>

            <div>
              <label
                htmlFor="gift-priority-select"
                className="block text-xs font-medium text-slate-300"
              >
                Priority Level
              </label>
              <select
                id="gift-priority-select"
                value={giftPriority}
                onChange={(e) =>
                  setGiftPriority(e.target.value as GiftPriority)
                }
                className="mt-1.5 w-full rounded-xl border border-slate-700 bg-slate-950 px-3.5 py-2 text-sm text-white"
              >
                <option value="High">High Priority</option>
                <option value="Medium">Medium Priority</option>
                <option value="Low">Low Priority</option>
              </select>
            </div>

            <div>
              <label
                htmlFor="gift-store-input"
                className="block text-xs font-medium text-slate-300"
              >
                Store or Shopping Link
              </label>
              <input
                id="gift-store-input"
                type="text"
                value={giftStore}
                onChange={(e) => setGiftStore(e.target.value)}
                placeholder="e.g., Apple Store or https://..."
                className="mt-1.5 w-full rounded-xl border border-slate-700 bg-slate-950 px-3.5 py-2 text-sm text-white"
              />
            </div>

            <div>
              <label
                htmlFor="gift-purchase-date"
                className="block text-xs font-medium text-slate-300"
              >
                Purchase Date
              </label>
              <input
                id="gift-purchase-date"
                type="date"
                value={giftPurchaseDate}
                onChange={(e) => setGiftPurchaseDate(e.target.value)}
                className="font-mono-tabular mt-1.5 w-full rounded-xl border border-slate-700 bg-slate-950 px-3.5 py-2 text-sm text-white"
              />
            </div>

            <div>
              <label
                htmlFor="gift-delivery-date"
                className="block text-xs font-medium text-slate-300"
              >
                Expected Delivery Date
              </label>
              <input
                id="gift-delivery-date"
                type="date"
                value={giftDeliveryDate}
                onChange={(e) => setGiftDeliveryDate(e.target.value)}
                className="font-mono-tabular mt-1.5 w-full rounded-xl border border-slate-700 bg-slate-950 px-3.5 py-2 text-sm text-white"
              />
            </div>

            <div>
              <label
                htmlFor="gift-photo-url"
                className="block text-xs font-medium text-slate-300"
              >
                Optional Gift Photo URL
              </label>
              <input
                id="gift-photo-url"
                type="url"
                value={giftPhotoUrl}
                onChange={(e) => setGiftPhotoUrl(e.target.value)}
                placeholder="https://..."
                className="mt-1.5 w-full rounded-xl border border-slate-700 bg-slate-950 px-3.5 py-2 text-sm text-white"
              />
            </div>

            <div className="flex items-end pb-2">
              <label className="inline-flex cursor-pointer items-center gap-2 text-xs font-medium text-amber-200">
                <input
                  type="checkbox"
                  checked={giftStocking}
                  onChange={(e) => setGiftStocking(e.target.checked)}
                  className="h-4 w-4 rounded border-slate-700 bg-slate-950 text-sky-400"
                />
                Track as Stocking Stuffer
              </label>
            </div>
          </div>

          <div className="mt-4">
            <label
              htmlFor="gift-notes-input"
              className="block text-xs font-medium text-slate-300"
            >
              Notes &amp; Hiding Spot
            </label>
            <input
              id="gift-notes-input"
              type="text"
              value={giftNotes}
              onChange={(e) => setGiftNotes(e.target.value)}
              placeholder="Wrapping paper style, closet location, or sizing notes..."
              className="mt-1.5 w-full rounded-xl border border-slate-700 bg-slate-950 px-3.5 py-2 text-sm text-white"
            />
          </div>

          <div className="mt-5 flex justify-end gap-3">
            <button
              type="button"
              onClick={() => setShowGiftModal(false)}
              className="rounded-xl border border-slate-700 px-4 py-2 text-xs font-medium text-slate-300"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="rounded-xl bg-sky-300 px-5 py-2 text-xs font-semibold text-slate-950 hover:bg-sky-200"
            >
              {editingGift ? 'Update Gift' : 'Save Gift'}
            </button>
          </div>
        </form>
      )}

      {/* Gifts List */}
      {visibleGifts.length === 0 ? (
        <div className="rounded-2xl border border-slate-800 bg-slate-900/50 p-12 text-center">
          <Gift className="mx-auto h-8 w-8 text-sky-300/60" />
          <p className="mt-3 text-sm font-medium text-white">
            No gifts match your current filter criteria
          </p>
          <p className="mt-1 text-xs text-slate-400">
            Add a new gift entry or switch your active child or stage filter.
          </p>
          <button
            type="button"
            onClick={() => handleOpenAddGift(selectedChildId)}
            className="mt-4 rounded-xl bg-sky-300 px-4 py-2 text-xs font-semibold text-slate-950 hover:bg-sky-200"
          >
            Add First Gift Entry
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
          {visibleGifts.map((gift) => {
            const recipient =
              gift.childId === 'household'
                ? 'Shared Household'
                : childrenProfiles.find((c) => c.id === gift.childId)?.name ||
                  'Family';
            const masked = formatSecretSantaGift(gift, secretSantaMode);
            const stageIdx = GIFT_STAGES.indexOf(gift.status);

            return (
              <article
                key={gift.id}
                className="flex flex-col justify-between rounded-2xl border border-sky-200/15 bg-slate-900/75 p-5 backdrop-blur-md transition hover:border-sky-300/35"
              >
                <div>
                  {/* Unboxed quiet 1-line metadata */}
                  <div className="flex flex-wrap items-center justify-between gap-2 text-xs text-slate-400">
                    <div className="flex flex-wrap items-center gap-1.5">
                      <span className="font-semibold text-sky-200">
                        {recipient}
                      </span>
                      <span aria-hidden="true">·</span>
                      <span>{gift.category}</span>
                      <span aria-hidden="true">·</span>
                      <span>{gift.priority} Priority</span>
                      {gift.isStockingStuffer && (
                        <>
                          <span aria-hidden="true">·</span>
                          <span className="font-medium text-amber-300">
                            Stocking Stuffer
                          </span>
                        </>
                      )}
                    </div>

                    <div className="font-mono-tabular text-sm font-semibold text-white">
                      {masked.displayPriceLabel}
                    </div>
                  </div>

                  {/* Title & Optional Photo */}
                  <div className="mt-2.5 flex items-start justify-between gap-4">
                    <div>
                      <h3 className="font-serif-display text-xl font-semibold text-white">
                        {masked.displayName}
                      </h3>
                      <p className="mt-1 text-xs text-slate-300">
                        Store:{' '}
                        {gift.storeOrLink.startsWith('http') &&
                        !secretSantaMode ? (
                          <a
                            href={gift.storeOrLink}
                            target="_blank"
                            rel="noreferrer"
                            className="inline-flex items-center gap-1 text-sky-300 underline hover:text-sky-200"
                          >
                            Visit Shop <ExternalLink className="h-3 w-3" />
                          </a>
                        ) : (
                          <span className="text-slate-200">
                            {masked.displayStore}
                          </span>
                        )}
                      </p>
                    </div>

                    {gift.photoUrl && !secretSantaMode && (
                      <div className="h-12 w-12 shrink-0 overflow-hidden rounded-xl border border-slate-700 bg-slate-950">
                        <img
                          src={gift.photoUrl}
                          alt={gift.name}
                          referrerPolicy="no-referrer"
                          className="h-full w-full object-cover"
                          onError={(e) => {
                            e.currentTarget.style.display = 'none';
                          }}
                        />
                      </div>
                    )}
                  </div>

                  {/* Cost & Delivery Metadata */}
                  <div className="mt-3 flex flex-wrap items-center gap-3 text-xs text-slate-400">
                    <span>
                      Est:{' '}
                      <strong className="font-mono-tabular text-slate-200">
                        {secretSantaMode
                          ? '$•••'
                          : `$${gift.estimatedPrice.toFixed(2)}`}
                      </strong>
                    </span>
                    <span aria-hidden="true">·</span>
                    <span>
                      Actual:{' '}
                      <strong className="font-mono-tabular text-emerald-300">
                        {secretSantaMode
                          ? '$•••'
                          : `$${gift.actualSpent.toFixed(2)}`}
                      </strong>
                    </span>
                    {gift.expectedDeliveryDate && (
                      <>
                        <span aria-hidden="true">·</span>
                        <span className="font-mono-tabular">
                          Delivery: {gift.expectedDeliveryDate}
                        </span>
                      </>
                    )}
                  </div>

                  {gift.notes && (
                    <p className="mt-2 text-xs text-slate-300">
                      {masked.displayNotes}
                    </p>
                  )}
                </div>

                {/* 7-Stage Pipeline Interactive Control */}
                <div className="mt-4 border-t border-slate-800/90 pt-3">
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-slate-400">
                      Stage {stageIdx + 1} of {GIFT_STAGES.length}
                    </span>
                    <span className="font-semibold tracking-wide text-amber-200">
                      {gift.status}
                    </span>
                  </div>

                  <div className="mt-1.5 grid grid-cols-7 gap-1">
                    {GIFT_STAGES.map((st, idx) => (
                      <div
                        key={st}
                        className={`h-1.5 rounded-full transition-colors ${
                          idx <= stageIdx ? 'bg-sky-300' : 'bg-slate-800'
                        }`}
                      />
                    ))}
                  </div>

                  <div className="mt-3 flex items-center justify-between gap-2">
                    <div className="flex items-center gap-1.5">
                      <button
                        type="button"
                        disabled={stageIdx === 0}
                        onClick={() => handleStepGiftStage(gift, 'prev')}
                        aria-label={`Move ${masked.displayName} to previous stage`}
                        className="inline-flex items-center gap-1 rounded-lg border border-slate-700 bg-slate-950 px-2.5 py-1.5 text-xs font-medium text-slate-200 hover:bg-slate-800 disabled:opacity-35 whitespace-nowrap shrink-0"
                      >
                        <ChevronLeft className="h-3.5 w-3.5" />
                        Prev Stage
                      </button>
                      <button
                        type="button"
                        disabled={stageIdx === GIFT_STAGES.length - 1}
                        onClick={() => handleStepGiftStage(gift, 'next')}
                        aria-label={`Advance ${masked.displayName} to next stage`}
                        className="inline-flex items-center gap-1 rounded-lg bg-sky-300/20 border border-sky-300/40 px-2.5 py-1.5 text-xs font-semibold text-sky-100 hover:bg-sky-300/30 disabled:opacity-35 whitespace-nowrap shrink-0"
                      >
                        Advance Stage
                        <ChevronRight className="h-3.5 w-3.5" />
                      </button>
                    </div>

                    <div className="flex items-center gap-1">
                      <button
                        type="button"
                        onClick={() => handleOpenEditGift(gift)}
                        aria-label={`Edit ${masked.displayName}`}
                        className="rounded-lg p-1.5 text-slate-400 hover:bg-slate-800 hover:text-white"
                      >
                        <Edit3 className="h-3.5 w-3.5" />
                      </button>
                      {confirmDeleteGiftId === gift.id ? (
                        <div className="flex items-center gap-1 rounded-lg border border-rose-400/40 bg-rose-950/60 px-2 py-1 text-[11px]">
                          <button
                            type="button"
                            onClick={() => {
                              onDeleteGift(gift.id);
                              setConfirmDeleteGiftId(null);
                            }}
                            className="font-semibold text-rose-200 hover:text-white"
                          >
                            Confirm Delete
                          </button>
                          <button
                            type="button"
                            onClick={() => setConfirmDeleteGiftId(null)}
                            className="text-slate-400 hover:text-white"
                          >
                            Cancel
                          </button>
                        </div>
                      ) : (
                        <button
                          type="button"
                          onClick={() => setConfirmDeleteGiftId(gift.id)}
                          aria-label={`Delete ${masked.displayName}`}
                          className="rounded-lg p-1.5 text-slate-400 hover:bg-rose-950/60 hover:text-rose-300"
                        >
                          <Trash2 className="h-3.5 w-3.5" />
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              </article>
            );
          })}
        </div>
      )}
    </div>
  );
};
