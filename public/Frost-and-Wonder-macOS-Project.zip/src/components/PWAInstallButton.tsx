import React, { useState } from 'react';
import { Download, Laptop, WifiOff } from 'lucide-react';
import { useOnlineStatus, usePWAInstall } from '../hooks/usePWAInstall';

export const PWAInstallButton: React.FC = () => {
  const { isInstallable, isInstalled, isIOS, isMacSafari, install } =
    usePWAInstall();
  const [showGuideModal, setShowGuideModal] = useState(false);

  if (isInstalled) {
    return null;
  }

  if (isInstallable) {
    return (
      <button
        type="button"
        onClick={install}
        className="inline-flex items-center gap-2 rounded-xl border border-sky-300/35 bg-sky-400/15 px-3.5 py-2 text-xs font-semibold text-sky-100 transition hover:bg-sky-400/25 whitespace-nowrap shrink-0"
      >
        <Download className="h-3.5 w-3.5" />
        Install Mac Web App
      </button>
    );
  }

  return (
    <>
      <button
        type="button"
        onClick={() => setShowGuideModal(true)}
        className="inline-flex items-center gap-2 rounded-xl border border-sky-200/25 bg-slate-900/80 px-3.5 py-2 text-xs font-medium text-sky-100 transition hover:bg-slate-800 whitespace-nowrap shrink-0"
      >
        <Laptop className="h-3.5 w-3.5 text-sky-300" />
        {isIOS ? 'Install on iOS' : 'Add to Mac Dock'}
      </button>

      {showGuideModal && (
        <div
          role="dialog"
          aria-modal="true"
          aria-label="Install Frost and Wonder on macOS or iOS"
          className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 p-4 backdrop-blur-md"
        >
          <div className="w-full max-w-md rounded-2xl border border-sky-200/30 bg-slate-900 p-6 shadow-2xl">
            <h3 className="font-serif-display text-2xl font-semibold text-white">
              Install Frost &amp; Wonder as a Standalone App
            </h3>
            <div className="mt-3 space-y-2.5 text-xs leading-relaxed text-slate-300">
              {isIOS ? (
                <p>
                  1. Tap the <strong>Share</strong> icon in Safari.<br />
                  2. Select <strong>Add to Home Screen</strong> to launch Frost &amp; Wonder in standalone fullscreen mode.
                </p>
              ) : isMacSafari ? (
                <p>
                  1. In macOS Safari (Sonoma/Sequoia), open the <strong>File</strong> menu in the top Mac menu bar.<br />
                  2. Click <strong>Add to Dock...</strong> to install Frost &amp; Wonder as a standalone macOS application with offline support.
                </p>
              ) : (
                <p>
                  In Chrome, Edge, or Brave on macOS, click the <strong>Install Frost &amp; Wonder</strong> icon on the right side of the address bar (or open Browser Menu → <strong>Save and Share → Install Page as App</strong>) to pin it directly to your Mac Dock.
                </p>
              )}
            </div>
            <div className="mt-5 flex justify-end">
              <button
                type="button"
                onClick={() => setShowGuideModal(false)}
                className="rounded-xl bg-sky-300 px-4 py-2 text-xs font-semibold text-slate-950 hover:bg-sky-200"
              >
                Got It
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export const OfflineIndicator: React.FC = () => {
  const isOnline = useOnlineStatus();
  if (isOnline) return null;

  return (
    <div
      role="status"
      className="fixed bottom-4 left-4 z-50 flex items-center gap-2 rounded-xl border border-amber-300/40 bg-slate-900/95 px-3.5 py-2 text-xs font-medium text-amber-200 shadow-lg backdrop-blur-md"
    >
      <WifiOff className="h-3.5 w-3.5 text-amber-300" />
      Offline Mode — Using cached local holiday vault
    </div>
  );
};
