import React, { useEffect, useState } from 'react';
import {
  Award,
  CheckCircle2,
  ChevronLeft,
  ChevronRight,
  Pause,
  Play,
  RotateCcw,
  Shield,
  Sparkles,
  X,
} from 'lucide-react';
import {
  ChildProfile,
  FamilyBudgetSummary,
  GiftItem,
  HolidayMilestone,
} from '../types/holiday';

export type ActiveTabId = 'countdown' | 'gifts' | 'budget' | 'mac';

interface JudgeDemoTourOverlayProps {
  isActive: boolean;
  onExitDemo: () => void;
  activeTab: ActiveTabId;
  onSelectTab: (tab: ActiveTabId) => void;
  onTriggerGlobeSwirl: () => void;
  onSimulateDemoPurchase: () => void;
  demoPurchaseSimulated: boolean;
  onToggleChristmasMorning: () => void;
  simulateChristmasMorning: boolean;
  secretSantaMode: boolean;
  onToggleSecretSanta: () => void;
  budgetSummary: FamilyBudgetSummary;
  onRestartDemo?: () => void;
}

interface DemoStepConfig {
  stepNumber: number;
  title: string;
  subtitle: string;
  targetTab: ActiveTabId;
  description: string;
  engineeringNote: string;
  actionLabel?: string;
}

const DEMO_STEPS: DemoStepConfig[] = [
  {
    stepNumber: 1,
    title: 'Welcome & The Enchanted 3D Snow Globe',
    subtitle: '0:00 – 0:10 · Interactive 3D Centerpiece',
    targetTab: 'countdown',
    description:
      'Welcome, Handshake Judge! Our centerpiece is a real-time 3D-projected Christmas Snow Globe with a glowing Ice Palace, shimmering windows, 3D evergreens, and interactive pointer/drag snow vortex physics.',
    engineeringNote:
      'Engineered with 60fps spherical 3D coordinate projection, zero-re-render pointer physics refs, and WCAG reduced-motion compliance.',
    actionLabel: 'Swirl the 3D Snow Globe Now',
  },
  {
    stepNumber: 2,
    title: 'Mathematical Countdown & Holiday Milestones',
    subtitle: '0:10 – 0:20 · Local Timezone Precision',
    targetTab: 'countdown',
    description:
      'Directly beneath the globe sits the live December 25 countdown alongside miniature frosted-glass milestone cards and an interactive season progression timeline.',
    engineeringNote:
      'Uses deterministic date math across year boundaries with automatic Atmosphere Intensity scaling (Levels 1–5) as Christmas approaches.',
    actionLabel: 'Preview Christmas Morning Celebration',
  },
  {
    stepNumber: 3,
    title: 'Fictional Family Profiles & 7-Stage Gift Pipeline',
    subtitle: '0:20 – 0:30 · Privacy-Isolated Demo Sandbox',
    targetTab: 'gifts',
    description:
      'Explore fictional profiles for Aria, Theo, and Elena (stored in an ephemeral sandbox so private user records are never touched). Track gifts from WISH LIST through READY FOR CHRISTMAS.',
    engineeringNote:
      'Includes 1-click wishlist-to-gift conversion, stocking stuffer separation, and instant Secret Santa Mode spoiler cloaking.',
    actionLabel: 'Toggle Secret Santa Cloak',
  },
  {
    stepNumber: 4,
    title: 'Live Gift Purchase & Automatic Budget Recalculation',
    subtitle: '0:30 – 0:40 · Zero-Double-Counting Financial Engine',
    targetTab: 'gifts',
    description:
      'Watch what happens when a planned gift is purchased: its cost transitions cleanly from Estimated Remaining to Confirmed Spent without ever double-counting.',
    engineeringNote:
      'Pure TypeScript financial state machine verified via automated node:test unit tests.',
    actionLabel: 'Simulate Demo Gift Purchase ($92)',
  },
  {
    stepNumber: 5,
    title: 'Christmas Budget Command Center',
    subtitle: '0:40 – 0:50 · Executive Financial Dashboard',
    targetTab: 'budget',
    description:
      'Inspect total family budget utilization, per-child spending bars, shared household gifts, category distributions, and automatic over-budget threshold warnings.',
    engineeringNote:
      'All numeric displays enforce font-variant-numeric: tabular-nums for zero layout jitter during live updates.',
    actionLabel: 'Preview Christmas Morning Theme',
  },
  {
    stepNumber: 6,
    title: 'macOS Desktop Studio & Software Engineering',
    subtitle: '0:50 – 1:00 · PWA & Native SwiftUI Architecture',
    targetTab: 'mac',
    description:
      'Preview the macOS Desktop Widget, Menu Bar countdown, Full-Screen Animated Screen Saver, 4K Lock Screen Wallpaper generator, and copyable SwiftUI/WidgetKit source code.',
    engineeringNote:
      'Clearly distinguishes supported web/PWA capabilities from native macOS APIs while respecting macOS Lock Screen security boundaries.',
  },
];

export const JudgeDemoTourOverlay: React.FC<JudgeDemoTourOverlayProps> = ({
  isActive,
  onExitDemo,
  onSelectTab,
  onTriggerGlobeSwirl,
  onSimulateDemoPurchase,
  demoPurchaseSimulated,
  onToggleChristmasMorning,
  simulateChristmasMorning,
  secretSantaMode,
  onToggleSecretSanta,
  budgetSummary,
  onRestartDemo,
}) => {
  const [currentStepIdx, setCurrentStepIdx] = useState(0);
  const [elapsedSeconds, setElapsedSeconds] = useState(0);
  const [isPaused, setIsPaused] = useState(false);

  const currentStep = DEMO_STEPS[currentStepIdx] || DEMO_STEPS[0];

  useEffect(() => {
    if (isActive) {
      setCurrentStepIdx(0);
      setElapsedSeconds(0);
      setIsPaused(false);
    }
  }, [isActive]);

  // Sync active tab and trigger step-specific showcase actions when step changes
  useEffect(() => {
    if (!isActive) return;
    const step = DEMO_STEPS[currentStepIdx];
    if (!step) return;
    onSelectTab(step.targetTab);

    if (step.stepNumber === 1) {
      onTriggerGlobeSwirl();
    } else if (step.stepNumber === 4 && !demoPurchaseSimulated) {
      // Automatically demonstrate live purchase update 2.5s into Step 4 if not clicked yet
      const timer = window.setTimeout(() => {
        onSimulateDemoPurchase();
      }, 2200);
      return () => window.clearTimeout(timer);
    }
  }, [currentStepIdx, isActive]);

  // 60-second guided tour timer (10s per step across 6 steps)
  useEffect(() => {
    if (!isActive || isPaused) return;
    const interval = window.setInterval(() => {
      setElapsedSeconds((prev) => {
        if (prev >= 59) {
          setIsPaused(true);
          return 60;
        }
        const nextSec = prev + 1;
        const calculatedStep = Math.min(
          DEMO_STEPS.length - 1,
          Math.floor(nextSec / 10)
        );
        setCurrentStepIdx(calculatedStep);
        return nextSec;
      });
    }, 1000);

    return () => window.clearInterval(interval);
  }, [isActive, isPaused]);

  if (!isActive) return null;

  const handleGoToStep = (index: number) => {
    const clamped = Math.max(0, Math.min(DEMO_STEPS.length - 1, index));
    setCurrentStepIdx(clamped);
    setElapsedSeconds(clamped * 10);
  };

  const handleRestartTour = () => {
    setCurrentStepIdx(0);
    setElapsedSeconds(0);
    setIsPaused(false);
    if (onRestartDemo) {
      onRestartDemo();
    } else {
      onSelectTab('countdown');
      onTriggerGlobeSwirl();
    }
  };

  const handleStepInteractiveAction = () => {
    if (currentStep.stepNumber === 1) {
      onTriggerGlobeSwirl();
    } else if (currentStep.stepNumber === 2 || currentStep.stepNumber === 5) {
      onToggleChristmasMorning();
    } else if (currentStep.stepNumber === 3) {
      onToggleSecretSanta();
    } else if (currentStep.stepNumber === 4) {
      onSimulateDemoPurchase();
    }
  };

  const overallProgressPct = Math.min(
    100,
    Math.round((elapsedSeconds / 60) * 100)
  );

  return (
    <aside
      aria-label="Handshake Competition Judge Guided Tour"
      className="sticky top-16 z-40 mx-auto max-w-7xl px-4 pt-3 sm:px-6 lg:px-8"
    >
      <div className="overflow-hidden rounded-2xl border-2 border-amber-300/60 bg-slate-950/95 shadow-2xl backdrop-blur-2xl">
        {/* Top Progress Bar (60-second tour) */}
        <div className="h-1.5 w-full bg-slate-900">
          <div
            className="h-full bg-gradient-to-r from-sky-300 via-amber-300 to-emerald-300 transition-all duration-500"
            style={{ width: `${overallProgressPct}%` }}
          />
        </div>

        <div className="p-4 sm:p-5">
          {/* Header Row: Sandbox Badge + Tour Controls */}
          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-800 pb-3">
            <div className="flex flex-wrap items-center gap-2 text-xs">
              <Award className="h-4 w-4 text-amber-300" />
              <span className="font-semibold tracking-wide text-amber-200">
                HANDSHAKE JUDGE DEMO MODE
              </span>
              <span aria-hidden="true" className="text-slate-600">
                ·
              </span>
              <span className="inline-flex items-center gap-1 text-emerald-300">
                <Shield className="h-3.5 w-3.5" />
                Isolated Fictional Sandbox (Private User Vault Protected)
              </span>
              <span aria-hidden="true" className="text-slate-600">
                ·
              </span>
              <span className="font-mono-tabular text-sky-200">
                Step {currentStep.stepNumber}/6 ({elapsedSeconds}s / 60s)
              </span>
            </div>

            {/* Playback Controls: Pause, Skip, Restart, Exit */}
            <div className="flex flex-wrap items-center gap-2">
              <button
                type="button"
                onClick={() => setIsPaused((p) => !p)}
                className="inline-flex items-center gap-1.5 rounded-lg border border-slate-700 bg-slate-900 px-3 py-1.5 text-xs font-medium text-slate-200 hover:bg-slate-800 whitespace-nowrap shrink-0"
              >
                {isPaused ? (
                  <>
                    <Play className="h-3.5 w-3.5 text-emerald-300" />
                    Resume Tour
                  </>
                ) : (
                  <>
                    <Pause className="h-3.5 w-3.5 text-amber-300" />
                    Pause Tour
                  </>
                )}
              </button>

              <button
                type="button"
                disabled={currentStepIdx === 0}
                onClick={() => handleGoToStep(currentStepIdx - 1)}
                aria-label="Previous demo step"
                className="inline-flex items-center gap-1 rounded-lg border border-slate-700 bg-slate-900 px-2.5 py-1.5 text-xs font-medium text-slate-200 hover:bg-slate-800 disabled:opacity-40 whitespace-nowrap shrink-0"
              >
                <ChevronLeft className="h-3.5 w-3.5" />
                Prev
              </button>

              <button
                type="button"
                disabled={currentStepIdx === DEMO_STEPS.length - 1}
                onClick={() => handleGoToStep(currentStepIdx + 1)}
                aria-label="Skip to next demo step"
                className="inline-flex items-center gap-1 rounded-lg border border-sky-300/40 bg-sky-400/15 px-3 py-1.5 text-xs font-semibold text-sky-100 hover:bg-sky-400/25 disabled:opacity-40 whitespace-nowrap shrink-0"
              >
                Skip / Next Step
                <ChevronRight className="h-3.5 w-3.5" />
              </button>

              <button
                type="button"
                onClick={handleRestartTour}
                className="inline-flex items-center gap-1.5 rounded-lg border border-slate-700 bg-slate-900 px-3 py-1.5 text-xs font-medium text-slate-200 hover:bg-slate-800 whitespace-nowrap shrink-0"
              >
                <RotateCcw className="h-3.5 w-3.5" />
                Restart
              </button>

              <button
                type="button"
                onClick={onExitDemo}
                className="inline-flex items-center gap-1.5 rounded-lg bg-rose-500/20 border border-rose-400/40 px-3 py-1.5 text-xs font-semibold text-rose-200 hover:bg-rose-500/30 whitespace-nowrap shrink-0"
              >
                <X className="h-3.5 w-3.5" />
                Exit Demo
              </button>
            </div>
          </div>

          {/* Main Step Narrative & Interactive Action */}
          <div className="mt-3.5 grid grid-cols-1 gap-4 lg:grid-cols-12 lg:items-center">
            <div className="lg:col-span-8">
              <div className="text-xs font-medium text-sky-300">
                {currentStep.subtitle}
              </div>
              <h2 className="font-serif-display mt-0.5 text-2xl font-semibold text-white">
                0{currentStep.stepNumber}. {currentStep.title}
              </h2>
              <p className="mt-1 text-xs leading-relaxed text-slate-200 sm:text-sm">
                {currentStep.description}
              </p>
              <p className="mt-1.5 text-xs text-amber-200/90">
                <strong>Engineering Highlight:</strong>{' '}
                {currentStep.engineeringNote}
              </p>
            </div>

            <div className="flex flex-col items-stretch justify-end gap-2 sm:flex-row lg:col-span-4 lg:flex-col">
              {/* Live Demo Sandbox Metrics Snapshot */}
              <div className="rounded-xl border border-slate-800 bg-slate-900/90 px-3.5 py-2 text-xs">
                <div className="flex items-center justify-between text-slate-400">
                  <span>Sandbox Confirmed Spend:</span>
                  <strong className="font-mono-tabular text-emerald-300">
                    ${budgetSummary.confirmedSpentTotal.toFixed(2)}
                  </strong>
                </div>
                <div className="mt-0.5 flex items-center justify-between text-slate-400">
                  <span>Sandbox Est. Remaining:</span>
                  <strong className="font-mono-tabular text-amber-200">
                    ${budgetSummary.estimatedRemainingTotal.toFixed(2)}
                  </strong>
                </div>
              </div>

              {currentStep.actionLabel && (
                <button
                  type="button"
                  onClick={handleStepInteractiveAction}
                  className="inline-flex items-center justify-center gap-2 rounded-xl bg-amber-300 px-4 py-2 text-xs font-semibold text-slate-950 transition hover:bg-amber-200 whitespace-nowrap shrink-0"
                >
                  <Sparkles className="h-3.5 w-3.5" />
                  {currentStep.stepNumber === 4 && demoPurchaseSimulated
                    ? 'Demo Purchase Applied! ($92 → Confirmed)'
                    : currentStep.actionLabel}
                </button>
              )}
            </div>
          </div>

          {/* 6 Chapter Stepper Buttons */}
          <div className="mt-3.5 grid grid-cols-2 gap-1.5 sm:grid-cols-3 lg:grid-cols-6">
            {DEMO_STEPS.map((st, idx) => (
              <button
                key={st.stepNumber}
                type="button"
                onClick={() => handleGoToStep(idx)}
                className={`rounded-lg border px-2.5 py-1.5 text-left text-xs transition ${
                  idx === currentStepIdx
                    ? 'border-amber-300 bg-amber-300/15 text-white'
                    : idx < currentStepIdx
                    ? 'border-emerald-400/30 bg-emerald-950/20 text-emerald-200'
                    : 'border-slate-800 bg-slate-900/60 text-slate-400 hover:text-slate-200'
                }`}
              >
                <div className="flex items-center justify-between font-mono-tabular text-[10px]">
                  <span>STEP 0{st.stepNumber}</span>
                  {idx < currentStepIdx && (
                    <CheckCircle2 className="h-3 w-3 text-emerald-400" />
                  )}
                </div>
                <div className="mt-0.5 truncate font-medium">{st.title}</div>
              </button>
            ))}
          </div>
        </div>
      </div>
    </aside>
  );
};
