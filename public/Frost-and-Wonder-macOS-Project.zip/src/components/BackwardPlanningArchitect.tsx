import React, { useState } from 'react';
import {
  AlertTriangle,
  Bell,
  CalendarCheck,
  CheckCircle2,
  Clock,
  Download,
  RefreshCw,
  Sparkles,
} from 'lucide-react';
import {
  BackwardPlanPhase,
  CountdownState,
  FamilyBudgetSummary,
  HolidayMilestone,
  MilestoneReminderRecord,
} from '../types/holiday';
import {
  generateMilestoneIcsContent,
  getDefaultBackwardPlanPhases,
} from '../utils/holidayLogic';

interface BackwardPlanningArchitectProps {
  countdown: CountdownState;
  milestones: HolidayMilestone[];
  budgetSummary: FamilyBudgetSummary;
  childrenCount: number;
  onSyncBackwardPlanToMilestones: (phases?: BackwardPlanPhase[]) => void;
  onToggleMilestoneComplete: (id: string) => void;
}

export const BackwardPlanningArchitect: React.FC<
  BackwardPlanningArchitectProps
> = ({
  countdown,
  milestones,
  budgetSummary,
  childrenCount,
  onSyncBackwardPlanToMilestones,
  onToggleMilestoneComplete,
}) => {
  const [phases, setPhases] = useState<BackwardPlanPhase[]>(() =>
    getDefaultBackwardPlanPhases(countdown.targetYear)
  );
  const [aiMethodologySummary, setAiMethodologySummary] = useState<string>(
    'By working backward from December 25, 2026, Gemini decomposes a single high-pressure holiday deadline into six sequential weekly checkpoints—inserting a 10-day ground-shipping buffer (Dec 14) and a dedicated 5-day delivery verification window (Dec 15–19) so wrapping and Christmas Eve remain completely stress-free.'
  );
  const [customFocus, setCustomFocus] = useState<string>(
    'Stress-free family Christmas with early shipping cutoff'
  );
  const [isGeneratingAi, setIsGeneratingAi] = useState<boolean>(false);
  const [aiFeedback, setAiFeedback] = useState<{
    type: 'success' | 'error';
    text: string;
  } | null>(null);
  const [syncedBanner, setSyncedBanner] = useState<string | null>(null);

  // Reminder verification state (never claims reminders are scheduled unless actually created & verified)
  const [leadTimeHours, setLeadTimeHours] = useState<number>(24);
  const [verifiedReminders, setVerifiedReminders] = useState<
    MilestoneReminderRecord[]
  >([]);
  const [notificationStatusMsg, setNotificationStatusMsg] = useState<{
    type: 'verified' | 'unverified';
    text: string;
  }>({
    type: 'unverified',
    text: 'No reminders scheduled yet. Export a verified .ICS calendar file for macOS Calendar/Reminders or verify Browser Notification permission below.',
  });

  const handleGenerateWithGemini = async () => {
    setIsGeneratingAi(true);
    setAiFeedback(null);
    try {
      const response = await fetch('/api/backward-plan', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          targetYear: countdown.targetYear,
          daysRemaining: countdown.days,
          totalFamilyBudget: budgetSummary.totalFamilyBudget || 1200,
          childrenCount: Math.max(1, childrenCount),
          customFocus,
        }),
      });
      const data = await response.json();
      if (!response.ok || data.error) {
        setAiFeedback({
          type: 'error',
          text:
            data.error ||
            'Could not reach Gemini API. Showing the default verified 6-phase backward plan.',
        });
        return;
      }

      if (Array.isArray(data.phases) && data.phases.length >= 4) {
        const defaults = getDefaultBackwardPlanPhases(countdown.targetYear);
        const mapped: BackwardPlanPhase[] = data.phases.map(
          (item: Partial<BackwardPlanPhase>, idx: number) => {
            const fallback = defaults[idx] || defaults[defaults.length - 1];
            return {
              id: `bp-ai-${idx + 1}`,
              stageKey: fallback.stageKey,
              phaseNumber: item.phaseNumber || idx + 1,
              title: item.title || fallback.title,
              dateWindowLabel: item.dateWindowLabel || fallback.dateWindowLabel,
              targetDate: item.targetDate || fallback.targetDate,
              daysBeforeChristmas:
                typeof item.daysBeforeChristmas === 'number'
                  ? item.daysBeforeChristmas
                  : fallback.daysBeforeChristmas,
              objective: item.objective || fallback.objective,
              actionChecklist:
                Array.isArray(item.actionChecklist) &&
                item.actionChecklist.length > 0
                  ? item.actionChecklist
                  : fallback.actionChecklist,
              linkedMilestoneTitle:
                item.linkedMilestoneTitle || fallback.linkedMilestoneTitle,
              icon: fallback.icon,
              category: fallback.category,
            };
          }
        );
        setPhases(mapped);
        if (typeof data.aiMethodologySummary === 'string') {
          setAiMethodologySummary(data.aiMethodologySummary);
        }
        setAiFeedback({
          type: 'success',
          text: 'Gemini AI generated a customized 6-phase backward plan tailored to your family budget and countdown!',
        });
      }
    } catch (err: unknown) {
      setAiFeedback({
        type: 'error',
        text:
          err instanceof Error
            ? err.message
            : 'Network error while requesting Gemini backward plan.',
      });
    } finally {
      setIsGeneratingAi(false);
    }
  };

  const handleSyncToMilestones = () => {
    onSyncBackwardPlanToMilestones(phases);
    setSyncedBanner(
      `Synchronized all ${phases.length} backward-planning checkpoints with your Enchanted Season Milestones timeline in chronological order.`
    );
    window.setTimeout(() => setSyncedBanner(null), 5000);
  };

  // Verified RFC 5545 .ICS Calendar Reminder Export
  const handleExportIcsReminder = (targetMilestones: HolidayMilestone[]) => {
    if (targetMilestones.length === 0) return;
    const icsContent = generateMilestoneIcsContent(
      targetMilestones,
      leadTimeHours
    );
    if (!icsContent.includes('BEGIN:VALARM')) return;

    const blob = new Blob([icsContent], {
      type: 'text/calendar;charset=utf-8',
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    const slug =
      targetMilestones.length === 1
        ? targetMilestones[0].title.toLowerCase().replace(/[^a-z0-9]+/g, '-')
        : `all-${targetMilestones.length}-christmas-milestones`;
    a.download = `Frost-and-Wonder-Reminder-${slug}.ics`;
    a.click();
    URL.revokeObjectURL(url);

    const timestamp = new Date().toLocaleTimeString([], {
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
    });
    const newRecords: MilestoneReminderRecord[] = targetMilestones.map((m) => ({
      milestoneId: m.id,
      milestoneTitle: m.title,
      targetDate: m.targetDate,
      leadTimeHours,
      channel: 'ics_calendar',
      verifiedAt: timestamp,
    }));

    setVerifiedReminders((prev) => {
      const filtered = prev.filter(
        (r) => !newRecords.some((nr) => nr.milestoneId === r.milestoneId)
      );
      return [...filtered, ...newRecords];
    });

    setNotificationStatusMsg({
      type: 'verified',
      text: `Verified RFC 5545 .ICS calendar file created (${targetMilestones.length} event${
        targetMilestones.length > 1 ? 's' : ''
      } with -PT${leadTimeHours}H VALARM alert trigger) at ${timestamp}. Open the downloaded .ics file to add directly to macOS Calendar.`,
    });
  };

  // Honest Browser Notification API Permission & Verification
  const handleVerifyBrowserNotification = async (milestone: HolidayMilestone) => {
    if (typeof window === 'undefined' || !('Notification' in window)) {
      setNotificationStatusMsg({
        type: 'unverified',
        text: 'Browser Notification API is not supported in this browser environment. No browser notification was scheduled — please use the verified .ICS Apple Calendar export instead.',
      });
      return;
    }

    try {
      let permission = Notification.permission;
      if (permission === 'default') {
        permission = await Notification.requestPermission();
      }

      if (permission !== 'granted') {
        setNotificationStatusMsg({
          type: 'unverified',
          text: `Browser Notification permission is "${permission}". No browser reminder is scheduled. Use the .ICS Apple Calendar file export to set a native macOS reminder.`,
        });
        return;
      }

      const notif = new Notification(`🎄 Frost & Wonder Reminder Verified`, {
        body: `Active session reminder enabled for "${milestone.title}" (${new Date(
          milestone.targetDate
        ).toLocaleDateString()}).`,
      });
      notif.close();

      const timestamp = new Date().toLocaleTimeString([], {
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
      });
      setVerifiedReminders((prev) => [
        ...prev.filter((r) => r.milestoneId !== milestone.id),
        {
          milestoneId: milestone.id,
          milestoneTitle: milestone.title,
          targetDate: milestone.targetDate,
          leadTimeHours,
          channel: 'browser_notification',
          verifiedAt: timestamp,
        },
      ]);
      setNotificationStatusMsg({
        type: 'verified',
        text: `Verified Browser Notification permission ("granted") and dispatched confirmation for "${milestone.title}" at ${timestamp}.`,
      });
    } catch {
      setNotificationStatusMsg({
        type: 'unverified',
        text: 'Browser notifications are restricted inside this embedded preview frame. No browser reminder was scheduled — click "Export .ICS Reminder" to schedule a verified macOS Calendar alert.',
      });
    }
  };

  const upcomingMilestones = [...milestones]
    .sort(
      (a, b) =>
        new Date(a.targetDate).getTime() - new Date(b.targetDate).getTime()
    );

  return (
    <section
      aria-label="Gemini-Assisted Backward Planning and Optional Milestone Reminders"
      data-testid="backward-planning-architect"
      className="space-y-8 rounded-3xl border border-sky-200/20 bg-slate-900/75 p-6 shadow-2xl backdrop-blur-xl sm:p-8"
    >
      {/* Section Header */}
      <div className="flex flex-col justify-between gap-4 border-b border-sky-200/15 pb-6 lg:flex-row lg:items-end">
        <div>
          <div className="inline-flex items-center gap-2 text-xs font-semibold tracking-wide text-amber-200">
            <Sparkles className="h-4 w-4 text-amber-300" />
            <span>
              GEMINI-ASSISTED BACKWARD PLANNING · DECEMBER 25, {countdown.targetYear} DEADLINE ARCHITECT
            </span>
          </div>
          <h2 className="font-serif-display mt-1 text-3xl font-semibold text-white sm:text-4xl">
            Visible Christmas Preparation Roadmap
          </h2>
          <p className="mt-1 max-w-3xl text-sm text-slate-300">
            Working backward from <strong>December 25, {countdown.targetYear}</strong> across six structured stages: Budgeting, Gift Selection, Purchasing, Delivery Checks, Wrapping, and Final Preparation.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <button
            type="button"
            onClick={handleSyncToMilestones}
            className="inline-flex items-center gap-2 rounded-xl bg-sky-300 px-4 py-2.5 text-xs font-semibold text-slate-950 shadow-sm transition hover:bg-sky-200 whitespace-nowrap shrink-0"
          >
            <CalendarCheck className="h-4 w-4" />
            Sync All 6 Phases to Holiday Milestones
          </button>
        </div>
      </div>

      {/* Short, Attractive Editorial Callout: How AI Turned One Major Deadline into Smaller Achievable Steps */}
      <div
        data-testid="ai-backward-planning-explanation"
        className="grid grid-cols-1 gap-6 rounded-2xl border border-amber-300/30 bg-gradient-to-r from-slate-950/90 via-[#0e1d3d]/90 to-slate-950/90 p-5 lg:grid-cols-12 lg:items-center"
      >
        <div className="space-y-2 lg:col-span-7">
          <div className="flex items-center gap-2 text-xs font-semibold text-amber-200">
            <Sparkles className="h-4 w-4 text-amber-300" />
            <span>How AI Helped Turn One Major Deadline into Achievable Steps</span>
          </div>
          <p className="text-xs leading-relaxed text-slate-200 sm:text-sm">
            {aiMethodologySummary}
          </p>
          <p className="text-xs text-sky-200/90">
            Every backward-planned stage below connects directly to a live card in your <strong>Enchanted Season Milestones</strong> timeline and appears on your downloadable <strong>Mac Lock-Screen Wallpaper</strong>.
          </p>
        </div>

        {/* Live Gemini Customization Controls */}
        <div className="space-y-2.5 rounded-xl border border-sky-200/20 bg-slate-950/80 p-4 lg:col-span-5">
          <label
            htmlFor="gemini-focus-input"
            className="block text-xs font-semibold text-sky-200"
          >
            Customize Backward Plan Focus with Gemini AI
          </label>
          <div className="flex flex-col gap-2 sm:flex-row">
            <input
              id="gemini-focus-input"
              type="text"
              value={customFocus}
              onChange={(e) => setCustomFocus(e.target.value)}
              placeholder="e.g., Early shipping cutoff & handmade gifts"
              className="w-full rounded-xl border border-slate-700 bg-slate-900 px-3 py-2 text-xs text-white placeholder:text-slate-500 focus:border-sky-400 focus:outline-none"
            />
            <button
              type="button"
              disabled={isGeneratingAi}
              onClick={handleGenerateWithGemini}
              className="inline-flex items-center justify-center gap-1.5 rounded-xl bg-amber-300 px-3.5 py-2 text-xs font-semibold text-slate-950 transition hover:bg-amber-200 disabled:opacity-50 whitespace-nowrap shrink-0"
            >
              <RefreshCw
                className={`h-3.5 w-3.5 ${isGeneratingAi ? 'animate-spin' : ''}`}
              />
              {isGeneratingAi ? 'Planning...' : 'Ask Gemini AI'}
            </button>
          </div>
          {aiFeedback && (
            <p
              role="status"
              className={`text-xs ${
                aiFeedback.type === 'error'
                  ? 'text-amber-200'
                  : 'text-emerald-300'
              }`}
            >
              {aiFeedback.text}
            </p>
          )}
        </div>
      </div>

      {syncedBanner && (
        <div
          role="status"
          className="flex items-center gap-2 rounded-xl border border-emerald-400/40 bg-emerald-950/40 px-4 py-3 text-xs font-medium text-emerald-200"
        >
          <CheckCircle2 className="h-4 w-4 shrink-0 text-emerald-300" />
          <span>{syncedBanner}</span>
        </div>
      )}

      {/* 6-Phase Backward Plan Grid Connected to Existing Holiday Milestones */}
      <div className="grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-3">
        {phases.map((phase) => {
          const linkedMilestone = milestones.find(
            (m) =>
              m.title.toLowerCase() ===
                phase.linkedMilestoneTitle.toLowerCase() ||
              m.title.toLowerCase().includes(phase.title.toLowerCase())
          );
          const isCompleted = Boolean(linkedMilestone?.completed);

          return (
            <article
              key={phase.id}
              data-testid={`backward-plan-phase-${phase.phaseNumber}`}
              className={`flex flex-col justify-between rounded-2xl border p-5 transition ${
                isCompleted
                  ? 'border-emerald-400/35 bg-emerald-950/20'
                  : 'border-sky-200/15 bg-slate-950/75 hover:border-sky-300/35'
              }`}
            >
              <div>
                <div className="flex items-center justify-between gap-2 text-xs">
                  <span className="font-mono-tabular font-semibold text-sky-300">
                    PHASE 0{phase.phaseNumber} · T-{phase.daysBeforeChristmas} DAYS
                  </span>
                  <span className="font-mono-tabular text-amber-200">
                    {phase.dateWindowLabel}
                  </span>
                </div>

                <h3 className="font-serif-display mt-2 text-2xl font-semibold text-white">
                  {phase.title}
                </h3>
                <p className="mt-1 text-xs leading-relaxed text-slate-300">
                  {phase.objective}
                </p>

                <ul className="mt-3 space-y-1.5 border-t border-slate-800/80 pt-3 text-xs text-slate-200">
                  {phase.actionChecklist.map((step, i) => (
                    <li key={i} className="flex items-start gap-2">
                      <span className="text-sky-300">•</span>
                      <span>{step}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Direct Connection to Existing Holiday Milestone */}
              <div className="mt-4 border-t border-slate-800/80 pt-3">
                <div className="flex items-center justify-between gap-2 text-xs">
                  <div className="truncate text-slate-400">
                    Linked Milestone:{' '}
                    <strong className="text-white">
                      {linkedMilestone
                        ? linkedMilestone.title
                        : phase.linkedMilestoneTitle}
                    </strong>
                  </div>
                  {linkedMilestone ? (
                    <button
                      type="button"
                      onClick={() =>
                        onToggleMilestoneComplete(linkedMilestone.id)
                      }
                      className={`rounded-lg px-2.5 py-1 text-[11px] font-semibold transition whitespace-nowrap shrink-0 ${
                        isCompleted
                          ? 'bg-emerald-400/20 text-emerald-200'
                          : 'bg-sky-400/20 text-sky-100 hover:bg-sky-400/30'
                      }`}
                    >
                      {isCompleted ? '✓ Milestone Done' : 'Mark Milestone Done'}
                    </button>
                  ) : (
                    <button
                      type="button"
                      onClick={handleSyncToMilestones}
                      className="rounded-lg bg-amber-300/20 px-2.5 py-1 text-[11px] font-semibold text-amber-200 hover:bg-amber-300/30 whitespace-nowrap shrink-0"
                    >
                      + Link to Timeline
                    </button>
                  )}
                </div>
              </div>
            </article>
          );
        })}
      </div>

      {/* THIRD PRIORITY: OPTIONAL REMINDER SETUP FOR KEY MILESTONES */}
      <div
        data-testid="milestone-reminder-setup"
        className="rounded-2xl border border-sky-200/20 bg-slate-950/85 p-5 sm:p-6"
      >
        <div className="flex flex-col justify-between gap-4 border-b border-slate-800 pb-4 lg:flex-row lg:items-center">
          <div>
            <div className="flex items-center gap-2 text-xs font-semibold text-sky-300">
              <Bell className="h-4 w-4 text-amber-300" />
              <span>OPTIONAL MILESTONE REMINDERS · VERIFIED CALENDAR &amp; NOTIFICATION SETUP</span>
            </div>
            <h3 className="font-serif-display mt-1 text-2xl font-semibold text-white">
              Schedule Verified Milestone Alerts
            </h3>
            <p className="mt-0.5 text-xs text-slate-300">
              Export standards-compliant <code>.ICS</code> calendar alerts with embedded <code>VALARM</code> triggers for macOS Calendar, or test live browser notification permissions. Frost &amp; Wonder never marks a reminder as scheduled until it is created and verified.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <div className="flex items-center gap-2 text-xs text-slate-300">
              <Clock className="h-3.5 w-3.5 text-sky-300" />
              <label htmlFor="reminder-lead-select">Alert Lead Time:</label>
              <select
                id="reminder-lead-select"
                value={leadTimeHours}
                onChange={(e) => setLeadTimeHours(Number(e.target.value))}
                className="rounded-lg border border-slate-700 bg-slate-900 px-2.5 py-1.5 text-xs text-white"
              >
                <option value={2}>2 Hours Before</option>
                <option value={24}>24 Hours Before (1 Day)</option>
                <option value={48}>48 Hours Before (2 Days)</option>
                <option value={168}>1 Week Before</option>
              </select>
            </div>

            <button
              type="button"
              onClick={() => handleExportIcsReminder(upcomingMilestones)}
              className="inline-flex items-center gap-1.5 rounded-xl bg-amber-300 px-4 py-2 text-xs font-semibold text-slate-950 transition hover:bg-amber-200 whitespace-nowrap shrink-0"
            >
              <Download className="h-3.5 w-3.5" />
              Export All Milestones to macOS Calendar (.ICS)
            </button>
          </div>
        </div>

        {/* Honest Verification Status Banner */}
        <div
          role="status"
          data-testid="reminder-verification-status"
          className={`mt-4 flex items-start gap-2.5 rounded-xl border p-3.5 text-xs ${
            notificationStatusMsg.type === 'verified'
              ? 'border-emerald-400/40 bg-emerald-950/40 text-emerald-200'
              : 'border-slate-700 bg-slate-900/90 text-slate-300'
          }`}
        >
          {notificationStatusMsg.type === 'verified' ? (
            <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-emerald-300" />
          ) : (
            <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0 text-amber-300" />
          )}
          <div>
            <strong className="text-white">
              {notificationStatusMsg.type === 'verified'
                ? 'Verified Reminder Created:'
                : 'Honest Reminder Status:'}
            </strong>{' '}
            {notificationStatusMsg.text}
          </div>
        </div>

        {/* Per-Milestone Reminder Actions */}
        <div className="mt-4 grid grid-cols-1 gap-2.5 sm:grid-cols-2 lg:grid-cols-3">
          {upcomingMilestones.slice(0, 6).map((ms) => {
            const verifiedRecord = verifiedReminders.find(
              (r) => r.milestoneId === ms.id
            );
            const dateStr = new Date(ms.targetDate).toLocaleDateString(
              'en-US',
              {
                month: 'short',
                day: 'numeric',
              }
            );

            return (
              <div
                key={ms.id}
                className="flex flex-col justify-between rounded-xl border border-slate-800 bg-slate-900/75 p-3.5 text-xs"
              >
                <div>
                  <div className="flex items-center justify-between gap-2">
                    <span className="font-mono-tabular font-semibold text-sky-300">
                      {dateStr}
                    </span>
                    {verifiedRecord ? (
                      <span className="inline-flex items-center gap-1 font-medium text-emerald-300">
                        <CheckCircle2 className="h-3 w-3" />
                        Verified ({verifiedRecord.channel === 'ics_calendar' ? '.ICS' : 'Notif'})
                      </span>
                    ) : (
                      <span className="text-slate-500">Not Scheduled</span>
                    )}
                  </div>
                  <div className="mt-1 font-semibold text-white">
                    {ms.title}
                  </div>
                </div>

                <div className="mt-3 flex items-center gap-2 pt-2 border-t border-slate-800/80">
                  <button
                    type="button"
                    onClick={() => handleExportIcsReminder([ms])}
                    className="flex-1 rounded-lg border border-sky-300/35 bg-sky-400/15 px-2.5 py-1.5 text-center text-[11px] font-semibold text-sky-100 hover:bg-sky-400/25"
                  >
                    Export .ICS Alert
                  </button>
                  <button
                    type="button"
                    onClick={() => handleVerifyBrowserNotification(ms)}
                    className="rounded-lg border border-slate-700 bg-slate-950 px-2.5 py-1.5 text-[11px] font-medium text-slate-300 hover:text-white"
                  >
                    Test Browser Alert
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
