import React, { useState } from 'react';
import {
  AlertTriangle,
  CheckCircle2,
  DollarSign,
  Home,
  PieChart,
  Plus,
  ShoppingBag,
  Sparkles,
  TrendingUp,
} from 'lucide-react';
import {
  ChildProfile,
  FamilyBudgetSummary,
  GiftCategory,
  GiftItem,
} from '../types/holiday';
import {
  classifyGiftCost,
  CONFIRMED_SPEND_STAGES,
} from '../utils/holidayLogic';
import { AVATAR_METADATA } from '../data/seedData';

interface BudgetCommandCenterProps {
  summary: FamilyBudgetSummary;
  childrenProfiles: ChildProfile[];
  gifts: GiftItem[];
  householdBudget: number;
  onUpdateHouseholdBudget: (newBudget: number) => void;
  onUpdateChildBudget: (childId: string, newBudget: number) => void;
  onMarkGiftPurchased: (giftId: string) => void;
  onAddHouseholdGift: (gift: Omit<GiftItem, 'id'>) => void;
  secretSantaMode: boolean;
}

export const BudgetCommandCenter: React.FC<BudgetCommandCenterProps> = ({
  summary,
  childrenProfiles,
  gifts,
  householdBudget,
  onUpdateHouseholdBudget,
  onUpdateChildBudget,
  onMarkGiftPurchased,
  onAddHouseholdGift,
  secretSantaMode,
}) => {
  const [editingHousehold, setEditingHousehold] = useState(false);
  const [householdInput, setHouseholdInput] = useState(String(householdBudget));
  const [editingChildId, setEditingChildId] = useState<string | null>(null);
  const [childBudgetInput, setChildBudgetInput] = useState('');

  // Quick Household Gift Form
  const [showAddHouseholdForm, setShowAddHouseholdForm] = useState(false);
  const [hhName, setHhName] = useState('');
  const [hhStore, setHhStore] = useState('');
  const [hhEst, setHhEst] = useState('75');
  const [hhStatus, setHhStatus] = useState<'PLANNED' | 'PURCHASED'>('PLANNED');

  const handleSaveHouseholdBudget = (e: React.FormEvent) => {
    e.preventDefault();
    const val = Number(householdInput);
    if (!Number.isNaN(val) && val >= 0) {
      onUpdateHouseholdBudget(val);
    }
    setEditingHousehold(false);
  };

  const handleSaveChildBudget = (e: React.FormEvent, childId: string) => {
    e.preventDefault();
    const val = Number(childBudgetInput);
    if (!Number.isNaN(val) && val >= 0) {
      onUpdateChildBudget(childId, val);
    }
    setEditingChildId(null);
  };

  const handleCreateHouseholdGift = (e: React.FormEvent) => {
    e.preventDefault();
    if (!hhName.trim()) return;
    const price = Math.max(0, Number(hhEst) || 0);
    onAddHouseholdGift({
      childId: 'household',
      name: hhName.trim(),
      category: 'Family Shared',
      storeOrLink: hhStore.trim() || 'Holiday Home Atelier',
      estimatedPrice: price,
      actualSpent: hhStatus === 'PURCHASED' ? price : 0,
      priority: 'Medium',
      purchaseDate:
        hhStatus === 'PURCHASED'
          ? new Date().toISOString().slice(0, 10)
          : '',
      expectedDeliveryDate: '',
      notes: 'Shared family holiday gift',
      status: hhStatus,
      isStockingStuffer: false,
    });
    setHhName('');
    setHhStore('');
    setHhEst('75');
    setShowAddHouseholdForm(false);
  };

  // Compute Category Breakdown
  const categoriesMap = new Map<
    GiftCategory,
    { confirmed: number; estimated: number; count: number }
  >();
  for (const g of gifts) {
    const prev = categoriesMap.get(g.category) || {
      confirmed: 0,
      estimated: 0,
      count: 0,
    };
    const c = classifyGiftCost(g);
    prev.confirmed += c.confirmedAmount;
    prev.estimated += c.estimatedRemainingAmount;
    prev.count += 1;
    categoriesMap.set(g.category, prev);
  }
  const categoryRows = Array.from(categoriesMap.entries()).sort(
    (a, b) =>
      b[1].confirmed + b[1].estimated - (a[1].confirmed + a[1].estimated)
  );

  const unpurchasedGifts = gifts.filter(
    (g) => !CONFIRMED_SPEND_STAGES.includes(g.status)
  );
  const householdGifts = gifts.filter((g) => g.childId === 'household');

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex flex-col justify-between gap-4 border-b border-sky-200/15 pb-6 lg:flex-row lg:items-end">
        <div>
          <p className="text-xs font-medium text-sky-300">
            Financial Ledger &amp; Zero-Double-Counting Engine
          </p>
          <h1 className="font-serif-display mt-1 text-3xl font-semibold text-white sm:text-4xl">
            Christmas Budget Command Center
          </h1>
          <p className="mt-1 text-sm text-slate-300">
            Real-time financial clarity across confirmed purchases, remaining planned estimates, and shared household gifts.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <button
            type="button"
            onClick={() => setShowAddHouseholdForm((prev) => !prev)}
            className="inline-flex items-center gap-2 rounded-xl bg-sky-300 px-4 py-2.5 text-xs font-semibold text-slate-950 transition hover:bg-sky-200 whitespace-nowrap shrink-0"
          >
            <Plus className="h-4 w-4" />
            Add Shared Household Gift
          </button>
        </div>
      </div>

      {/* Budget Warning Callout if Exceeded or Approaching Limit */}
      {(summary.isOverBudgetConfirmed ||
        summary.isOverBudgetProjected ||
        summary.isNearBudgetWarning ||
        summary.childMetrics.some(
          (m) => m.isConfirmedOverBudget || m.isProjectedOverBudget
        )) && (
        <div
          role="alert"
          className="rounded-2xl border border-amber-300/40 bg-amber-950/35 p-5 backdrop-blur-md"
        >
          <div className="flex items-start gap-3">
            <AlertTriangle className="mt-0.5 h-5 w-5 shrink-0 text-amber-300" />
            <div>
              <h2 className="text-sm font-semibold text-amber-100">
                Christmas Budget Threshold Alert
              </h2>
              <p className="mt-1 text-xs leading-relaxed text-amber-200/90">
                {summary.isOverBudgetConfirmed
                  ? `Confirmed family spending ($${summary.confirmedSpentTotal.toFixed(
                      2
                    )}) has exceeded the total family Christmas budget ($${summary.totalFamilyBudget.toFixed(
                      2
                    )}).`
                  : summary.isOverBudgetProjected
                  ? `Combined confirmed spending ($${summary.confirmedSpentTotal.toFixed(
                      2
                    )}) plus remaining planned gifts ($${summary.estimatedRemainingTotal.toFixed(
                      2
                    )}) is projected to exceed your total budget by $${Math.abs(
                      summary.projectedAvailableBudget
                    ).toFixed(2)}.`
                  : 'One or more gift allocations are approaching or exceeding 90% of their designated limit.'}
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Top 4 Executive Financial KPI Cards */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <div className="rounded-2xl border border-sky-200/15 bg-slate-900/75 p-5 backdrop-blur-md">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>Total Family Christmas Budget</span>
            <DollarSign className="h-4 w-4 text-sky-300" />
          </div>
          <div className="font-mono-tabular mt-2 text-3xl font-semibold text-white">
            ${summary.totalFamilyBudget.toFixed(2)}
          </div>
          <div className="mt-2 text-xs text-slate-400">
            Children: ${summary.allocatedChildrenBudget.toFixed(0)} · Household: $
            {summary.householdBudgetAllocation.toFixed(0)}
          </div>
        </div>

        <div className="rounded-2xl border border-sky-200/15 bg-slate-900/75 p-5 backdrop-blur-md">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>Amount Already Spent (Confirmed)</span>
            <CheckCircle2 className="h-4 w-4 text-emerald-300" />
          </div>
          <div className="font-mono-tabular mt-2 text-3xl font-semibold text-emerald-300">
            ${summary.confirmedSpentTotal.toFixed(2)}
          </div>
          <div className="mt-2 text-xs text-slate-400">
            {summary.percentConfirmedUsed}% of budget ·{' '}
            {summary.totalPurchasedOrBeyondCount} purchased/wrapped items
          </div>
        </div>

        <div className="rounded-2xl border border-sky-200/15 bg-slate-900/75 p-5 backdrop-blur-md">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>Est. Cost of Remaining Gifts</span>
            <ShoppingBag className="h-4 w-4 text-amber-300" />
          </div>
          <div className="font-mono-tabular mt-2 text-3xl font-semibold text-amber-200">
            ${summary.estimatedRemainingTotal.toFixed(2)}
          </div>
          <div className="mt-2 text-xs text-slate-400">
            {unpurchasedGifts.length} unpurchased wishlist/planned items
          </div>
        </div>

        <div className="rounded-2xl border border-sky-200/15 bg-slate-900/75 p-5 backdrop-blur-md">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>Available Budget Remaining</span>
            <TrendingUp className="h-4 w-4 text-sky-300" />
          </div>
          <div
            className={`font-mono-tabular mt-2 text-3xl font-semibold ${
              summary.availableBudget < 0 ? 'text-rose-300' : 'text-sky-200'
            }`}
          >
            ${summary.availableBudget.toFixed(2)}
          </div>
          <div className="mt-2 text-xs text-slate-400">
            After all planned gifts:{' '}
            <strong
              className={`font-mono-tabular ${
                summary.projectedAvailableBudget < 0
                  ? 'text-rose-300'
                  : 'text-slate-200'
              }`}
            >
              ${summary.projectedAvailableBudget.toFixed(2)}
            </strong>
          </div>
        </div>
      </div>

      {/* Add Shared Household Gift Form */}
      {showAddHouseholdForm && (
        <form
          onSubmit={handleCreateHouseholdGift}
          className="rounded-2xl border border-sky-200/30 bg-slate-900/95 p-6 backdrop-blur-xl"
        >
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <h3 className="font-serif-display text-2xl font-semibold text-white">
              Add Shared Household Christmas Gift
            </h3>
            <button
              type="button"
              onClick={() => setShowAddHouseholdForm(false)}
              className="text-xs text-slate-400 hover:text-white"
            >
              Cancel
            </button>
          </div>
          <div className="mt-4 grid grid-cols-1 gap-4 sm:grid-cols-4">
            <div>
              <label
                htmlFor="hh-gift-name"
                className="block text-xs font-medium text-slate-300"
              >
                Household Gift Name
              </label>
              <input
                id="hh-gift-name"
                type="text"
                value={hhName}
                onChange={(e) => setHhName(e.target.value)}
                placeholder="e.g., Family Board Game Chest"
                className="mt-1.5 w-full rounded-xl border border-slate-700 bg-slate-950 px-3.5 py-2 text-sm text-white"
              />
            </div>
            <div>
              <label
                htmlFor="hh-gift-store"
                className="block text-xs font-medium text-slate-300"
              >
                Store
              </label>
              <input
                id="hh-gift-store"
                type="text"
                value={hhStore}
                onChange={(e) => setHhStore(e.target.value)}
                placeholder="Hearth & Home"
                className="mt-1.5 w-full rounded-xl border border-slate-700 bg-slate-950 px-3.5 py-2 text-sm text-white"
              />
            </div>
            <div>
              <label
                htmlFor="hh-gift-price"
                className="block text-xs font-medium text-slate-300"
              >
                Amount ($)
              </label>
              <input
                id="hh-gift-price"
                type="number"
                min="0"
                step="1"
                value={hhEst}
                onChange={(e) => setHhEst(e.target.value)}
                className="font-mono-tabular mt-1.5 w-full rounded-xl border border-slate-700 bg-slate-950 px-3.5 py-2 text-sm text-white"
              />
            </div>
            <div>
              <label
                htmlFor="hh-gift-status"
                className="block text-xs font-medium text-slate-300"
              >
                Initial Stage
              </label>
              <select
                id="hh-gift-status"
                value={hhStatus}
                onChange={(e) =>
                  setHhStatus(e.target.value as 'PLANNED' | 'PURCHASED')
                }
                className="mt-1.5 w-full rounded-xl border border-slate-700 bg-slate-950 px-3.5 py-2 text-sm text-white"
              >
                <option value="PLANNED">PLANNED (Estimated)</option>
                <option value="PURCHASED">PURCHASED (Confirmed Spend)</option>
              </select>
            </div>
          </div>
          <div className="mt-4 flex justify-end gap-3">
            <button
              type="submit"
              className="rounded-xl bg-sky-300 px-5 py-2 text-xs font-semibold text-slate-950 hover:bg-sky-200"
            >
              Save Household Gift
            </button>
          </div>
        </form>
      )}

      {/* Overall Multi-Segment Visual Progress Bar */}
      <div className="rounded-2xl border border-sky-200/15 bg-slate-900/70 p-6 backdrop-blur-md">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div>
            <h2 className="font-serif-display text-2xl font-semibold text-white">
              Confirmed vs. Estimated Spending Spectrum
            </h2>
            <p className="text-xs text-slate-300">
              When a planned gift is marked as purchased, its cost moves cleanly from Estimated Remaining to Confirmed Spent without double-counting.
            </p>
          </div>
          <span className="font-mono-tabular text-xs font-semibold text-sky-200">
            {summary.percentProjectedUsed}% Projected Utilization
          </span>
        </div>

        {/* Stacked Progress Bar */}
        <div className="mt-4 flex h-4 w-full overflow-hidden rounded-full bg-slate-950 p-0.5">
          <div
            title={`Confirmed Spent: $${summary.confirmedSpentTotal.toFixed(2)}`}
            className="h-full rounded-l-full bg-emerald-400 transition-all duration-500"
            style={{
              width: `${Math.min(100, summary.percentConfirmedUsed)}%`,
            }}
          />
          <div
            title={`Estimated Remaining: $${summary.estimatedRemainingTotal.toFixed(
              2
            )}`}
            className="h-full bg-amber-300 transition-all duration-500"
            style={{
              width: `${Math.max(
                0,
                Math.min(
                  100 - Math.min(100, summary.percentConfirmedUsed),
                  summary.percentProjectedUsed - summary.percentConfirmedUsed
                )
              )}%`,
            }}
          />
        </div>

        <div className="mt-3 flex flex-wrap items-center justify-between gap-4 text-xs text-slate-300">
          <div className="flex flex-wrap items-center gap-4">
            <span className="font-mono-tabular text-emerald-300">
              Confirmed Spent: ${summary.confirmedSpentTotal.toFixed(2)} (
              {summary.percentConfirmedUsed}%)
            </span>
            <span aria-hidden="true">·</span>
            <span className="font-mono-tabular text-amber-200">
              Estimated Remaining: ${summary.estimatedRemainingTotal.toFixed(2)}{' '}
              (
              {Math.max(
                0,
                Number(
                  (
                    summary.percentProjectedUsed - summary.percentConfirmedUsed
                  ).toFixed(1)
                )
              )}
              %)
            </span>
          </div>
          <span className="font-mono-tabular text-sky-200">
            Total Projected: ${summary.totalProjectedSpend.toFixed(2)} / $
            {summary.totalFamilyBudget.toFixed(2)}
          </span>
        </div>
      </div>

      {/* Per-Child & Household Budget Comparisons */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        <div className="space-y-4 lg:col-span-2">
          <h2 className="font-serif-display text-2xl font-semibold text-white">
            Per-Child &amp; Household Budget Comparison
          </h2>

          {summary.childMetrics.map((metric) => {
            const profile = childrenProfiles.find(
              (c) => c.id === metric.childId
            );
            const avatar = profile
              ? AVATAR_METADATA[profile.avatarId]
              : AVATAR_METADATA.owl;

            return (
              <div
                key={metric.childId}
                className="rounded-2xl border border-sky-200/15 bg-slate-900/70 p-5 backdrop-blur-md"
              >
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <div className="h-11 w-11 overflow-hidden rounded-xl border border-sky-200/30 bg-slate-800">
                      <img
                        src={avatar.image}
                        alt={metric.childName}
                        referrerPolicy="no-referrer"
                        className="h-full w-full object-cover"
                        onError={(e) => {
                          e.currentTarget.style.display = 'none';
                        }}
                      />
                    </div>
                    <div>
                      <h3 className="font-serif-display text-xl font-semibold text-white">
                        {metric.childName}
                      </h3>
                      <p className="text-xs text-slate-400">
                        {metric.totalGiftsCount} total gifts ·{' '}
                        {metric.purchasedOrBeyondCount} purchased ·{' '}
                        {metric.wrappedOrReadyCount} wrapped
                      </p>
                    </div>
                  </div>

                  {/* Quick Edit Individual Budget */}
                  {editingChildId === metric.childId ? (
                    <form
                      onSubmit={(e) => handleSaveChildBudget(e, metric.childId)}
                      className="flex items-center gap-2"
                    >
                      <input
                        type="number"
                        min="0"
                        step="10"
                        aria-label={`New budget for ${metric.childName}`}
                        value={childBudgetInput}
                        onChange={(e) => setChildBudgetInput(e.target.value)}
                        className="font-mono-tabular w-24 rounded-lg border border-sky-300 bg-slate-950 px-2.5 py-1 text-xs text-white"
                      />
                      <button
                        type="submit"
                        className="rounded-lg bg-sky-300 px-2.5 py-1 text-xs font-semibold text-slate-950"
                      >
                        Save
                      </button>
                    </form>
                  ) : (
                    <div className="flex items-center gap-3">
                      <div className="text-right">
                        <div className="font-mono-tabular text-sm font-semibold text-white">
                          ${metric.confirmedSpent.toFixed(2)} spent / $
                          {metric.budget.toFixed(2)}
                        </div>
                        <div className="font-mono-tabular text-xs text-slate-400">
                          +${metric.estimatedRemaining.toFixed(2)} est. remaining
                          ({metric.percentProjectedUsed}% used)
                        </div>
                      </div>
                      <button
                        type="button"
                        onClick={() => {
                          setEditingChildId(metric.childId);
                          setChildBudgetInput(String(metric.budget));
                        }}
                        className="rounded-lg border border-slate-700 px-2.5 py-1 text-xs text-slate-300 hover:bg-slate-800"
                      >
                        Adjust Cap
                      </button>
                    </div>
                  )}
                </div>

                {/* Progress Bar */}
                <div className="mt-3 flex h-2.5 w-full overflow-hidden rounded-full bg-slate-950">
                  <div
                    className={`h-full transition-all duration-300 ${
                      metric.isConfirmedOverBudget
                        ? 'bg-rose-400'
                        : 'bg-emerald-400'
                    }`}
                    style={{
                      width: `${Math.min(100, metric.percentConfirmedUsed)}%`,
                    }}
                  />
                  <div
                    className="h-full bg-amber-300 transition-all duration-300"
                    style={{
                      width: `${Math.max(
                        0,
                        Math.min(
                          100 - Math.min(100, metric.percentConfirmedUsed),
                          metric.percentProjectedUsed -
                            metric.percentConfirmedUsed
                        )
                      )}%`,
                    }}
                  />
                </div>

                <div className="mt-2 flex items-center justify-between text-xs text-slate-400">
                  <span>
                    Available vs Confirmed:{' '}
                    <strong
                      className={`font-mono-tabular ${
                        metric.availableBudget < 0
                          ? 'text-rose-300'
                          : 'text-emerald-300'
                      }`}
                    >
                      ${metric.availableBudget.toFixed(2)}
                    </strong>
                  </span>
                  <span>
                    Projected Balance:{' '}
                    <strong
                      className={`font-mono-tabular ${
                        metric.projectedRemainingBudget < 0
                          ? 'text-rose-300'
                          : 'text-sky-200'
                      }`}
                    >
                      ${metric.projectedRemainingBudget.toFixed(2)}
                    </strong>
                  </span>
                </div>
              </div>
            );
          })}

          {/* Optional Shared Household Gift Allocation Card */}
          <div className="rounded-2xl border border-amber-300/20 bg-slate-900/70 p-5 backdrop-blur-md">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div className="flex items-center gap-3">
                <div className="flex h-11 w-11 items-center justify-center rounded-xl border border-amber-300/30 bg-amber-300/10">
                  <Home className="h-5 w-5 text-amber-200" />
                </div>
                <div>
                  <h3 className="font-serif-display text-xl font-semibold text-white">
                    Shared Household Gift Pool
                  </h3>
                  <p className="text-xs text-slate-400">
                    {householdGifts.length} shared family gifts tracked
                  </p>
                </div>
              </div>

              {editingHousehold ? (
                <form
                  onSubmit={handleSaveHouseholdBudget}
                  className="flex items-center gap-2"
                >
                  <input
                    type="number"
                    min="0"
                    step="10"
                    aria-label="Household gift budget allocation"
                    value={householdInput}
                    onChange={(e) => setHouseholdInput(e.target.value)}
                    className="font-mono-tabular w-24 rounded-lg border border-amber-300 bg-slate-950 px-2.5 py-1 text-xs text-white"
                  />
                  <button
                    type="submit"
                    className="rounded-lg bg-amber-300 px-2.5 py-1 text-xs font-semibold text-slate-950"
                  >
                    Save
                  </button>
                </form>
              ) : (
                <div className="flex items-center gap-3">
                  <div className="text-right">
                    <div className="font-mono-tabular text-sm font-semibold text-white">
                      ${summary.householdConfirmedSpent.toFixed(2)} spent / $
                      {summary.householdBudgetAllocation.toFixed(2)}
                    </div>
                    <div className="font-mono-tabular text-xs text-slate-400">
                      +${summary.householdEstimatedRemaining.toFixed(2)} est.
                      remaining
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      setHouseholdInput(
                        String(summary.householdBudgetAllocation)
                      );
                      setEditingHousehold(true);
                    }}
                    className="rounded-lg border border-slate-700 px-2.5 py-1 text-xs text-slate-300 hover:bg-slate-800"
                  >
                    Adjust Cap
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Right Column: Category Breakdown & Instant Purchase Simulator */}
        <div className="space-y-6">
          <div className="rounded-2xl border border-sky-200/15 bg-slate-900/70 p-5 backdrop-blur-md">
            <div className="flex items-center gap-2">
              <PieChart className="h-4 w-4 text-sky-300" />
              <h2 className="font-serif-display text-xl font-semibold text-white">
                Spending by Category
              </h2>
            </div>

            <div className="mt-4 space-y-3">
              {categoryRows.map(([category, vals]) => {
                const totalCat = vals.confirmed + vals.estimated;
                const pct =
                  summary.totalProjectedSpend > 0
                    ? Math.round((totalCat / summary.totalProjectedSpend) * 100)
                    : 0;
                return (
                  <div key={category} className="space-y-1 text-xs">
                    <div className="flex items-center justify-between">
                      <span className="font-medium text-slate-200">
                        {category}{' '}
                        <span className="text-slate-500">({vals.count})</span>
                      </span>
                      <span className="font-mono-tabular text-slate-300">
                        ${vals.confirmed.toFixed(0)} spent · $
                        {vals.estimated.toFixed(0)} est. ({pct}%)
                      </span>
                    </div>
                    <div className="h-1.5 w-full overflow-hidden rounded-full bg-slate-950">
                      <div
                        className="h-full rounded-full bg-sky-300"
                        style={{ width: `${Math.min(100, pct)}%` }}
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Interactive Unpurchased Queue: Mark as Purchased to see Instant Zero-Double-Count Update */}
          <div className="rounded-2xl border border-sky-200/15 bg-slate-900/70 p-5 backdrop-blur-md">
            <div className="flex items-center gap-2">
              <Sparkles className="h-4 w-4 text-amber-300" />
              <h3 className="font-serif-display text-xl font-semibold text-white">
                Pending Planned Purchases
              </h3>
            </div>
            <p className="mt-1 text-xs text-slate-400">
              Mark any planned item below as purchased to shift its cost from Estimated Remaining to Confirmed Spent immediately.
            </p>

            {unpurchasedGifts.length === 0 ? (
              <p className="mt-4 text-xs text-emerald-300">
                All planned and wishlist gifts have been purchased!
              </p>
            ) : (
              <ul className="mt-4 space-y-2.5">
                {unpurchasedGifts.map((g) => {
                  const childName =
                    g.childId === 'household'
                      ? 'Household'
                      : childrenProfiles.find((c) => c.id === g.childId)
                          ?.name || 'Family';
                  return (
                    <li
                      key={g.id}
                      className="flex items-center justify-between gap-3 rounded-xl border border-slate-800 bg-slate-950/75 p-3 text-xs"
                    >
                      <div className="min-w-0">
                        <p className="truncate font-medium text-white">
                          {secretSantaMode
                            ? `Encrypted Parcel #${g.id.slice(-3)}`
                            : g.name}
                        </p>
                        <p className="font-mono-tabular text-slate-400">
                          {childName} · Est. ${g.estimatedPrice.toFixed(2)} ·{' '}
                          {g.status}
                        </p>
                      </div>
                      <button
                        type="button"
                        onClick={() => onMarkGiftPurchased(g.id)}
                        className="rounded-lg bg-emerald-400/20 border border-emerald-400/40 px-3 py-1.5 text-xs font-semibold text-emerald-200 hover:bg-emerald-400/30 whitespace-nowrap shrink-0"
                      >
                        Mark Purchased
                      </button>
                    </li>
                  );
                })}
              </ul>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
