import React, { useEffect, useState } from 'react';
import {
  ArrowDown,
  ArrowUp,
  Bell,
  Calendar,
  CheckCircle2,
  ChevronLeft,
  ChevronRight,
  Circle,
  Cookie,
  Edit3,
  Gift,
  Plus,
  ShoppingBag,
  Sparkles,
  Star,
  Trash2,
  TreePine,
  Utensils,
} from 'lucide-react';
import {
  CountdownState,
  HolidayMilestone,
  MilestoneIconType,
} from '../types/holiday';
import {
  calculateMilestoneTimeRemaining,
  FESTIVE_MESSAGES,
} from '../utils/holidayLogic';
import { GENERATED_ASSETS } from '../data/seedData';
import { EnchantedSnowGlobe } from './EnchantedSnowGlobe';

interface CountdownHeroAndMilestonesProps {
  countdown: CountdownState;
  now: Date;
  simulateChristmasMorning: boolean;
  onToggleSimulateChristmas: () => void;
  onAdvanceToNextSeason: () => void;
  hasTargetYearOverride: boolean;
  onResetSeasonYear: () => void;
  milestones: HolidayMilestone[];
  onAddMilestone: (ms: Omit<HolidayMilestone, 'id' | 'order'>) => void;
  onUpdateMilestone: (ms: HolidayMilestone) => void;
  onToggleMilestoneComplete: (id: string) => void;
  onDeleteMilestone: (id: string) => void;
  onMoveMilestone: (id: string, direction: 'up' | 'down') => void;
  onOpenScreenSaver: () => void;
  onStartJudgeDemo: () => void;
  externalSwirlTrigger?: number;
}

const MILESTONE_ICONS: Record<MilestoneIconType, React.ReactNode> = {
  turkey: <Utensils className="h-4 w-4 text-amber-300" />,
  tree: <TreePine className="h-4 w-4 text-emerald-300" />,
  shopping: <ShoppingBag className="h-4 w-4 text-sky-300" />,
  cookie: <Cookie className="h-4 w-4 text-amber-200" />,
  gift: <Gift className="h-4 w-4 text-purple-300" />,
  sleigh: <Sparkles className="h-4 w-4 text-amber-300" />,
  star: <Star className="h-4 w-4 text-amber-300" />,
  snowflake: <Sparkles className="h-4 w-4 text-sky-200" />,
  bell: <Bell className="h-4 w-4 text-amber-200" />,
};

export const CountdownHeroAndMilestones: React.FC<
  CountdownHeroAndMilestonesProps
> = ({
  countdown,
  now,
  simulateChristmasMorning,
  onToggleSimulateChristmas,
  onAdvanceToNextSeason,
  hasTargetYearOverride,
  onResetSeasonYear,
  milestones,
  onAddMilestone,
  onUpdateMilestone,
  onToggleMilestoneComplete,
  onDeleteMilestone,
  onMoveMilestone,
  onOpenScreenSaver,
  onStartJudgeDemo,
  externalSwirlTrigger = 0,
}) => {
  const [messageIndex, setMessageIndex] = useState(0);
  const [timelineFilter, setTimelineFilter] = useState<
    'all' | 'upcoming' | 'completed'
  >('all');
  const [showMilestoneForm, setShowMilestoneForm] = useState(false);
  const [editingMilestoneId, setEditingMilestoneId] = useState<string | null>(
    null
  );
  const [confirmDeleteMilestoneId, setConfirmDeleteMilestoneId] = useState<
    string | null
  >(null);

  // Form states
  const [formTitle, setFormTitle] = useState('');
  const [formDate, setFormDate] = useState(
    `${countdown.targetYear}-12-15T18:00`
  );
  const [formIcon, setFormIcon] = useState<MilestoneIconType>('snowflake');
  const [formCategory, setFormCategory] = useState('Family Tradition');
  const [formNotes, setFormNotes] = useState('');
  const [formError, setFormError] = useState('');

  useEffect(() => {
    const interval = window.setInterval(() => {
      setMessageIndex((prev) => (prev + 1) % FESTIVE_MESSAGES.length);
    }, 9000);
    return () => window.clearInterval(interval);
  }, []);

  const handleOpenCreate = () => {
    setEditingMilestoneId(null);
    setFormTitle('');
    setFormDate(`${countdown.targetYear}-12-15T18:00`);
    setFormIcon('snowflake');
    setFormCategory('Family Tradition');
    setFormNotes('');
    setFormError('');
    setShowMilestoneForm(true);
  };

  const handleOpenEdit = (ms: HolidayMilestone) => {
    setEditingMilestoneId(ms.id);
    setFormTitle(ms.title);
    setFormDate(ms.targetDate);
    setFormIcon(ms.icon);
    setFormCategory(ms.category);
    setFormNotes(ms.notes || '');
    setFormError('');
    setShowMilestoneForm(true);
  };

  const handleSubmitMilestone = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formTitle.trim()) {
      setFormError('Please enter a milestone title.');
      return;
    }
    if (!formDate.trim() || Number.isNaN(new Date(formDate).getTime())) {
      setFormError('Please select a valid date and time.');
      return;
    }

    if (editingMilestoneId) {
      const existing = milestones.find((m) => m.id === editingMilestoneId);
      if (existing) {
        onUpdateMilestone({
          ...existing,
          title: formTitle.trim(),
          targetDate: formDate,
          icon: formIcon,
          category: formCategory.trim() || 'Family Tradition',
          notes: formNotes.trim(),
        });
      }
    } else {
      onAddMilestone({
        title: formTitle.trim(),
        targetDate: formDate,
        icon: formIcon,
        category: formCategory.trim() || 'Family Tradition',
        completed: false,
        notes: formNotes.trim(),
      });
    }

    setShowMilestoneForm(false);
    setEditingMilestoneId(null);
  };

  const sortedMilestones = [...milestones].sort((a, b) => a.order - b.order);
  const filteredMilestones = sortedMilestones.filter((m) => {
    if (timelineFilter === 'upcoming') return !m.completed;
    if (timelineFilter === 'completed') return m.completed;
    return true;
  });

  const completedCount = milestones.filter((m) => m.completed).length;

  return (
    <div className="space-y-12">
      {/* Centerpiece Enchanted Ice Palace & Interactive 3D Snow Globe Hero */}
      <section
        aria-label="Christmas Centerpiece Countdown and Interactive Snow Globe"
        className="relative overflow-hidden rounded-3xl border border-sky-200/20 bg-[#0b1530] shadow-2xl"
      >
        {/* Background Artwork with resilient fallback gradient */}
        <div className="absolute inset-0 bg-gradient-to-b from-[#0c1938] via-[#132347] to-[#070d1f]">
          <img
            src={GENERATED_ASSETS.heroIcePalace}
            alt="Glowing Crystalline Ice Palace in the Winter Mountains"
            referrerPolicy="no-referrer"
            className="h-full w-full object-cover object-center opacity-50 transition-opacity duration-700"
            onError={(e) => {
              e.currentTarget.style.display = 'none';
            }}
          />
          {/* Measured Contrast Scrim for 4.5:1+ WCAG readability */}
          <div className="absolute inset-0 bg-gradient-to-t from-[#070d1f] via-[#070d1f]/70 to-[#070d1f]/80" />
          <div className="animate-aurora pointer-events-none absolute -top-24 left-1/4 h-72 w-2/3 rounded-full bg-gradient-to-r from-sky-400/20 via-purple-400/20 to-amber-300/20 blur-3xl" />
        </div>

        {/* Content Container */}
        <div className="relative z-10 px-6 py-8 sm:px-10 sm:py-12 lg:px-14">
          <div className="mx-auto max-w-4xl text-center">
            {/* Above Timer Required Message */}
            {countdown.isChristmasMorning ? (
              <div className="inline-flex items-center gap-2 text-base font-medium tracking-wide text-amber-200 sm:text-lg">
                <span>🎄 Merry Christmas! The Magic Has Arrived!</span>
              </div>
            ) : (
              <p className="text-base font-medium tracking-wide text-sky-200 sm:text-lg">
                ✨ The Magic of Christmas Is Almost Here ✨
              </p>
            )}

            <h1
              className="font-serif-display mt-2 text-4xl font-semibold tracking-tight text-white sm:text-5xl lg:text-6xl"
              style={{ textWrap: 'balance' }}
            >
              {countdown.isChristmasMorning
                ? 'Rejoice in the Enchanted Winter Kingdom'
                : `Frost & Wonder Christmas ${countdown.targetYear}`}
            </h1>

            {/* FEATURE ONE: THE ENCHANTED 3D SNOW GLOBE CENTERPIECE */}
            <div className="mt-4">
              <EnchantedSnowGlobe
                countdown={countdown}
                onToggleSimulateChristmas={onToggleSimulateChristmas}
                simulateChristmasMorning={simulateChristmasMorning}
                externalSwirlTrigger={externalSwirlTrigger}
              />
            </div>

            {/* Beautiful Christmas Countdown Displayed Elegantly Beneath the Globe */}
            {countdown.isChristmasMorning ? (
              <div className="mt-6 rounded-2xl border border-amber-300/35 bg-slate-950/75 p-7 backdrop-blur-xl">
                <p className="font-serif-display text-2xl text-amber-100 sm:text-3xl">
                  🎄 Merry Christmas! The Magic Has Arrived!
                </p>
                <p className="mx-auto mt-2.5 max-w-2xl text-sm leading-relaxed text-slate-200 sm:text-base">
                  The Great Ice Palace is aglow with champagne starlight and joyful song. Gather around the tree, unwrap your memories, and when you are ready, begin planning the magic for next Christmas season.
                </p>
                <div className="mt-5 flex flex-wrap items-center justify-center gap-4">
                  <button
                    type="button"
                    onClick={onAdvanceToNextSeason}
                    className="rounded-xl bg-amber-300 px-5 py-2.5 text-sm font-semibold text-slate-950 transition hover:bg-amber-200 whitespace-nowrap shrink-0"
                  >
                    Continue for Next Christmas Season ({countdown.targetYear + 1})
                  </button>
                  {simulateChristmasMorning && (
                    <button
                      type="button"
                      onClick={onToggleSimulateChristmas}
                      className="rounded-xl border border-sky-200/30 bg-slate-900/80 px-4 py-2.5 text-sm font-medium text-sky-100 transition hover:bg-slate-800 whitespace-nowrap shrink-0"
                    >
                      Return to Live Timer
                    </button>
                  )}
                </div>
              </div>
            ) : (
              <div
                role="timer"
                aria-label="Time remaining until Christmas beneath the snow globe"
                className="mt-6 grid grid-cols-2 gap-3.5 sm:grid-cols-4 sm:gap-5"
              >
                {[
                  {
                    label: 'DAYS',
                    value: String(countdown.days).padStart(2, '0'),
                    sub: `Dec 25, ${countdown.targetYear}`,
                  },
                  {
                    label: 'HOURS',
                    value: String(countdown.hours).padStart(2, '0'),
                    sub: 'Local Time',
                  },
                  {
                    label: 'MINUTES',
                    value: String(countdown.minutes).padStart(2, '0'),
                    sub: 'Crystal Sync',
                  },
                  {
                    label: 'SECONDS',
                    value: String(countdown.seconds).padStart(2, '0'),
                    sub: 'Live Pulse',
                  },
                ].map((unit) => (
                  <div
                    key={unit.label}
                    className="rounded-2xl border border-sky-200/20 bg-slate-950/70 px-4 py-5 backdrop-blur-xl"
                  >
                    <div className="font-mono-tabular text-4xl font-semibold tracking-tight text-white sm:text-5xl">
                      {unit.value}
                    </div>
                    <div className="mt-1.5 text-xs font-semibold tracking-widest text-amber-200/90">
                      {unit.label}
                    </div>
                    <div className="mt-0.5 text-xs text-slate-400">{unit.sub}</div>
                  </div>
                ))}
              </div>
            )}

            {/* Rotating Collection of Original Festive Messages */}
            <div className="mt-6 flex items-center justify-center gap-3">
              <button
                type="button"
                aria-label="Previous festive message"
                onClick={() =>
                  setMessageIndex(
                    (prev) =>
                      (prev - 1 + FESTIVE_MESSAGES.length) %
                      FESTIVE_MESSAGES.length
                  )
                }
                className="rounded-lg border border-slate-700/70 bg-slate-900/60 p-2 text-slate-300 transition hover:border-sky-300/40 hover:text-white"
              >
                <ChevronLeft className="h-4 w-4" />
              </button>
              <p className="font-serif-display max-w-2xl text-lg italic text-slate-100 sm:text-xl">
                “{FESTIVE_MESSAGES[messageIndex]}”
              </p>
              <button
                type="button"
                aria-label="Next festive message"
                onClick={() =>
                  setMessageIndex((prev) => (prev + 1) % FESTIVE_MESSAGES.length)
                }
                className="rounded-lg border border-slate-700/70 bg-slate-900/60 p-2 text-slate-300 transition hover:border-sky-300/40 hover:text-white"
              >
                <ChevronRight className="h-4 w-4" />
              </button>
            </div>

            {/* Secondary Controls Bar inside Hero */}
            <div className="mt-7 flex flex-wrap items-center justify-between gap-4 border-t border-sky-200/15 pt-5 text-xs text-slate-300">
              <div className="flex flex-wrap items-center gap-2">
                <span className="font-medium text-sky-200">
                  Atmosphere Level {countdown.magicIntensity}/5: {countdown.magicStageLabel}
                </span>
                <span aria-hidden="true">·</span>
                <span className="font-mono-tabular">
                  Season Progress {countdown.seasonProgressPercent}%
                </span>
                <span aria-hidden="true">·</span>
                <span>
                  Local Timezone ({Intl.DateTimeFormat().resolvedOptions().timeZone || 'Local'})
                </span>
              </div>

              <div className="flex flex-wrap items-center gap-2.5">
                <button
                  type="button"
                  onClick={onOpenScreenSaver}
                  className="rounded-lg border border-sky-300/30 bg-sky-400/15 px-3.5 py-2 text-xs font-medium text-sky-100 transition hover:bg-sky-400/25 whitespace-nowrap shrink-0"
                >
                  Full-Screen Display Mode
                </button>
                <button
                  type="button"
                  onClick={onToggleSimulateChristmas}
                  className="rounded-lg border border-amber-300/35 bg-amber-300/15 px-3.5 py-2 text-xs font-medium text-amber-100 transition hover:bg-amber-300/25 whitespace-nowrap shrink-0"
                >
                  {simulateChristmasMorning
                    ? 'Exit Christmas Morning Preview'
                    : 'Preview Christmas Morning'}
                </button>
                {hasTargetYearOverride && (
                  <button
                    type="button"
                    onClick={onResetSeasonYear}
                    className="rounded-lg border border-slate-700 bg-slate-900/80 px-3.5 py-2 text-xs font-medium text-slate-200 transition hover:bg-slate-800 whitespace-nowrap shrink-0"
                  >
                    Reset to Current Season
                  </button>
                )}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Mini Countdowns & Interactive Holiday Milestones */}
      <section aria-label="Mini Countdowns and Holiday Milestones" className="space-y-6">
        <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-end">
          <div>
            <p className="text-xs font-medium text-sky-300">
              Holiday Timeline &amp; Mini Countdowns
            </p>
            <h2 className="font-serif-display mt-1 text-3xl font-semibold text-white">
              Enchanted Season Milestones
            </h2>
            <p className="mt-1 text-sm text-slate-300">
              Track every cherished family tradition leading up to Christmas morning.{' '}
              <span className="font-mono-tabular text-sky-200">
                {completedCount} of {milestones.length} completed
              </span>
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            {/* Segmented Filter Control */}
            <div
              role="group"
              aria-label="Filter milestones"
              className="flex items-center gap-1 rounded-xl border border-slate-800 bg-slate-900/90 p-1"
            >
              {(
                [
                  { id: 'all', label: 'All Events' },
                  { id: 'upcoming', label: 'Upcoming' },
                  { id: 'completed', label: 'Completed' },
                ] as const
              ).map((tab) => (
                <button
                  key={tab.id}
                  type="button"
                  onClick={() => setTimelineFilter(tab.id)}
                  className={`rounded-lg px-3 py-1.5 text-xs font-medium transition whitespace-nowrap shrink-0 ${
                    timelineFilter === tab.id
                      ? 'bg-sky-400/20 text-sky-100'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>

            <button
              type="button"
              onClick={handleOpenCreate}
              className="inline-flex items-center gap-2 rounded-xl bg-sky-300 px-4 py-2 text-xs font-semibold text-slate-950 transition hover:bg-sky-200 whitespace-nowrap shrink-0"
            >
              <Plus className="h-4 w-4" />
              Add Milestone
            </button>
          </div>
        </div>

        {/* Create / Edit Milestone Modal Form */}
        {showMilestoneForm && (
          <form
            onSubmit={handleSubmitMilestone}
            className="rounded-2xl border border-sky-200/25 bg-slate-900/90 p-6 backdrop-blur-xl"
          >
            <div className="flex items-center justify-between border-b border-slate-800 pb-4">
              <h3 className="font-serif-display text-2xl font-semibold text-white">
                {editingMilestoneId
                  ? 'Edit Holiday Milestone'
                  : 'Create Holiday Milestone'}
              </h3>
              <button
                type="button"
                onClick={() => setShowMilestoneForm(false)}
                className="text-xs font-medium text-slate-400 hover:text-white"
              >
                Cancel
              </button>
            </div>

            {formError && (
              <p role="alert" className="mt-3 text-xs font-medium text-rose-300">
                {formError}
              </p>
            )}

            <div className="mt-4 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
              <div>
                <label
                  htmlFor="ms-title-input"
                  className="block text-xs font-medium text-slate-300"
                >
                  Milestone Name
                </label>
                <input
                  id="ms-title-input"
                  type="text"
                  value={formTitle}
                  onChange={(e) => setFormTitle(e.target.value)}
                  placeholder="e.g., Gingerbread House Night"
                  className="mt-1.5 w-full rounded-xl border border-slate-700 bg-slate-950/90 px-3.5 py-2 text-sm text-white placeholder:text-slate-500 focus:border-sky-400 focus:outline-none"
                />
              </div>

              <div>
                <label
                  htmlFor="ms-date-input"
                  className="block text-xs font-medium text-slate-300"
                >
                  Target Date &amp; Time
                </label>
                <input
                  id="ms-date-input"
                  type="datetime-local"
                  value={formDate}
                  onChange={(e) => setFormDate(e.target.value)}
                  className="font-mono-tabular mt-1.5 w-full rounded-xl border border-slate-700 bg-slate-950/90 px-3.5 py-2 text-sm text-white focus:border-sky-400 focus:outline-none"
                />
              </div>

              <div>
                <label
                  htmlFor="ms-icon-select"
                  className="block text-xs font-medium text-slate-300"
                >
                  Themed Icon
                </label>
                <select
                  id="ms-icon-select"
                  value={formIcon}
                  onChange={(e) =>
                    setFormIcon(e.target.value as MilestoneIconType)
                  }
                  className="mt-1.5 w-full rounded-xl border border-slate-700 bg-slate-950/90 px-3.5 py-2 text-sm text-white focus:border-sky-400 focus:outline-none"
                >
                  <option value="snowflake">Crystal Snowflake</option>
                  <option value="tree">Christmas Tree</option>
                  <option value="turkey">Thanksgiving Feast</option>
                  <option value="shopping">Holiday Shopping</option>
                  <option value="cookie">Cookie Baking</option>
                  <option value="gift">Wrapping Presents</option>
                  <option value="sleigh">Santa&apos;s Sleigh</option>
                  <option value="star">Christmas Morning Star</option>
                  <option value="bell">Silver Sleigh Bell</option>
                </select>
              </div>

              <div>
                <label
                  htmlFor="ms-category-input"
                  className="block text-xs font-medium text-slate-300"
                >
                  Tradition Category
                </label>
                <input
                  id="ms-category-input"
                  type="text"
                  value={formCategory}
                  onChange={(e) => setFormCategory(e.target.value)}
                  placeholder="Family Tradition"
                  className="mt-1.5 w-full rounded-xl border border-slate-700 bg-slate-950/90 px-3.5 py-2 text-sm text-white placeholder:text-slate-500 focus:border-sky-400 focus:outline-none"
                />
              </div>
            </div>

            <div className="mt-4">
              <label
                htmlFor="ms-notes-input"
                className="block text-xs font-medium text-slate-300"
              >
                Festive Notes (Optional)
              </label>
              <input
                id="ms-notes-input"
                type="text"
                value={formNotes}
                onChange={(e) => setFormNotes(e.target.value)}
                placeholder="Add recipes, reminders, or family traditions..."
                className="mt-1.5 w-full rounded-xl border border-slate-700 bg-slate-950/90 px-3.5 py-2 text-sm text-white placeholder:text-slate-500 focus:border-sky-400 focus:outline-none"
              />
            </div>

            <div className="mt-5 flex justify-end gap-3">
              <button
                type="button"
                onClick={() => setShowMilestoneForm(false)}
                className="rounded-xl border border-slate-700 px-4 py-2 text-xs font-medium text-slate-300 hover:bg-slate-800 whitespace-nowrap shrink-0"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="rounded-xl bg-sky-300 px-5 py-2 text-xs font-semibold text-slate-950 hover:bg-sky-200 whitespace-nowrap shrink-0"
              >
                {editingMilestoneId ? 'Save Changes' : 'Create Milestone'}
              </button>
            </div>
          </form>
        )}

        {/* Miniature Frosted-Glass Milestone Cards Grid */}
        {filteredMilestones.length === 0 ? (
          <div className="rounded-2xl border border-slate-800 bg-slate-900/50 p-10 text-center">
            <p className="text-sm text-slate-300">
              No holiday milestones match the selected filter.
            </p>
            <button
              type="button"
              onClick={handleOpenCreate}
              className="mt-4 rounded-xl bg-sky-300 px-4 py-2 text-xs font-semibold text-slate-950 hover:bg-sky-200"
            >
              Create First Milestone
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-3">
            {filteredMilestones.map((ms, idx) => {
              const remaining = calculateMilestoneTimeRemaining(
                ms.targetDate,
                now
              );
              const formattedDate = new Date(ms.targetDate).toLocaleDateString(
                undefined,
                {
                  month: 'short',
                  day: 'numeric',
                  hour: 'numeric',
                  minute: '2-digit',
                }
              );

              return (
                <article
                  key={ms.id}
                  className={`flex flex-col justify-between rounded-2xl border p-5 backdrop-blur-md transition ${
                    ms.completed
                      ? 'border-emerald-400/25 bg-slate-900/45 opacity-85'
                      : 'border-sky-200/15 bg-slate-900/70 hover:border-sky-300/35'
                  }`}
                >
                  <div>
                    {/* Quiet 1-line unboxed metadata kicker */}
                    <div className="flex items-center justify-between gap-2 text-xs text-slate-400">
                      <div className="flex items-center gap-2">
                        {MILESTONE_ICONS[ms.icon]}
                        <span>{ms.category}</span>
                        <span aria-hidden="true">·</span>
                        <span className="font-mono-tabular">{formattedDate}</span>
                      </div>
                      <span
                        className={`font-mono-tabular font-semibold ${
                          ms.completed
                            ? 'text-emerald-300'
                            : remaining.isPast
                            ? 'text-amber-300'
                            : 'text-sky-200'
                        }`}
                      >
                        {ms.completed ? 'Completed' : remaining.formattedLabel}
                      </span>
                    </div>

                    <h3
                      className={`font-serif-display mt-2.5 text-xl font-semibold ${
                        ms.completed
                          ? 'line-through text-slate-400'
                          : 'text-white'
                      }`}
                    >
                      {ms.title}
                    </h3>

                    {ms.notes && (
                      <p className="mt-1.5 text-xs leading-relaxed text-slate-300">
                        {ms.notes}
                      </p>
                    )}

                    {/* Mini Live Breakdown when upcoming */}
                    {!ms.completed && !remaining.isPast && (
                      <div className="mt-4 flex items-center gap-4 border-t border-slate-800/80 pt-3 text-xs text-slate-300">
                        <div>
                          <span className="font-mono-tabular font-semibold text-white">
                            {remaining.days}
                          </span>{' '}
                          days
                        </div>
                        <span aria-hidden="true">·</span>
                        <div>
                          <span className="font-mono-tabular font-semibold text-white">
                            {remaining.hours}
                          </span>{' '}
                          hrs
                        </div>
                        <span aria-hidden="true">·</span>
                        <div>
                          <span className="font-mono-tabular font-semibold text-white">
                            {remaining.minutes}
                          </span>{' '}
                          mins
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Card Actions */}
                  <div className="mt-4 flex items-center justify-between border-t border-slate-800/80 pt-3">
                    <button
                      type="button"
                      onClick={() => onToggleMilestoneComplete(ms.id)}
                      aria-label={
                        ms.completed
                          ? `Mark ${ms.title} incomplete`
                          : `Complete ${ms.title}`
                      }
                      className="inline-flex items-center gap-1.5 text-xs font-medium text-sky-200 hover:text-white whitespace-nowrap shrink-0"
                    >
                      {ms.completed ? (
                        <CheckCircle2 className="h-4 w-4 text-emerald-400" />
                      ) : (
                        <Circle className="h-4 w-4 text-slate-400" />
                      )}
                      {ms.completed ? 'Done' : 'Mark Complete'}
                    </button>

                    <div className="flex items-center gap-1">
                      <button
                        type="button"
                        onClick={() => onMoveMilestone(ms.id, 'up')}
                        disabled={idx === 0}
                        aria-label={`Move ${ms.title} earlier`}
                        className="rounded-lg p-1.5 text-slate-400 hover:bg-slate-800 hover:text-white disabled:opacity-30"
                      >
                        <ArrowUp className="h-3.5 w-3.5" />
                      </button>
                      <button
                        type="button"
                        onClick={() => onMoveMilestone(ms.id, 'down')}
                        disabled={idx === filteredMilestones.length - 1}
                        aria-label={`Move ${ms.title} later`}
                        className="rounded-lg p-1.5 text-slate-400 hover:bg-slate-800 hover:text-white disabled:opacity-30"
                      >
                        <ArrowDown className="h-3.5 w-3.5" />
                      </button>
                      <button
                        type="button"
                        onClick={() => handleOpenEdit(ms)}
                        aria-label={`Edit ${ms.title}`}
                        className="rounded-lg p-1.5 text-slate-400 hover:bg-slate-800 hover:text-white"
                      >
                        <Edit3 className="h-3.5 w-3.5" />
                      </button>
                      {confirmDeleteMilestoneId === ms.id ? (
                        <div className="flex items-center gap-1 rounded-lg border border-rose-400/40 bg-rose-950/60 px-2 py-1 text-[11px]">
                          <button
                            type="button"
                            onClick={() => {
                              onDeleteMilestone(ms.id);
                              setConfirmDeleteMilestoneId(null);
                            }}
                            className="font-semibold text-rose-200 hover:text-white"
                          >
                            Confirm
                          </button>
                          <button
                            type="button"
                            onClick={() => setConfirmDeleteMilestoneId(null)}
                            className="text-slate-400 hover:text-white"
                          >
                            Cancel
                          </button>
                        </div>
                      ) : (
                        <button
                          type="button"
                          onClick={() => setConfirmDeleteMilestoneId(ms.id)}
                          aria-label={`Delete ${ms.title}`}
                          className="rounded-lg p-1.5 text-slate-400 hover:bg-rose-950/60 hover:text-rose-300"
                        >
                          <Trash2 className="h-3.5 w-3.5" />
                        </button>
                      )}
                    </div>
                  </div>
                </article>
              );
            })}
          </div>
        )}

        {/* Interactive Holiday Timeline Strip */}
        <div className="rounded-2xl border border-sky-200/15 bg-slate-900/60 p-6 backdrop-blur-md">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Calendar className="h-4 w-4 text-amber-300" />
              <h3 className="font-serif-display text-xl font-semibold text-white">
                Interactive Season Progression Timeline
              </h3>
            </div>
            <span className="font-mono-tabular text-xs text-slate-400">
              {completedCount}/{milestones.length} Milestones Reached
            </span>
          </div>

          <div className="mt-5 grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-7">
            {sortedMilestones.map((ms, index) => {
              const rem = calculateMilestoneTimeRemaining(ms.targetDate, now);
              return (
                <button
                  key={ms.id}
                  type="button"
                  onClick={() => onToggleMilestoneComplete(ms.id)}
                  className={`group text-left rounded-xl border p-3 transition ${
                    ms.completed
                      ? 'border-emerald-400/30 bg-emerald-950/20'
                      : 'border-slate-800 bg-slate-950/60 hover:border-sky-300/30'
                  }`}
                >
                  <div className="flex items-center justify-between text-xs text-slate-400">
                    <span className="font-mono-tabular">0{index + 1}.</span>
                    <span
                      className={
                        ms.completed
                          ? 'text-emerald-300 font-medium'
                          : 'text-sky-300 font-mono-tabular'
                      }
                    >
                      {ms.completed ? 'Done' : rem.formattedLabel}
                    </span>
                  </div>
                  <p className="mt-1.5 truncate text-xs font-semibold text-white group-hover:text-sky-200">
                    {ms.title}
                  </p>
                </button>
              );
            })}
          </div>
        </div>
      </section>
    </div>
  );
};
