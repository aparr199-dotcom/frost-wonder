import React, { useRef, useState } from 'react';
import {
  Apple,
  Check,
  Code2,
  Copy,
  Download,
  Laptop,
  Lock,
  Maximize2,
  Monitor,
  ShieldCheck,
  Sparkles,
} from 'lucide-react';
import {
  CountdownState,
  FamilyBudgetSummary,
  HolidayMilestone,
} from '../types/holiday';
import { GENERATED_ASSETS } from '../data/seedData';
import { PWAInstallButton } from './PWAInstallButton';

interface MacExperienceStudioProps {
  countdown: CountdownState;
  milestones: HolidayMilestone[];
  budgetSummary: FamilyBudgetSummary;
  onLaunchScreenSaver: () => void;
}

const SWIFT_WIDGETKIT_CODE = `// Sources/FrostWonderWidget/FrostWonderWidget.swift — macOS Sonoma / Sequoia Desktop & Notification Center Widget
import WidgetKit
import SwiftUI

struct ChristmasEntry: TimelineEntry {
    let date: Date
    let targetYear: Int
    let daysRemaining: Int
    let hoursRemaining: Int
    let minutesRemaining: Int
    let isChristmasDay: Bool
    let nextMilestone: String
}

struct FrostWonderProvider: TimelineProvider {
    func placeholder(in context: Context) -> ChristmasEntry {
        ChristmasEntry(date: Date(), targetYear: 2026, daysRemaining: 38, hoursRemaining: 14, minutesRemaining: 22, isChristmasDay: false, nextMilestone: "Tree Decorating")
    }

    func getSnapshot(in context: Context, completion: @escaping (ChristmasEntry) -> ()) {
        completion(makeEntry(for: Date()))
    }

    func getTimeline(in context: Context, completion: @escaping (Timeline<ChristmasEntry>) -> ()) {
        var entries: [ChristmasEntry] = []
        let now = Date()
        for minuteOffset in 0..<60 {
            if let entryDate = Calendar.current.date(byAdding: .minute, value: minuteOffset, to: now) {
                entries.append(makeEntry(for: entryDate))
            }
        }
        completion(Timeline(entries: entries, policy: .atEnd))
    }

    // Matches TypeScript calculateChristmasCountdown across Dec 25 & Dec 26-31 rollover
    private func makeEntry(for date: Date) -> ChristmasEntry {
        let calendar = Calendar.current
        let year = calendar.component(.year, from: date)
        let month = calendar.component(.month, from: date)
        let day = calendar.component(.day, from: date)

        if month == 12 && day == 25 {
            return ChristmasEntry(date: date, targetYear: year, daysRemaining: 0, hoursRemaining: 0, minutesRemaining: 0, isChristmasDay: true, nextMilestone: "Merry Christmas!")
        }

        let targetYear = (month == 12 && day > 25) ? (year + 1) : year
        let target = calendar.date(from: DateComponents(year: targetYear, month: 12, day: 25, hour: 0, minute: 0)) ?? date
        let totalSeconds = max(0, Int(target.timeIntervalSince(date)))
        return ChristmasEntry(
            date: date,
            targetYear: targetYear,
            daysRemaining: totalSeconds / 86_400,
            hoursRemaining: (totalSeconds % 86_400) / 3_600,
            minutesRemaining: (totalSeconds % 3_600) / 60,
            isChristmasDay: false,
            nextMilestone: "Christmas Morning"
        )
    }
}`;

const SWIFT_MENUBAR_AND_LOGIN_CODE = `// Sources/FrostWonderMacApp/FrostWonderMacApp.swift — Native macOS App + MenuBarExtra + SMAppService
import SwiftUI
import ServiceManagement
import FrostWonderShared

@main
struct FrostWonderMacApp: App {
    @AppStorage("launchAtLogin") private var launchAtLogin = false

    private var snapshot: ChristmasCountdownSnapshot {
        ChristmasCountdownMath.calculate(now: Date())
    }

    var body: some Scene {
        WindowGroup("Frost & Wonder — Christmas Countdown") {
            FrostWonderNativeCompanionView()
                .frame(minWidth: 760, minHeight: 520)
        }
        // Native macOS Menu Bar Extra Countdown
        MenuBarExtra(
            snapshot.isChristmasMorning ? "🎄 Merry Christmas!" : "🎄 \\(snapshot.days)d \\(snapshot.hours)h to Christmas",
            systemImage: "snowflake"
        ) {
            VStack(alignment: .leading, spacing: 10) {
                Text("Frost & Wonder Countdown")
                    .font(.headline)
                Text("\\(snapshot.days)d \\(snapshot.hours)h \\(snapshot.minutes)m Until Dec 25, \\(String(snapshot.targetYear))")
                    .font(.system(.subheadline, design: .monospaced))
                Divider()
                Toggle("Launch at Login on Mac Sign-In", isOn: $launchAtLogin)
                    .onChange(of: launchAtLogin) { _, enabled in
                        try? enabled ? SMAppService.mainApp.register() : SMAppService.mainApp.unregister()
                    }
                Divider()
                Button("Quit Frost & Wonder") {
                    NSApplication.shared.terminate(nil)
                }
            }
            .padding(12)
        }
    }
}`;

const SWIFT_SCREENSAVER_CODE = `// Sources/FrostWonderSaver/FrostWonderSaverView.swift — 100% Offline Native SwiftUI ScreenSaverKit (.saver)
// Zero dependency on localhost:3000 or network access; renders native 60fps Canvas snowfall & Ice Palace
import ScreenSaver
import SwiftUI

@objc(FrostWonderSaverView)
final class FrostWonderSaverView: ScreenSaverView {
    private var hostingView: NSHostingView<FrostWonderNativeSaverCanvas>?

    override init?(frame: NSRect, isPreview: Bool) {
        super.init(frame: frame, isPreview: isPreview)
        self.animationTimeInterval = 1.0 / 30.0
        setupNativeCanvas()
    }

    required init?(coder: NSCoder) {
        super.init(coder: coder)
        self.animationTimeInterval = 1.0 / 30.0
        setupNativeCanvas()
    }

    private func setupNativeCanvas() {
        let rootView = FrostWonderNativeSaverCanvas(isPreview: isPreview)
        let host = NSHostingView(rootView: rootView)
        host.frame = bounds
        host.autoresizingMask = [.width, .height]
        addSubview(host)
        self.hostingView = host
    }
}`;

export const MacExperienceStudio: React.FC<MacExperienceStudioProps> = ({
  countdown,
  milestones,
  budgetSummary,
  onLaunchScreenSaver,
}) => {
  const [widgetSize, setWidgetSize] = useState<'medium' | 'large'>('large');
  const [launchAtLoginSimulated, setLaunchAtLoginSimulated] = useState(true);
  const [activeCodeTab, setActiveCodeTab] = useState<
    'widgetkit' | 'menubar' | 'screensaver'
  >('widgetkit');
  const [copiedCode, setCopiedCode] = useState(false);
  const [wallpaperExported, setWallpaperExported] = useState(false);
  const exportCanvasRef = useRef<HTMLCanvasElement | null>(null);

  const upcomingMilestone =
    milestones.find((m) => !m.completed) || milestones[0];

  const handleCopySwiftCode = () => {
    const code =
      activeCodeTab === 'widgetkit'
        ? SWIFT_WIDGETKIT_CODE
        : activeCodeTab === 'menubar'
        ? SWIFT_MENUBAR_AND_LOGIN_CODE
        : SWIFT_SCREENSAVER_CODE;
    navigator.clipboard?.writeText(code).catch(() => {});
    setCopiedCode(true);
    window.setTimeout(() => setCopiedCode(false), 2500);
  };

  // Generates a coordinated 2560x1440 macOS Lock Screen & Desktop Wallpaper PNG
  const handleDownloadCoordinatedWallpaper = () => {
    const canvas = exportCanvasRef.current;
    if (!canvas) return;
    canvas.width = 2560;
    canvas.height = 1440;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const drawWallpaperOverlay = () => {
      // Subtle top lock-screen clock safe zone & bottom countdown crest
      const scrim = ctx.createLinearGradient(0, 0, 0, 1440);
      scrim.addColorStop(0, 'rgba(7, 13, 31, 0.55)');
      scrim.addColorStop(0.5, 'rgba(7, 13, 31, 0.2)');
      scrim.addColorStop(1, 'rgba(7, 13, 31, 0.85)');
      ctx.fillStyle = scrim;
      ctx.fillRect(0, 0, 2560, 1440);

      // Decorative snowflakes
      ctx.fillStyle = 'rgba(224, 242, 254, 0.45)';
      for (let i = 0; i < 120; i++) {
        const x = (i * 197) % 2560;
        const y = (i * 311) % 1440;
        const r = (i % 4) + 1.5;
        ctx.beginPath();
        ctx.arc(x, y, r, 0, Math.PI * 2);
        ctx.fill();
      }

      // Bottom Lock-Screen Coordinated Crest (leaves top center clear for macOS Sonoma/Sequoia Lock Screen clock)
      ctx.fillStyle = 'rgba(15, 23, 42, 0.78)';
      ctx.strokeStyle = 'rgba(125, 211, 252, 0.45)';
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.roundRect(780, 1080, 1000, 220, 36);
      ctx.fill();
      ctx.stroke();

      ctx.textAlign = 'center';
      ctx.fillStyle = '#bae6fd';
      ctx.font = '600 26px "Plus Jakarta Sans", sans-serif';
      ctx.fillText(
        '✨ FROST & WONDER · ENCHANTED WINTER KINGDOM ✨',
        1280,
        1140
      );

      ctx.fillStyle = '#ffffff';
      ctx.font = '700 64px "JetBrains Mono", monospace';
      ctx.fillText(
        `${countdown.days}D : ${String(countdown.hours).padStart(
          2,
          '0'
        )}H : ${String(countdown.minutes).padStart(2, '0')}M TO CHRISTMAS`,
        1280,
        1218
      );

      ctx.fillStyle = '#fde68a';
      ctx.font = '500 24px "Cormorant Garamond", Georgia, serif';
      ctx.fillText(
        `Coordinated macOS Lock Screen & Desktop Wallpaper · December 25, ${countdown.targetYear}`,
        1280,
        1268
      );

      try {
        const dataUrl = canvas.toDataURL('image/png');
        const a = document.createElement('a');
        a.href = dataUrl;
        a.download = `Frost-and-Wonder-macOS-Wallpaper-${countdown.targetYear}.png`;
        a.click();
        setWallpaperExported(true);
        window.setTimeout(() => setWallpaperExported(false), 3500);
      } catch {
        setWallpaperExported(true);
      }
    };

    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => {
      ctx.drawImage(img, 0, 0, 2560, 1440);
      drawWallpaperOverlay();
    };
    img.onerror = () => {
      const bg = ctx.createLinearGradient(0, 0, 2560, 1440);
      bg.addColorStop(0, '#070d1f');
      bg.addColorStop(0.5, '#13264e');
      bg.addColorStop(1, '#1e1b4b');
      ctx.fillStyle = bg;
      ctx.fillRect(0, 0, 2560, 1440);
      drawWallpaperOverlay();
    };
    img.src = GENERATED_ASSETS.heroIcePalace;
  };

  return (
    <div className="space-y-10">
      <canvas ref={exportCanvasRef} className="hidden" aria-hidden="true" />

      {/* Header */}
      <div className="flex flex-col justify-between gap-4 border-b border-sky-200/15 pb-6 lg:flex-row lg:items-end">
        <div>
          <p className="text-xs font-medium text-sky-300">
            macOS Desktop, Menu Bar, Screen Saver &amp; Native SwiftUI Bridge
          </p>
          <h1 className="font-serif-display mt-1 text-3xl font-semibold text-white sm:text-4xl">
            Mac Lock Screen, Screen Saver &amp; Desktop Studio
          </h1>
          <p className="mt-1 text-sm text-slate-300">
            Enjoy Frost &amp; Wonder as an installable macOS Web App, launch the interactive Full-Screen Christmas Screen Saver, download a coordinated Lock Screen wallpaper, or build the native SwiftUI extensions.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <a
            href="/Frost-and-Wonder-macOS-Project.zip"
            download="Frost-and-Wonder-macOS-Project.zip"
            className="inline-flex items-center gap-2 rounded-xl border border-amber-300/40 bg-amber-300/15 px-4 py-2.5 text-xs font-semibold text-amber-100 transition hover:bg-amber-300/25 whitespace-nowrap shrink-0"
          >
            <Download className="h-4 w-4 text-amber-300" />
            Download Full Project (.ZIP)
          </a>
          <PWAInstallButton />
          <button
            type="button"
            onClick={onLaunchScreenSaver}
            className="inline-flex items-center gap-2 rounded-xl bg-sky-300 px-4 py-2.5 text-xs font-semibold text-slate-950 transition hover:bg-sky-200 whitespace-nowrap shrink-0"
          >
            <Maximize2 className="h-4 w-4" />
            Launch Animated Christmas Screen Saver
          </button>
        </div>
      </div>

      {/* Live Interactive macOS Sonoma / Sequoia Desktop & Menu Bar Preview */}
      <section
        aria-label="macOS Desktop and Menu Bar Interactive Simulation"
        className="overflow-hidden rounded-3xl border border-sky-200/25 bg-[#091328] shadow-2xl"
      >
        {/* Simulated macOS Top Menu Bar */}
        <div className="flex items-center justify-between border-b border-white/10 bg-slate-950/90 px-4 py-2 text-xs text-slate-200 backdrop-blur-xl">
          <div className="flex items-center gap-4">
            <span className="font-semibold text-white"></span>
            <span className="font-semibold text-sky-200">Frost &amp; Wonder</span>
            <span className="hidden text-slate-400 sm:inline">File</span>
            <span className="hidden text-slate-400 sm:inline">View</span>
            <span className="hidden text-slate-400 sm:inline">Window</span>
          </div>

          {/* Menu Bar Countdown Extra */}
          <div className="flex items-center gap-4">
            <div
              title="macOS MenuBarExtra Live Countdown"
              className="flex items-center gap-1.5 rounded-md border border-sky-300/35 bg-sky-400/15 px-2.5 py-0.5 font-mono-tabular text-xs font-semibold text-sky-100"
            >
              <span>🎄 {countdown.days}d {countdown.hours}h to Christmas</span>
            </div>
            <span className="font-mono-tabular hidden text-slate-300 md:inline">
              {new Date().toLocaleTimeString([], {
                hour: '2-digit',
                minute: '2-digit',
              })}
            </span>
          </div>
        </div>

        {/* Simulated macOS Desktop Surface with Interactive WidgetKit Preview */}
        <div className="relative p-6 sm:p-10">
          <div className="absolute inset-0">
            <img
              src={GENERATED_ASSETS.heroIcePalace}
              alt="macOS Coordinated Winter Desktop Wallpaper"
              referrerPolicy="no-referrer"
              className="h-full w-full object-cover opacity-45"
              onError={(e) => {
                e.currentTarget.style.display = 'none';
              }}
            />
            <div className="absolute inset-0 bg-gradient-to-r from-[#070d1f]/90 via-[#070d1f]/65 to-[#070d1f]/85" />
          </div>

          <div className="relative z-10 grid grid-cols-1 gap-8 lg:grid-cols-12 lg:items-center">
            {/* Left: Interactive macOS Desktop Widget Preview */}
            <div className="space-y-4 lg:col-span-7">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <span className="text-xs font-medium text-sky-200">
                  Live macOS Desktop Widget Preview (WidgetKit)
                </span>
                <div
                  role="group"
                  aria-label="Desktop widget size"
                  className="flex items-center gap-1 rounded-xl border border-slate-700 bg-slate-950/80 p-1"
                >
                  <button
                    type="button"
                    onClick={() => setWidgetSize('medium')}
                    className={`rounded-lg px-2.5 py-1 text-xs font-medium transition ${
                      widgetSize === 'medium'
                        ? 'bg-sky-400/25 text-sky-100'
                        : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    systemMedium
                  </button>
                  <button
                    type="button"
                    onClick={() => setWidgetSize('large')}
                    className={`rounded-lg px-2.5 py-1 text-xs font-medium transition ${
                      widgetSize === 'large'
                        ? 'bg-sky-400/25 text-sky-100'
                        : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    systemLarge
                  </button>
                </div>
              </div>

              {/* Frosted Glass Widget Card */}
              <div
                className={`rounded-3xl border border-white/20 bg-slate-950/75 p-6 shadow-2xl backdrop-blur-2xl transition-all ${
                  widgetSize === 'medium' ? 'max-w-md' : 'max-w-xl'
                }`}
              >
                <div className="flex items-center justify-between text-xs text-sky-200">
                  <span className="font-semibold tracking-wider">
                    ✨ FROST &amp; WONDER DESKTOP WIDGET
                  </span>
                  <span className="font-mono-tabular text-amber-200">
                    Dec 25, {countdown.targetYear}
                  </span>
                </div>

                <div className="mt-4 grid grid-cols-4 gap-3 text-center">
                  {[
                    { l: 'DAYS', v: countdown.days },
                    { l: 'HRS', v: countdown.hours },
                    { l: 'MIN', v: countdown.minutes },
                    { l: 'SEC', v: countdown.seconds },
                  ].map((u) => (
                    <div
                      key={u.l}
                      className="rounded-2xl border border-sky-200/15 bg-white/5 py-3"
                    >
                      <div className="font-mono-tabular text-2xl font-bold text-white sm:text-3xl">
                        {String(u.v).padStart(2, '0')}
                      </div>
                      <div className="mt-0.5 text-[10px] font-semibold tracking-widest text-sky-200">
                        {u.l}
                      </div>
                    </div>
                  ))}
                </div>

                {widgetSize === 'large' && (
                  <div className="mt-4 space-y-2 border-t border-white/10 pt-4 text-xs">
                    <div className="flex items-center justify-between text-slate-300">
                      <span>Next Holiday Milestone:</span>
                      <span className="font-semibold text-white">
                        {upcomingMilestone
                          ? upcomingMilestone.title
                          : 'Christmas Morning'}
                      </span>
                    </div>
                    <div className="flex items-center justify-between text-slate-300">
                      <span>Family Gift Readiness:</span>
                      <span className="font-mono-tabular font-semibold text-emerald-300">
                        {budgetSummary.totalWrappedOrReadyCount} of{' '}
                        {budgetSummary.totalGiftsCount} Gifts Wrapped/Ready
                      </span>
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* Right: Wallpaper Exporter & Launch at Sign-In Controls */}
            <div className="space-y-4 rounded-2xl border border-sky-200/20 bg-slate-950/80 p-6 backdrop-blur-xl lg:col-span-5">
              <h2 className="font-serif-display text-2xl font-semibold text-white">
                Coordinated Wallpaper &amp; Sign-In Options
              </h2>
              <p className="text-xs leading-relaxed text-slate-300">
                Export a custom 4K (2560×1440) Ice Palace wallpaper formatted for the macOS Sonoma/Sequoia Lock Screen clock, or configure launch behavior.
              </p>

              <button
                type="button"
                onClick={handleDownloadCoordinatedWallpaper}
                className="flex w-full items-center justify-center gap-2 rounded-xl bg-amber-300 px-4 py-2.5 text-xs font-semibold text-slate-950 transition hover:bg-amber-200"
              >
                <Download className="h-4 w-4" />
                {wallpaperExported
                  ? '4K Lock Screen Wallpaper Downloaded!'
                  : 'Download Coordinated 4K Mac Wallpaper (.PNG)'}
              </button>

              <div className="rounded-xl border border-slate-800 bg-slate-900/90 p-3.5">
                <label className="flex cursor-pointer items-center justify-between gap-3 text-xs">
                  <div>
                    <span className="font-semibold text-white">
                      Auto-Launch Full-Screen Mode on App Start
                    </span>
                    <p className="mt-0.5 text-[11px] text-slate-400">
                      Also supports URL parameter <code>?autostart=1</code> or{' '}
                      <code>?screensaver=1</code> for macOS Login Items.
                    </p>
                  </div>
                  <input
                    type="checkbox"
                    checked={launchAtLoginSimulated}
                    onChange={(e) =>
                      setLaunchAtLoginSimulated(e.target.checked)
                    }
                    className="h-4 w-4 rounded border-slate-700 bg-slate-950 text-sky-400"
                  />
                </label>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Honest Engineering Audit: Implemented vs Visual Demo vs Native macOS */}
      <section
        aria-label="Engineering Transparency and macOS Lock Screen Security Boundaries"
        className="grid grid-cols-1 gap-6 lg:grid-cols-3"
      >
        <div className="rounded-2xl border border-emerald-400/25 bg-slate-900/75 p-6 backdrop-blur-md">
          <div className="flex items-center gap-2 text-xs font-semibold text-emerald-300">
            <ShieldCheck className="h-4 w-4" />
            <span>1. Fully Implemented in This Web/PWA App</span>
          </div>
          <h3 className="font-serif-display mt-2 text-2xl font-semibold text-white">
            Working Production Features
          </h3>
          <ul className="mt-3 space-y-2 text-xs leading-relaxed text-slate-300">
            <li>
              • <strong>Interactive 3D-Projected Snow Globe</strong> with drag rotation, pointer vortex physics, lighting modes, and reduced-motion accessibility.
            </li>
            <li>
              • <strong>Live Local-Timezone Countdown</strong> to Dec 25, seasonal atmosphere escalation, and Christmas Morning celebration mode.
            </li>
            <li>
              • <strong>Mini Countdowns &amp; Milestones</strong> with create, edit, complete, delete, and custom reordering.
            </li>
            <li>
              • <strong>Family Gift Manager &amp; 7-Stage Pipeline</strong> with Secret Santa Cloak mode and isolated Judge Demo sandbox.
            </li>
            <li>
              • <strong>Zero-Double-Counting Budget Command Center</strong>, Full-Screen Animated Screen Saver Display, 4K Wallpaper PNG Generator, and Offline-Ready PWA.
            </li>
          </ul>
        </div>

        <div className="rounded-2xl border border-sky-300/25 bg-slate-900/75 p-6 backdrop-blur-md">
          <div className="flex items-center gap-2 text-xs font-semibold text-sky-300">
            <Monitor className="h-4 w-4" />
            <span>2. Interactive Visual Demonstrations</span>
          </div>
          <h3 className="font-serif-display mt-2 text-2xl font-semibold text-white">
            Browser-Hosted System Previews
          </h3>
          <ul className="mt-3 space-y-2 text-xs leading-relaxed text-slate-300">
            <li>
              • <strong>macOS Desktop Widget Preview</strong>: Accurately models the <code>systemMedium</code> and <code>systemLarge</code> WidgetKit layout using live app state inside the studio preview above.
            </li>
            <li>
              • <strong>macOS Menu Bar Countdown Preview</strong>: Demonstrates the <code>MenuBarExtra</code> status item in the simulated top bar while updating the real browser tab title with live days remaining.
            </li>
            <li>
              • <strong>Screen Saver vs. System Lock Screen</strong>: Our Full-Screen Display runs via the HTML5 Fullscreen API as an interactive ambient display, never pretending to bypass macOS authentication.
            </li>
          </ul>
        </div>

        <div className="rounded-2xl border border-amber-300/25 bg-slate-900/75 p-6 backdrop-blur-md">
          <div className="flex items-center gap-2 text-xs font-semibold text-amber-300">
            <Lock className="h-4 w-4" />
            <span>3. Native macOS APIs &amp; Lock Screen Rules</span>
          </div>
          <h3 className="font-serif-display mt-2 text-2xl font-semibold text-white">
            macOS Security &amp; Native SwiftUI
          </h3>
          <p className="mt-3 text-xs leading-relaxed text-slate-300">
            <strong>Important macOS Lock Screen Restriction:</strong> macOS strictly prohibits third-party apps or web pages from rendering interactive custom UI directly over the system authentication Lock Screen (`loginwindow`) to preserve FileVault and Touch ID security.
          </p>
          <p className="mt-2 text-xs leading-relaxed text-slate-300">
            To run natively outside the browser on macOS Sonoma/Sequoia, compile the provided Swift files below into a signed Xcode target using <strong>WidgetKit</strong> (Desktop Widgets), <strong>ScreenSaverKit</strong> (`.saver` bundle), <strong>MenuBarExtra</strong>, and <strong>SMAppService.mainApp</strong> (Launch at Login).
          </p>
        </div>
      </section>

      {/* Native SwiftUI / WidgetKit / ScreenSaverKit Blueprint Code Viewer */}
      <section
        aria-label="Native macOS SwiftUI Source Code Blueprints"
        className="rounded-2xl border border-sky-200/15 bg-slate-900/80 p-6 backdrop-blur-md"
      >
        <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-800 pb-4">
          <div className="flex items-center gap-2">
            <Code2 className="h-5 w-5 text-sky-300" />
            <div>
              <h2 className="font-serif-display text-2xl font-semibold text-white">
                Buildable Native macOS Project (`macos-native/`)
              </h2>
              <p className="text-xs text-slate-400">
                Complete SwiftPM + Xcode 16 project structure with XCTest suite, offline SwiftUI `.saver` bundle, `MenuBarExtra`, and `WidgetKit`
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            {(
              [
                { id: 'widgetkit', label: 'WidgetKit Desktop Extension' },
                { id: 'menubar', label: 'MenuBarExtra & Launch at Login' },
                { id: 'screensaver', label: 'Offline ScreenSaverKit (.saver)' },
              ] as const
            ).map((tab) => (
              <button
                key={tab.id}
                type="button"
                onClick={() => setActiveCodeTab(tab.id)}
                className={`rounded-xl px-3 py-1.5 text-xs font-medium transition whitespace-nowrap shrink-0 ${
                  activeCodeTab === tab.id
                    ? 'bg-sky-400/20 text-sky-100 border border-sky-300/30'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                {tab.label}
              </button>
            ))}

            <button
              type="button"
              onClick={handleCopySwiftCode}
              className="inline-flex items-center gap-1.5 rounded-xl bg-slate-800 px-3 py-1.5 text-xs font-medium text-sky-200 hover:bg-slate-700 whitespace-nowrap shrink-0"
            >
              {copiedCode ? (
                <>
                  <Check className="h-3.5 w-3.5 text-emerald-300" />
                  Copied Swift Code
                </>
              ) : (
                <>
                  <Copy className="h-3.5 w-3.5" />
                  Copy Swift File
                </>
              )}
            </button>
          </div>
        </div>

        {/* Native Build Instructions Summary */}
        <div className="mt-4 grid grid-cols-1 gap-3 rounded-xl border border-slate-800 bg-slate-950/80 p-4 text-xs text-slate-300 md:grid-cols-3">
          <div>
            <strong className="text-sky-200">1. Build &amp; Test via SwiftPM / Xcode:</strong>
            <p className="mt-1 text-slate-400">
              Unzip the project, run <code>cd macos-native &amp;&amp; ./build-macos.sh</code> or <code>open Package.swift</code> in Xcode 16+ to build <code>FrostWonderMacApp.app</code> and run <code>swift test</code>.
            </p>
          </div>
          <div>
            <strong className="text-emerald-200">2. Zero Localhost Screen Saver:</strong>
            <p className="mt-1 text-slate-400">
              <code>build-macos.sh</code> compiles <code>FrostWonderSaver.saver</code> as a 100% offline native SwiftUI <code>Canvas</code> bundle and installs it to <code>~/Library/Screen Savers/</code>.
            </p>
          </div>
          <div>
            <strong className="text-amber-200">3. Identical Year-Boundary Math:</strong>
            <p className="mt-1 text-slate-400">
              <code>ChristmasCountdownMath.swift</code> and TypeScript <code>calculateChristmasCountdown</code> share identical Dec 25 celebration &amp; Dec 26–31 automatic rollover logic.
            </p>
          </div>
        </div>

        <pre className="font-mono-tabular mt-4 max-h-80 overflow-x-auto rounded-xl border border-slate-800 bg-slate-950 p-4 text-xs leading-relaxed text-sky-100">
          <code>
            {activeCodeTab === 'widgetkit'
              ? SWIFT_WIDGETKIT_CODE
              : activeCodeTab === 'menubar'
              ? SWIFT_MENUBAR_AND_LOGIN_CODE
              : SWIFT_SCREENSAVER_CODE}
          </code>
        </pre>
      </section>
    </div>
  );
};
