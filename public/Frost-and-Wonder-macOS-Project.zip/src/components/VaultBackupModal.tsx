import React, { useRef, useState } from 'react';
import {
  AlertTriangle,
  CheckCircle2,
  Copy,
  Database,
  Download,
  FileJson,
  Lock,
  ShieldAlert,
  Trash2,
  Upload,
  X,
} from 'lucide-react';
import {
  ChildProfile,
  GiftItem,
  HolidayMilestone,
} from '../types/holiday';
import {
  createVaultBackupPayload,
  validateAndParseVaultBackup,
} from '../utils/holidayLogic';

interface VaultBackupModalProps {
  isOpen: boolean;
  onClose: () => void;
  childrenProfiles: ChildProfile[];
  gifts: GiftItem[];
  milestones: HolidayMilestone[];
  householdBudget: number;
  targetYearOverride: number | null;
  onRestoreBackup: (data: {
    children: ChildProfile[];
    gifts: GiftItem[];
    milestones: HolidayMilestone[];
    householdBudget: number;
    targetYearOverride: number | null;
  }) => void;
  onClearPrivateVault: () => void;
}

export const VaultBackupModal: React.FC<VaultBackupModalProps> = ({
  isOpen,
  onClose,
  childrenProfiles,
  gifts,
  milestones,
  householdBudget,
  targetYearOverride,
  onRestoreBackup,
  onClearPrivateVault,
}) => {
  const [restoreJsonText, setRestoreJsonText] = useState('');
  const [validationMessage, setValidationMessage] = useState<{
    type: 'error' | 'success';
    text: string;
  } | null>(null);
  const [copiedBackup, setCopiedBackup] = useState(false);
  const [confirmResetOpen, setConfirmResetOpen] = useState(false);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  if (!isOpen) return null;

  const currentBackupPayload = createVaultBackupPayload({
    children: childrenProfiles,
    gifts,
    milestones,
    householdBudget,
    targetYearOverride,
  });

  const handleDownloadBackupJson = () => {
    const jsonString = JSON.stringify(currentBackupPayload, null, 2);
    const blob = new Blob([jsonString], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    const dateStr = new Date().toISOString().slice(0, 10);
    a.href = url;
    a.download = `Frost-and-Wonder-Vault-Backup-${dateStr}.json`;
    a.click();
    URL.revokeObjectURL(url);
    setValidationMessage({
      type: 'success',
      text: `Exported backup with ${childrenProfiles.length} child profiles, ${gifts.length} gifts, and ${milestones.length} milestones.`,
    });
  };

  const handleCopyBackupJson = () => {
    const jsonString = JSON.stringify(currentBackupPayload, null, 2);
    navigator.clipboard?.writeText(jsonString).catch(() => {});
    setCopiedBackup(true);
    window.setTimeout(() => setCopiedBackup(false), 2500);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        setRestoreJsonText(reader.result);
        setValidationMessage(null);
      }
    };
    reader.readAsText(file);
  };

  const handleValidateAndRestore = (e: React.FormEvent) => {
    e.preventDefault();
    const res = validateAndParseVaultBackup(restoreJsonText);
    if (!res.valid) {
      setValidationMessage({
        type: 'error',
        text: res.error,
      });
      return;
    }

    onRestoreBackup(res.data);
    setValidationMessage({
      type: 'success',
      text: `Successfully validated and restored ${res.data.children.length} child profiles, ${res.data.gifts.length} gifts, and ${res.data.milestones.length} milestones!`,
    });
    setRestoreJsonText('');
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="Private Family Vault Backup, Restore, and Data Protection"
      className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/85 p-4 backdrop-blur-md"
    >
      <div className="max-h-[88vh] w-full max-w-2xl overflow-y-auto rounded-3xl border border-sky-200/30 bg-slate-900 p-6 shadow-2xl sm:p-8">
        <div className="sticky top-0 z-10 -mx-2 flex items-start justify-between gap-4 border-b border-slate-800 bg-slate-900/95 px-2 pb-4 backdrop-blur-md">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl border border-sky-300/30 bg-sky-400/15">
              <Database className="h-5 w-5 text-sky-300" />
            </div>
            <div>
              <h2 className="font-serif-display text-2xl font-semibold text-white">
                Private Family Vault — Backup, Restore &amp; Privacy
              </h2>
              <p className="text-xs text-slate-400">
                Currently storing {childrenProfiles.length} children ·{' '}
                {gifts.length} gifts · {milestones.length} milestones
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            aria-label="Close Data Protection Modal"
            className="rounded-lg p-1.5 text-slate-400 hover:bg-slate-800 hover:text-white"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Status Alert */}
        {validationMessage && (
          <div
            role="alert"
            className={`mt-4 flex items-start gap-2.5 rounded-xl border p-3.5 text-xs ${
              validationMessage.type === 'error'
                ? 'border-rose-400/40 bg-rose-950/40 text-rose-200'
                : 'border-emerald-400/40 bg-emerald-950/40 text-emerald-200'
            }`}
          >
            {validationMessage.type === 'error' ? (
              <AlertTriangle className="h-4 w-4 shrink-0 text-rose-300" />
            ) : (
              <CheckCircle2 className="h-4 w-4 shrink-0 text-emerald-300" />
            )}
            <span>{validationMessage.text}</span>
          </div>
        )}

        {/* Section 1: Export Backup */}
        <div className="mt-5 rounded-2xl border border-sky-200/15 bg-slate-950/60 p-4">
          <h3 className="text-sm font-semibold text-white">
            1. Export Portable Vault Backup (.JSON)
          </h3>
          <p className="mt-1 text-xs text-slate-300">
            Save a validated JSON snapshot of your family profiles, wishlists, gift stages, budgets, and milestones to your Mac.
          </p>
          <div className="mt-3 flex flex-wrap items-center gap-3">
            <button
              type="button"
              onClick={handleDownloadBackupJson}
              className="inline-flex items-center gap-2 rounded-xl bg-sky-300 px-4 py-2 text-xs font-semibold text-slate-950 transition hover:bg-sky-200"
            >
              <Download className="h-3.5 w-3.5" />
              Download Backup (.JSON)
            </button>
            <button
              type="button"
              onClick={handleCopyBackupJson}
              className="inline-flex items-center gap-2 rounded-xl border border-slate-700 bg-slate-900 px-3.5 py-2 text-xs font-medium text-slate-200 hover:bg-slate-800"
            >
              <Copy className="h-3.5 w-3.5" />
              {copiedBackup ? 'Copied Backup JSON!' : 'Copy Backup JSON'}
            </button>
          </div>
        </div>

        {/* Section 2: Restore & Validate Backup */}
        <form
          onSubmit={handleValidateAndRestore}
          className="mt-4 rounded-2xl border border-sky-200/15 bg-slate-950/60 p-4"
        >
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div>
              <h3 className="text-sm font-semibold text-white">
                2. Restore &amp; Validate Backup
              </h3>
              <p className="mt-0.5 text-xs text-slate-300">
                Upload a `.json` backup file or paste backup JSON below. All records are strictly schema-validated before import.
              </p>
            </div>
            <div>
              <input
                ref={fileInputRef}
                type="file"
                accept=".json,application/json"
                onChange={handleFileUpload}
                className="hidden"
              />
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="inline-flex items-center gap-1.5 rounded-xl border border-sky-300/35 bg-sky-400/15 px-3 py-1.5 text-xs font-medium text-sky-100 hover:bg-sky-400/25"
              >
                <Upload className="h-3.5 w-3.5" />
                Choose .JSON File
              </button>
            </div>
          </div>

          <textarea
            rows={4}
            aria-label="Backup JSON content to validate and restore"
            value={restoreJsonText}
            onChange={(e) => {
              setRestoreJsonText(e.target.value);
              setValidationMessage(null);
            }}
            placeholder='Paste Frost & Wonder JSON backup here ({"schemaVersion": 1, "app": "Frost & Wonder", ...})'
            className="font-mono-tabular mt-3 w-full rounded-xl border border-slate-700 bg-slate-900 p-3 text-xs text-slate-100 placeholder:text-slate-500 focus:border-sky-400 focus:outline-none"
          />

          <div className="mt-3 flex justify-end">
            <button
              type="submit"
              className="inline-flex items-center gap-1.5 rounded-xl bg-amber-300 px-4 py-2 text-xs font-semibold text-slate-950 hover:bg-amber-200"
            >
              <FileJson className="h-3.5 w-3.5" />
              Validate &amp; Restore Backup
            </button>
          </div>
        </form>

        {/* Section 3: Browser Storage Transparency & Confirmation-Protected Reset */}
        <div className="mt-4 rounded-2xl border border-slate-800 bg-slate-950/60 p-4">
          <div className="flex items-start gap-2.5">
            <Lock className="mt-0.5 h-4 w-4 shrink-0 text-amber-300" />
            <div className="text-xs leading-relaxed text-slate-300">
              <strong className="text-white">
                Browser Storage &amp; Security Transparency:
              </strong>{' '}
              Your private family records are persisted locally on this Mac using browser{' '}
              <code>localStorage</code> and are never uploaded to external servers. Because browser{' '}
              <code>localStorage</code> is unencrypted on disk within your macOS user profile and can be cleared if you wipe browser site data, we recommend exporting a <code>.JSON</code> backup periodically and using <strong>Secret Santa Mode</strong> when planning around family members.
            </div>
          </div>

          <div className="mt-4 flex flex-wrap items-center justify-between gap-3 border-t border-slate-800/80 pt-3">
            <span className="text-xs text-slate-400">
              Need to start fresh with an empty private workspace?
            </span>

            {!confirmResetOpen ? (
              <button
                type="button"
                onClick={() => setConfirmResetOpen(true)}
                className="inline-flex items-center gap-1.5 rounded-xl border border-rose-400/35 bg-rose-950/30 px-3.5 py-1.5 text-xs font-medium text-rose-200 hover:bg-rose-950/50"
              >
                <Trash2 className="h-3.5 w-3.5" />
                Clear Private Vault...
              </button>
            ) : (
              <div className="flex flex-wrap items-center gap-2 rounded-xl border border-rose-400/50 bg-rose-950/50 px-3 py-2">
                <ShieldAlert className="h-4 w-4 text-rose-300" />
                <span className="text-xs font-semibold text-rose-100">
                  Confirm permanent reset of private vault?
                </span>
                <button
                  type="button"
                  onClick={() => {
                    onClearPrivateVault();
                    setConfirmResetOpen(false);
                    setValidationMessage({
                      type: 'success',
                      text: 'Private Family Vault has been reset to a clean, empty state.',
                    });
                  }}
                  className="rounded-lg bg-rose-500 px-3 py-1 text-xs font-semibold text-white hover:bg-rose-400"
                >
                  Yes, Wipe Private Vault
                </button>
                <button
                  type="button"
                  onClick={() => setConfirmResetOpen(false)}
                  className="rounded-lg border border-slate-700 bg-slate-900 px-2.5 py-1 text-xs text-slate-300 hover:text-white"
                >
                  Cancel
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
