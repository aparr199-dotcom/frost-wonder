import React, { useEffect, useRef, useState } from 'react';
import { Pause, Play, Wind } from 'lucide-react';
import { CountdownState } from '../types/holiday';

interface EnchantedSnowGlobeProps {
  countdown: CountdownState;
  onToggleSimulateChristmas: () => void;
  simulateChristmasMorning: boolean;
  externalSwirlTrigger?: number;
}

interface GlobeFlake3D {
  x: number; // -1 to 1 normalized sphere space
  y: number;
  z: number;
  vx: number;
  vy: number;
  vz: number;
  size: number;
  alpha: number;
  isStarFlake: boolean;
  layer: 'foreground' | 'midground' | 'background';
  phase: number;
}

export const EnchantedSnowGlobe: React.FC<EnchantedSnowGlobeProps> = ({
  countdown,
  externalSwirlTrigger = 0,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [reducedMotion, setReducedMotion] = useState(() =>
    typeof window !== 'undefined'
      ? window.matchMedia('(prefers-reduced-motion: reduce)').matches
      : false
  );
  const [swirlCount, setSwirlCount] = useState(0);
  const [globeTheme, setGlobeTheme] = useState<
    'twilight' | 'aurora' | 'solstice'
  >('twilight');

  // Interactive physics state stored in ref to avoid 60Hz React re-renders
  const interactionRef = useRef({
    yaw: 0,
    pitch: 0.05,
    targetYaw: 0,
    targetPitch: 0.05,
    wheelAngle: 0,
    isDragging: false,
    lastPointerX: 0,
    lastPointerY: 0,
    pointerNormX: 0,
    pointerNormY: 0,
    pointerActive: false,
    turbulence: 0.25,
    castleGlowBoost: 0,
  });

  const triggerShakeGlobe = () => {
    interactionRef.current.turbulence = 2.8;
    interactionRef.current.castleGlowBoost = 1.0;
    interactionRef.current.targetYaw += (Math.random() - 0.5) * 0.55;
    setSwirlCount((c) => c + 1);
  };

  useEffect(() => {
    if (externalSwirlTrigger > 0) {
      interactionRef.current.turbulence = 2.6;
      interactionRef.current.castleGlowBoost = 1.0;
    }
  }, [externalSwirlTrigger]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animId: number;
    const logicalSize = 460;
    const dpr =
      typeof window !== 'undefined'
        ? Math.min(2, window.devicePixelRatio || 1)
        : 1;
    canvas.width = logicalSize * dpr;
    canvas.height = logicalSize * dpr;

    const cx = logicalSize / 2;
    const cy = logicalSize / 2 - 22;
    const radius = 172;

    // Create 190 3D snowflakes & 6-pointed star crystals inside the unit sphere
    const flakes: GlobeFlake3D[] = Array.from({ length: 190 }, (_, idx) => {
      let x = 0;
      let y = 0;
      let z = 0;
      do {
        x = Math.random() * 2 - 1;
        y = Math.random() * 2 - 1;
        z = Math.random() * 2 - 1;
      } while (x * x + y * y + z * z > 0.92);

      const layer: GlobeFlake3D['layer'] =
        idx < 28 ? 'foreground' : idx < 115 ? 'midground' : 'background';

      return {
        x,
        y,
        z,
        vx: (Math.random() - 0.5) * 0.004,
        vy:
          layer === 'foreground'
            ? Math.random() * 0.0052 + 0.0028
            : layer === 'midground'
            ? Math.random() * 0.0042 + 0.002
            : Math.random() * 0.003 + 0.0014,
        vz: (Math.random() - 0.5) * 0.004,
        size:
          layer === 'foreground'
            ? Math.random() * 2.2 + 2.8
            : layer === 'midground'
            ? Math.random() * 1.5 + 1.4
            : Math.random() * 1.0 + 0.8,
        alpha:
          layer === 'foreground'
            ? Math.random() * 0.3 + 0.65
            : layer === 'midground'
            ? Math.random() * 0.35 + 0.45
            : Math.random() * 0.35 + 0.25,
        isStarFlake: idx < 22,
        layer,
        phase: Math.random() * Math.PI * 2,
      };
    });

    // Helper: draw 6-pointed crystalline star snowflake
    const drawStarSnowflake = (
      sx: number,
      sy: number,
      r: number,
      alpha: number,
      rotation: number
    ) => {
      ctx.save();
      ctx.translate(sx, sy);
      ctx.rotate(rotation);
      ctx.strokeStyle = `rgba(255, 255, 255, ${alpha})`;
      ctx.lineWidth = Math.max(1, r * 0.26);
      ctx.lineCap = 'round';
      for (let arm = 0; arm < 3; arm++) {
        const a = (arm * Math.PI) / 3;
        const dx = Math.cos(a) * r;
        const dy = Math.sin(a) * r;
        ctx.beginPath();
        ctx.moveTo(-dx, -dy);
        ctx.lineTo(dx, dy);
        ctx.stroke();
      }
      ctx.restore();
    };

    // Helper: draw lush snow-covered pine tree matching the reference artwork
    const drawSnowyEvergreen = (
      tx: number,
      ty: number,
      tw: number,
      th: number,
      tiers = 4
    ) => {
      for (let t = 0; t < tiers; t++) {
        const progress = t / tiers;
        const tierY = ty - progress * (th * 0.72);
        const tierW = tw * (1 - progress * 0.55);
        const tierH = th * 0.36;

        // Deep pine foliage shadow
        ctx.fillStyle = '#0c2e33';
        ctx.beginPath();
        ctx.moveTo(tx - tierW * 0.52, tierY);
        ctx.lineTo(tx, tierY - tierH);
        ctx.lineTo(tx + tierW * 0.52, tierY);
        ctx.closePath();
        ctx.fill();

        // Thick white snow mantle on boughs
        const snowGrad = ctx.createLinearGradient(
          tx - tierW * 0.4,
          tierY - tierH,
          tx + tierW * 0.4,
          tierY
        );
        snowGrad.addColorStop(0, '#ffffff');
        snowGrad.addColorStop(0.65, '#e0f2fe');
        snowGrad.addColorStop(1, '#7dd3fc');
        ctx.fillStyle = snowGrad;
        ctx.beginPath();
        ctx.moveTo(tx - tierW * 0.44, tierY - tierH * 0.18);
        ctx.quadraticCurveTo(
          tx - tierW * 0.15,
          tierY - tierH * 0.05,
          tx,
          tierY - tierH * 0.22
        );
        ctx.quadraticCurveTo(
          tx + tierW * 0.18,
          tierY - tierH * 0.06,
          tx + tierW * 0.44,
          tierY - tierH * 0.18
        );
        ctx.lineTo(tx, tierY - tierH);
        ctx.closePath();
        ctx.fill();
      }
    };

    let tick = 0;

    const drawFrame = () => {
      tick += reducedMotion ? 0 : 0.022;
      const state = interactionRef.current;

      // Smoothly interpolate rotation & Ferris wheel spin
      state.yaw += (state.targetYaw - state.yaw) * 0.08;
      state.pitch += (state.targetPitch - state.pitch) * 0.08;
      if (!state.isDragging && !reducedMotion) {
        state.targetYaw = Math.sin(tick * 0.35) * 0.14;
      }
      if (!reducedMotion) {
        state.wheelAngle += 0.006 + state.turbulence * 0.008;
      }
      state.turbulence = Math.max(0.08, state.turbulence * 0.975);
      state.castleGlowBoost = Math.max(0, state.castleGlowBoost * 0.96);

      ctx.save();
      ctx.scale(dpr, dpr);
      ctx.clearRect(0, 0, logicalSize, logicalSize);

      // 1. Background bokeh snowflakes & ambient sapphire halo around the globe
      const outerGlow = ctx.createRadialGradient(
        cx,
        cy,
        radius * 0.45,
        cx,
        cy,
        radius * 1.28
      );
      if (countdown.isChristmasMorning || globeTheme === 'solstice') {
        outerGlow.addColorStop(0, 'rgba(253, 224, 71, 0.25)');
        outerGlow.addColorStop(0.55, 'rgba(56, 189, 248, 0.22)');
        outerGlow.addColorStop(1, 'rgba(3, 9, 23, 0)');
      } else if (globeTheme === 'aurora') {
        outerGlow.addColorStop(0, 'rgba(167, 139, 250, 0.26)');
        outerGlow.addColorStop(0.55, 'rgba(14, 165, 233, 0.22)');
        outerGlow.addColorStop(1, 'rgba(3, 9, 23, 0)');
      } else {
        outerGlow.addColorStop(0, 'rgba(56, 189, 248, 0.28)');
        outerGlow.addColorStop(0.6, 'rgba(14, 116, 144, 0.18)');
        outerGlow.addColorStop(1, 'rgba(3, 9, 23, 0)');
      }
      ctx.fillStyle = outerGlow;
      ctx.beginPath();
      ctx.arc(cx, cy, radius * 1.28, 0, Math.PI * 2);
      ctx.fill();

      // 2. CLIP INSIDE CRYSTAL SPHERE DOME
      ctx.save();
      ctx.beginPath();
      ctx.arc(cx, cy, radius, 0, Math.PI * 2);
      ctx.clip();

      // Deep sapphire-to-cyan inner sky matching the uploaded snow globe image
      const skyGrad = ctx.createRadialGradient(
        cx,
        cy - 10,
        15,
        cx,
        cy,
        radius
      );
      if (globeTheme === 'aurora') {
        skyGrad.addColorStop(0, '#1e3a8a');
        skyGrad.addColorStop(0.55, '#0f295c');
        skyGrad.addColorStop(1, '#041028');
      } else if (countdown.isChristmasMorning || globeTheme === 'solstice') {
        skyGrad.addColorStop(0, '#0c4a6e');
        skyGrad.addColorStop(0.55, '#082f49');
        skyGrad.addColorStop(1, '#041326');
      } else {
        skyGrad.addColorStop(0, '#0ea5e9');
        skyGrad.addColorStop(0.38, '#0369a1');
        skyGrad.addColorStop(0.75, '#082f49');
        skyGrad.addColorStop(1, '#031226');
      }
      ctx.fillStyle = skyGrad;
      ctx.fillRect(cx - radius, cy - radius, radius * 2, radius * 2);

      const parallaxX = Math.sin(state.yaw) * 18;
      const parallaxY = state.pitch * 14;
      const horizonY = cy + 52 + parallaxY * 0.35;

      // 3. ILLUMINATED WINTER WONDERLAND FERRIS WHEEL (Behind left-center of village)
      const wheelCx = cx - 22 + parallaxX * 0.65;
      const wheelCy = horizonY - 76;
      const wheelR = 66;

      // Ferris wheel warm ambient halo
      const wheelGlow = ctx.createRadialGradient(
        wheelCx,
        wheelCy,
        4,
        wheelCx,
        wheelCy,
        wheelR * 1.25
      );
      wheelGlow.addColorStop(0, 'rgba(254, 240, 138, 0.42)');
      wheelGlow.addColorStop(0.5, 'rgba(186, 230, 253, 0.18)');
      wheelGlow.addColorStop(1, 'rgba(14, 165, 233, 0)');
      ctx.fillStyle = wheelGlow;
      ctx.beginPath();
      ctx.arc(wheelCx, wheelCy, wheelR * 1.25, 0, Math.PI * 2);
      ctx.fill();

      // Ferris wheel A-frame support struts
      ctx.strokeStyle = 'rgba(224, 242, 254, 0.72)';
      ctx.lineWidth = 2.2;
      ctx.beginPath();
      ctx.moveTo(wheelCx - 28, horizonY + 4);
      ctx.lineTo(wheelCx, wheelCy);
      ctx.lineTo(wheelCx + 28, horizonY + 4);
      ctx.stroke();

      // Concentric structural rings of Ferris wheel
      ctx.strokeStyle = 'rgba(240, 249, 255, 0.88)';
      ctx.lineWidth = 1.8;
      ctx.beginPath();
      ctx.arc(wheelCx, wheelCy, wheelR, 0, Math.PI * 2);
      ctx.stroke();

      ctx.strokeStyle = 'rgba(186, 230, 253, 0.65)';
      ctx.lineWidth = 1.1;
      ctx.beginPath();
      ctx.arc(wheelCx, wheelCy, wheelR * 0.76, 0, Math.PI * 2);
      ctx.stroke();
      ctx.beginPath();
      ctx.arc(wheelCx, wheelCy, wheelR * 0.44, 0, Math.PI * 2);
      ctx.stroke();

      // 16 Rotating radial spokes and glowing golden gondolas
      const numSpokes = 16;
      for (let i = 0; i < numSpokes; i++) {
        const angle = state.wheelAngle + (i * Math.PI * 2) / numSpokes;
        const gx = wheelCx + Math.cos(angle) * wheelR;
        const gy = wheelCy + Math.sin(angle) * wheelR;

        // Spoke line
        ctx.strokeStyle = 'rgba(224, 242, 254, 0.75)';
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.moveTo(wheelCx, wheelCy);
        ctx.lineTo(gx, gy);
        ctx.stroke();

        // Warm golden glowing gondola lantern on outer rim
        const gondolaGlow = ctx.createRadialGradient(gx, gy, 0.5, gx, gy, 7.5);
        gondolaGlow.addColorStop(0, '#ffffff');
        gondolaGlow.addColorStop(0.4, '#fde047');
        gondolaGlow.addColorStop(0.8, 'rgba(245, 158, 11, 0.65)');
        gondolaGlow.addColorStop(1, 'rgba(245, 158, 11, 0)');
        ctx.fillStyle = gondolaGlow;
        ctx.beginPath();
        ctx.arc(gx, gy, 7.5, 0, Math.PI * 2);
        ctx.fill();

        ctx.fillStyle = '#fef08a';
        ctx.beginPath();
        ctx.arc(gx, gy, 2.7, 0, Math.PI * 2);
        ctx.fill();
      }

      // Glowing central sunburst hub of the Ferris wheel
      const hubGlow = ctx.createRadialGradient(
        wheelCx,
        wheelCy,
        1,
        wheelCx,
        wheelCy,
        14
      );
      hubGlow.addColorStop(0, '#ffffff');
      hubGlow.addColorStop(0.45, '#fde68a');
      hubGlow.addColorStop(1, 'rgba(251, 191, 36, 0)');
      ctx.fillStyle = hubGlow;
      ctx.beginPath();
      ctx.arc(wheelCx, wheelCy, 14, 0, Math.PI * 2);
      ctx.fill();

      // 4. BACKGROUND SNOW-COVERED EVERGREENS (Flanking left & right)
      drawSnowyEvergreen(cx - 118 + parallaxX * 0.8, horizonY + 4, 44, 74, 4);
      drawSnowyEvergreen(cx - 92 + parallaxX * 0.85, horizonY + 2, 52, 92, 5);
      drawSnowyEvergreen(cx + 88 + parallaxX * 0.85, horizonY + 2, 50, 90, 5);
      drawSnowyEvergreen(cx + 116 + parallaxX * 0.8, horizonY + 6, 46, 78, 4);

      // 5. WARM-LIT ALPINE PALACE TOWERS & WINTER VILLAGE COTTAGES
      const villageX = cx + parallaxX;
      const warmPulse =
        0.85 +
        0.15 * Math.sin(tick * 2.6) +
        state.castleGlowBoost * 0.25 +
        (countdown.isChristmasMorning ? 0.2 : 0);

      // Helper to draw a cream/ice-stone tower or cottage with blue snow roof & warm glowing amber windows
      const drawPalaceBuilding = (opts: {
        dx: number;
        w: number;
        h: number;
        roofH: number;
        roofStyle: 'spire' | 'gable' | 'dome';
        windows: { rx: number; ry: number; rw: number; rh: number; arch?: boolean }[];
      }) => {
        const bx = villageX + opts.dx;
        const topY = horizonY - opts.h;

        // Warm interior light spill around building base
        const wallGrad = ctx.createLinearGradient(bx - opts.w / 2, topY, bx + opts.w / 2, horizonY);
        wallGrad.addColorStop(0, '#f8fafc');
        wallGrad.addColorStop(0.45, '#fed7aa');
        wallGrad.addColorStop(1, '#fb923c');

        ctx.fillStyle = wallGrad;
        ctx.strokeStyle = 'rgba(224, 242, 254, 0.85)';
        ctx.lineWidth = 1.1;
        ctx.beginPath();
        ctx.roundRect(bx - opts.w / 2, topY, opts.w, opts.h, [2, 2, 0, 0]);
        ctx.fill();
        ctx.stroke();

        // Ice-blue & snow-capped roof
        const roofGrad = ctx.createLinearGradient(
          bx,
          topY - opts.roofH,
          bx,
          topY
        );
        roofGrad.addColorStop(0, '#ffffff');
        roofGrad.addColorStop(0.55, '#38bdf8');
        roofGrad.addColorStop(1, '#0369a1');
        ctx.fillStyle = roofGrad;
        ctx.strokeStyle = '#e0f2fe';
        ctx.lineWidth = 1.2;

        ctx.beginPath();
        if (opts.roofStyle === 'dome') {
          ctx.moveTo(bx - opts.w / 2 - 3, topY);
          ctx.quadraticCurveTo(
            bx,
            topY - opts.roofH * 1.4,
            bx + opts.w / 2 + 3,
            topY
          );
          ctx.closePath();
        } else {
          ctx.moveTo(bx - opts.w / 2 - 4, topY);
          ctx.lineTo(bx, topY - opts.roofH);
          ctx.lineTo(bx + opts.w / 2 + 4, topY);
          ctx.closePath();
        }
        ctx.fill();
        ctx.stroke();

        // Spire finial on tall towers
        if (opts.roofStyle === 'spire') {
          ctx.strokeStyle = '#fef08a';
          ctx.lineWidth = 1.4;
          ctx.beginPath();
          ctx.moveTo(bx, topY - opts.roofH);
          ctx.lineTo(bx, topY - opts.roofH - 10);
          ctx.stroke();

          ctx.fillStyle = '#fef08a';
          ctx.beginPath();
          ctx.arc(bx, topY - opts.roofH - 10, 2.2, 0, Math.PI * 2);
          ctx.fill();
        }

        // Warm glowing golden-orange windows & grand arches
        opts.windows.forEach((w) => {
          const wx = bx + w.rx - w.rw / 2;
          const wy = horizonY + w.ry;

          // Window outer warm halo
          const winHalo = ctx.createRadialGradient(
            bx + w.rx,
            wy + w.rh / 2,
            1,
            bx + w.rx,
            wy + w.rh / 2,
            w.rw * 1.3
          );
          winHalo.addColorStop(0, `rgba(254, 240, 138, ${Math.min(1, 0.75 * warmPulse)})`);
          winHalo.addColorStop(0.5, 'rgba(249, 115, 22, 0.35)');
          winHalo.addColorStop(1, 'rgba(249, 115, 22, 0)');
          ctx.fillStyle = winHalo;
          ctx.beginPath();
          ctx.arc(bx + w.rx, wy + w.rh / 2, w.rw * 1.3, 0, Math.PI * 2);
          ctx.fill();

          ctx.fillStyle = '#fef08a';
          ctx.strokeStyle = '#d97706';
          ctx.lineWidth = 0.9;
          ctx.beginPath();
          ctx.roundRect(
            wx,
            wy,
            w.rw,
            w.rh,
            w.arch ? [w.rw / 2, w.rw / 2, 1, 1] : 1.5
          );
          ctx.fill();
          ctx.stroke();
        });
      };

      // Left turret tower
      drawPalaceBuilding({
        dx: -24,
        w: 22,
        h: 48,
        roofH: 22,
        roofStyle: 'spire',
        windows: [
          { rx: 0, ry: -36, rw: 6, rh: 12, arch: true },
          { rx: 0, ry: -18, rw: 6, rh: 11, arch: true },
        ],
      });

      // Center-right tall clock/citadel tower
      drawPalaceBuilding({
        dx: 25,
        w: 26,
        h: 78,
        roofH: 26,
        roofStyle: 'spire',
        windows: [
          { rx: 0, ry: -64, rw: 7, rh: 14, arch: true },
          { rx: -5, ry: -42, rw: 4.5, rh: 11, arch: true },
          { rx: 5, ry: -42, rw: 4.5, rh: 11, arch: true },
        ],
      });

      // Far-right tall palace bell tower (matching right side of reference snow globe)
      drawPalaceBuilding({
        dx: 56,
        w: 32,
        h: 96,
        roofH: 28,
        roofStyle: 'spire',
        windows: [
          { rx: -5, ry: -78, rw: 5, rh: 15, arch: true },
          { rx: 5, ry: -78, rw: 5, rh: 15, arch: true },
          { rx: 0, ry: -52, rw: 10, rh: 16, arch: true },
          { rx: 0, ry: -26, rw: 13, rh: 24, arch: true }, // Grand illuminated cathedral arch
        ],
      });

      // Center domed hall
      drawPalaceBuilding({
        dx: 4,
        w: 36,
        h: 46,
        roofH: 15,
        roofStyle: 'dome',
        windows: [
          { rx: -8, ry: -34, rw: 6, rh: 11, arch: true },
          { rx: 8, ry: -34, rw: 6, rh: 11, arch: true },
          { rx: 0, ry: -17, rw: 9, rh: 15, arch: true },
        ],
      });

      // Foreground cozy village cottages on left & center
      drawPalaceBuilding({
        dx: -68,
        w: 24,
        h: 22,
        roofH: 11,
        roofStyle: 'gable',
        windows: [
          { rx: -5, ry: -14, rw: 5, rh: 7 },
          { rx: 5, ry: -14, rw: 5, rh: 7 },
        ],
      });

      drawPalaceBuilding({
        dx: -44,
        w: 30,
        h: 26,
        roofH: 13,
        roofStyle: 'gable',
        windows: [
          { rx: -7, ry: -16, rw: 5.5, rh: 8 },
          { rx: 1, ry: -16, rw: 5.5, rh: 8 },
          { rx: 9, ry: -14, rw: 5, rh: 11, arch: true },
        ],
      });

      drawPalaceBuilding({
        dx: 22,
        w: 28,
        h: 28,
        roofH: 13,
        roofStyle: 'gable',
        windows: [
          { rx: -6, ry: -18, rw: 5.5, rh: 9 },
          { rx: 6, ry: -18, rw: 5.5, rh: 9 },
        ],
      });

      // Foreground miniature snowy pine tree between cottages and cathedral tower
      drawSnowyEvergreen(villageX + 38, horizonY + 6, 22, 38, 3);
      drawSnowyEvergreen(villageX - 16, horizonY + 7, 16, 26, 3);

      // 6. LUMINOUS CYAN-BLUE SWIRLING SNOWDRIFT BOWL AT BOTTOM OF GLOBE
      // Deep cyan-blue translucent snow base filling lower hemisphere
      const lowerBowlGrad = ctx.createLinearGradient(
        cx,
        horizonY - 4,
        cx,
        cy + radius
      );
      lowerBowlGrad.addColorStop(0, '#ffffff');
      lowerBowlGrad.addColorStop(0.18, '#bae6fd');
      lowerBowlGrad.addColorStop(0.45, '#0ea5e9');
      lowerBowlGrad.addColorStop(0.82, '#0369a1');
      lowerBowlGrad.addColorStop(1, '#082f49');

      ctx.fillStyle = lowerBowlGrad;
      ctx.beginPath();
      ctx.moveTo(cx - radius, horizonY + 4);
      ctx.quadraticCurveTo(cx - radius * 0.45, horizonY - 10, cx, horizonY + 2);
      ctx.quadraticCurveTo(
        cx + radius * 0.45,
        horizonY + 12,
        cx + radius,
        horizonY - 2
      );
      ctx.lineTo(cx + radius, cy + radius);
      ctx.lineTo(cx - radius, cy + radius);
      ctx.closePath();
      ctx.fill();

      // Warm golden reflection cast by the village windows onto the fresh snowdrift
      const snowReflection = ctx.createRadialGradient(
        villageX + 10,
        horizonY + 12,
        4,
        villageX + 10,
        horizonY + 12,
        85
      );
      snowReflection.addColorStop(0, 'rgba(253, 224, 71, 0.35)');
      snowReflection.addColorStop(0.5, 'rgba(251, 146, 60, 0.14)');
      snowReflection.addColorStop(1, 'rgba(14, 165, 233, 0)');
      ctx.fillStyle = snowReflection;
      ctx.beginPath();
      ctx.ellipse(villageX + 10, horizonY + 14, 90, 22, 0, 0, Math.PI * 2);
      ctx.fill();

      // 7. UPDATE & RENDER 3D SNOWFLAKES & STAR CRYSTALS
      const cosY = Math.cos(state.yaw);
      const sinY = Math.sin(state.yaw);

      for (const f of flakes) {
        if (!reducedMotion) {
          f.phase += 0.032;
          const swirlForce = state.turbulence * 0.015;
          f.vx +=
            Math.cos(f.phase + f.y * 4) * 0.00025 - f.z * swirlForce * 0.5;
          f.vz +=
            Math.sin(f.phase + f.x * 4) * 0.00025 + f.x * swirlForce * 0.5;
          f.vy += 0.00008;

          if (state.pointerActive) {
            const dx = f.x - state.pointerNormX;
            const dy = f.y - state.pointerNormY;
            const distSq = dx * dx + dy * dy;
            if (distSq < 0.3) {
              const push = (0.3 - distSq) * 0.048;
              f.vx += (-dy * 0.8 + dx * 0.3) * push;
              f.vy -= Math.abs(push) * 0.92;
              f.vz += (Math.random() - 0.5) * push;
            }
          }

          f.vx *= 0.985;
          f.vz *= 0.985;
          f.vy = Math.min(0.009, Math.max(-0.012, f.vy));

          f.x += f.vx;
          f.y += f.vy;
          f.z += f.vz;

          const rSq = f.x * f.x + f.y * f.y + f.z * f.z;
          if (f.y > 0.65 || rSq > 0.94) {
            const angle = Math.random() * Math.PI * 2;
            const spread = Math.random() * 0.75;
            f.x = Math.cos(angle) * spread;
            f.z = Math.sin(angle) * spread;
            f.y = -Math.sqrt(Math.max(0.05, 0.88 - f.x * f.x - f.z * f.z));
            f.vy = Math.random() * 0.004 + 0.002;
          }
        }

        const rx = f.x * cosY - f.z * sinY;
        const rz = f.x * sinY + f.z * cosY;
        const ry = f.y;

        const depthScale = 0.65 + (rz + 1) * 0.35;
        const screenX = cx + rx * radius * 0.92;
        const screenY = cy + ry * radius * 0.92;

        if (f.isStarFlake && screenY < horizonY + 12) {
          drawStarSnowflake(
            screenX,
            screenY,
            f.size * depthScale * 1.45,
            f.alpha,
            f.phase * 0.5
          );
        } else {
          ctx.fillStyle = `rgba(255, 255, 255, ${f.alpha})`;
          ctx.beginPath();
          ctx.arc(screenX, screenY, f.size * depthScale, 0, Math.PI * 2);
          ctx.fill();
        }
      }

      // 8. THICK CRESCENT GLASS REFRACTION HIGHLIGHTS (Matching Reference Globe)
      const rimGrad = ctx.createRadialGradient(
        cx - radius * 0.28,
        cy - radius * 0.28,
        radius * 0.2,
        cx,
        cy,
        radius
      );
      rimGrad.addColorStop(0, 'rgba(255, 255, 255, 0.06)');
      rimGrad.addColorStop(0.76, 'rgba(56, 189, 248, 0.04)');
      rimGrad.addColorStop(0.93, 'rgba(186, 230, 253, 0.28)');
      rimGrad.addColorStop(1, 'rgba(255, 255, 255, 0.65)');
      ctx.fillStyle = rimGrad;
      ctx.beginPath();
      ctx.arc(cx, cy, radius, 0, Math.PI * 2);
      ctx.fill();

      // Prominent upper-left curved glass reflection crescent
      const leftCrescentGrad = ctx.createLinearGradient(
        cx - radius,
        cy - radius * 0.7,
        cx - radius * 0.2,
        cy + radius * 0.2
      );
      leftCrescentGrad.addColorStop(0, 'rgba(255, 255, 255, 0.52)');
      leftCrescentGrad.addColorStop(0.6, 'rgba(186, 230, 253, 0.22)');
      leftCrescentGrad.addColorStop(1, 'rgba(186, 230, 253, 0)');
      ctx.fillStyle = leftCrescentGrad;
      ctx.beginPath();
      ctx.arc(cx, cy, radius - 6, Math.PI * 0.92, Math.PI * 1.46);
      ctx.quadraticCurveTo(
        cx - radius * 0.52,
        cy - radius * 0.35,
        cx - Math.cos(Math.PI * 0.08) * (radius - 6),
        cy + Math.sin(Math.PI * 0.08) * (radius - 6)
      );
      ctx.closePath();
      ctx.fill();

      // Right-side cyan glass refraction caustics
      const rightCausticGrad = ctx.createLinearGradient(
        cx + radius * 0.4,
        cy - radius * 0.5,
        cx + radius,
        cy + radius * 0.2
      );
      rightCausticGrad.addColorStop(0, 'rgba(125, 211, 252, 0)');
      rightCausticGrad.addColorStop(0.5, 'rgba(125, 211, 252, 0.32)');
      rightCausticGrad.addColorStop(1, 'rgba(255, 255, 255, 0.42)');
      ctx.fillStyle = rightCausticGrad;
      ctx.beginPath();
      ctx.arc(cx, cy, radius - 7, -Math.PI * 0.32, Math.PI * 0.14);
      ctx.quadraticCurveTo(
        cx + radius * 0.58,
        cy - radius * 0.15,
        cx + Math.cos(-Math.PI * 0.32) * (radius - 7),
        cy + Math.sin(-Math.PI * 0.32) * (radius - 7)
      );
      ctx.closePath();
      ctx.fill();

      ctx.restore(); // End sphere clip

      // Outer crystal glass sphere edge ring
      ctx.strokeStyle = 'rgba(224, 242, 254, 0.72)';
      ctx.lineWidth = 2.2;
      ctx.beginPath();
      ctx.arc(cx, cy, radius, 0, Math.PI * 2);
      ctx.stroke();

      // 9. ORNATE MIDNIGHT-BLUE PORCELAIN & GOLD FILIGREE PEDESTAL BASE IN SNOWBANKS
      const neckY = cy + radius - 14;
      const baseBottomY = neckY + 78;

      // Background snowbank hills behind the pedestal
      const backSnowGrad = ctx.createLinearGradient(
        0,
        neckY + 25,
        0,
        logicalSize
      );
      backSnowGrad.addColorStop(0, 'rgba(186, 230, 253, 0.35)');
      backSnowGrad.addColorStop(1, 'rgba(15, 23, 42, 0)');
      ctx.fillStyle = backSnowGrad;
      ctx.beginPath();
      ctx.ellipse(cx - 130, baseBottomY - 6, 95, 24, 0, 0, Math.PI * 2);
      ctx.ellipse(cx + 130, baseBottomY - 4, 95, 24, 0, 0, Math.PI * 2);
      ctx.fill();

      // Flared midnight-navy porcelain pedestal body
      const pedestalGrad = ctx.createLinearGradient(
        cx - 150,
        neckY,
        cx + 150,
        baseBottomY
      );
      pedestalGrad.addColorStop(0, '#040b1c');
      pedestalGrad.addColorStop(0.22, '#0c2147');
      pedestalGrad.addColorStop(0.38, '#1d4ed8');
      pedestalGrad.addColorStop(0.5, '#0a1936');
      pedestalGrad.addColorStop(0.78, '#0c2147');
      pedestalGrad.addColorStop(1, '#020617');

      ctx.fillStyle = pedestalGrad;
      ctx.strokeStyle = 'rgba(251, 191, 36, 0.75)';
      ctx.lineWidth = 1.6;

      ctx.beginPath();
      ctx.moveTo(cx - 118, neckY);
      ctx.quadraticCurveTo(cx, neckY + 12, cx + 118, neckY);
      ctx.bezierCurveTo(
        cx + 122,
        neckY + 24,
        cx + 148,
        baseBottomY - 18,
        cx + 154,
        baseBottomY
      );
      ctx.quadraticCurveTo(cx, baseBottomY + 16, cx - 154, baseBottomY);
      ctx.bezierCurveTo(
        cx - 148,
        baseBottomY - 18,
        cx - 122,
        neckY + 24,
        cx - 118,
        neckY
      );
      ctx.closePath();
      ctx.fill();
      ctx.stroke();

      // Upper collar lip on pedestal
      ctx.strokeStyle = 'rgba(147, 197, 253, 0.35)';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(cx - 119, neckY + 4);
      ctx.quadraticCurveTo(cx, neckY + 16, cx + 119, neckY + 4);
      ctx.stroke();

      // Beaded gold trim along the top collar of pedestal (matching reference image)
      ctx.fillStyle = '#fbbf24';
      const topBeadCount = 34;
      for (let b = 0; b <= topBeadCount; b++) {
        const t = b / topBeadCount;
        const bx = cx - 114 + t * 228;
        const curveOffset = Math.sin(t * Math.PI) * 7;
        const by = neckY + 12 + curveOffset;
        ctx.beginPath();
        ctx.arc(bx, by, 1.7, 0, Math.PI * 2);
        ctx.fill();
      }

      // Beaded gold trim along the bottom rim of pedestal
      const bottomBeadCount = 42;
      for (let b = 0; b <= bottomBeadCount; b++) {
        const t = b / bottomBeadCount;
        const bx = cx - 146 + t * 292;
        const curveOffset = Math.sin(t * Math.PI) * 9;
        const by = baseBottomY - 3 + curveOffset;
        ctx.beginPath();
        ctx.arc(bx, by, 1.9, 0, Math.PI * 2);
        ctx.fill();
      }

      // Intricate sweeping champagne-gold botanical vine & leaf filigree across the pedestal
      const drawGoldFiligreeBranch = (direction: -1 | 1) => {
        ctx.save();
        ctx.translate(cx, neckY + 44);
        ctx.scale(direction, 1);

        ctx.strokeStyle = '#fbbf24';
        ctx.lineWidth = 1.6;
        ctx.lineCap = 'round';

        // Main sweeping golden vine
        ctx.beginPath();
        ctx.moveTo(14, 6);
        ctx.bezierCurveTo(42, -12, 78, 16, 122, -4);
        ctx.stroke();

        // Secondary upper scroll branch
        ctx.beginPath();
        ctx.moveTo(48, -2);
        ctx.quadraticCurveTo(72, -18, 98, -14);
        ctx.stroke();

        // Golden botanical leaves along the vine
        ctx.fillStyle = '#fde68a';
        const leaves = [
          { x: 28, y: -2, angle: -0.45, rx: 6, ry: 2.3 },
          { x: 44, y: 5, angle: 0.4, rx: 6.5, ry: 2.4 },
          { x: 64, y: -11, angle: -0.5, rx: 6, ry: 2.2 },
          { x: 76, y: 4, angle: 0.35, rx: 7, ry: 2.5 },
          { x: 94, y: -15, angle: -0.3, rx: 5.5, ry: 2.1 },
          { x: 105, y: 1, angle: 0.25, rx: 6.5, ry: 2.3 },
          { x: 120, y: -6, angle: -0.4, rx: 5.5, ry: 2.1 },
        ];
        leaves.forEach((lf) => {
          ctx.save();
          ctx.translate(lf.x, lf.y);
          ctx.rotate(lf.angle);
          ctx.beginPath();
          ctx.ellipse(0, 0, lf.rx, lf.ry, 0, 0, Math.PI * 2);
          ctx.fill();
          ctx.restore();
        });

        ctx.restore();
      };

      drawGoldFiligreeBranch(-1);
      drawGoldFiligreeBranch(1);

      // Center golden crest flourish on pedestal
      ctx.fillStyle = '#fde047';
      ctx.beginPath();
      ctx.arc(cx, neckY + 46, 3.2, 0, Math.PI * 2);
      ctx.fill();

      // Fluffy foreground snowdrifts nestling the bottom of the pedestal
      const snowdriftGrad = ctx.createLinearGradient(
        cx,
        baseBottomY - 4,
        cx,
        baseBottomY + 24
      );
      snowdriftGrad.addColorStop(0, '#ffffff');
      snowdriftGrad.addColorStop(0.55, '#bae6fd');
      snowdriftGrad.addColorStop(1, 'rgba(12, 74, 110, 0)');
      ctx.fillStyle = snowdriftGrad;
      ctx.beginPath();
      ctx.ellipse(cx - 115, baseBottomY + 7, 72, 11, 0, 0, Math.PI * 2);
      ctx.ellipse(cx + 115, baseBottomY + 7, 72, 11, 0, 0, Math.PI * 2);
      ctx.ellipse(cx, baseBottomY + 11, 130, 9, 0, 0, Math.PI * 2);
      ctx.fill();

      ctx.restore();

      if (!reducedMotion) {
        animId = window.requestAnimationFrame(drawFrame);
      }
    };

    drawFrame();

    return () => {
      if (animId) window.cancelAnimationFrame(animId);
    };
  }, [
    countdown.isChristmasMorning,
    countdown.targetYear,
    globeTheme,
    reducedMotion,
  ]);

  const handlePointerDown = (e: React.PointerEvent<HTMLCanvasElement>) => {
    interactionRef.current.isDragging = true;
    interactionRef.current.lastPointerX = e.clientX;
    interactionRef.current.lastPointerY = e.clientY;
    interactionRef.current.turbulence = Math.min(
      2.7,
      interactionRef.current.turbulence + 0.9
    );
    interactionRef.current.castleGlowBoost = 0.95;
    setSwirlCount((c) => c + 1);
  };

  const handlePointerMove = (e: React.PointerEvent<HTMLCanvasElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const normX = ((e.clientX - rect.left) / rect.width) * 2 - 1;
    const normY = ((e.clientY - rect.top) / rect.height) * 2 - 1;
    interactionRef.current.pointerNormX = normX;
    interactionRef.current.pointerNormY = normY;
    interactionRef.current.pointerActive = true;

    if (interactionRef.current.isDragging) {
      const dx = e.clientX - interactionRef.current.lastPointerX;
      const dy = e.clientY - interactionRef.current.lastPointerY;
      interactionRef.current.targetYaw = Math.max(
        -0.85,
        Math.min(0.85, interactionRef.current.targetYaw + dx * 0.008)
      );
      interactionRef.current.targetPitch = Math.max(
        -0.35,
        Math.min(0.35, interactionRef.current.targetPitch + dy * 0.005)
      );
      interactionRef.current.lastPointerX = e.clientX;
      interactionRef.current.lastPointerY = e.clientY;
      interactionRef.current.turbulence = Math.min(
        2.7,
        interactionRef.current.turbulence + 0.15
      );
    } else {
      interactionRef.current.turbulence = Math.min(
        1.5,
        interactionRef.current.turbulence + 0.04
      );
    }
  };

  const handlePointerUpOrLeave = () => {
    interactionRef.current.isDragging = false;
    interactionRef.current.pointerActive = false;
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLCanvasElement>) => {
    if (e.key === 'ArrowLeft') {
      e.preventDefault();
      interactionRef.current.targetYaw = Math.max(
        -0.85,
        interactionRef.current.targetYaw - 0.15
      );
      interactionRef.current.turbulence = 1.4;
    } else if (e.key === 'ArrowRight') {
      e.preventDefault();
      interactionRef.current.targetYaw = Math.min(
        0.85,
        interactionRef.current.targetYaw + 0.15
      );
      interactionRef.current.turbulence = 1.4;
    } else if (e.key === ' ' || e.key === 'Enter') {
      e.preventDefault();
      triggerShakeGlobe();
    }
  };

  return (
    <div
      data-testid="enchanted-snow-globe"
      className="relative mx-auto flex max-w-3xl flex-col items-center"
    >
      {/* Interactive 3D Snow Globe Canvas */}
      <div className="relative flex flex-col items-center">
        <canvas
          ref={canvasRef}
          role="img"
          tabIndex={0}
          aria-label="Interactive 3D Enchanted Christmas Snow Globe featuring a rotating golden-lit winter Ferris wheel, warm-lit alpine palace towers and cottages, snow-covered evergreens, swirling star snowflakes, and an ornate midnight-blue and gold filigree pedestal."
          onPointerDown={handlePointerDown}
          onPointerMove={handlePointerMove}
          onPointerUp={handlePointerUpOrLeave}
          onPointerLeave={handlePointerUpOrLeave}
          onKeyDown={handleKeyDown}
          className="h-[290px] w-[290px] cursor-grab rounded-full touch-none select-none focus:outline-none focus:ring-2 focus:ring-sky-300/50 active:cursor-grabbing sm:h-[380px] sm:w-[380px]"
        />

        {/* Interactive Globe Controls Toolbar */}
        <div className="mt-1 flex flex-wrap items-center justify-center gap-2">
          <button
            type="button"
            onClick={triggerShakeGlobe}
            className="inline-flex items-center gap-1.5 rounded-xl bg-sky-300 px-3.5 py-2 text-xs font-semibold text-slate-950 shadow-sm transition hover:bg-sky-200 whitespace-nowrap shrink-0"
          >
            <Wind className="h-3.5 w-3.5" />
            Shake Snow Globe
          </button>

          <div
            role="group"
            aria-label="Snow globe lighting theme"
            className="flex items-center gap-1 rounded-xl border border-sky-200/20 bg-slate-950/80 p-1"
          >
            {(
              [
                { id: 'twilight', label: 'Icy Twilight' },
                { id: 'aurora', label: 'Lavender Aurora' },
                { id: 'solstice', label: 'Champagne Gold' },
              ] as const
            ).map((mode) => (
              <button
                key={mode.id}
                type="button"
                onClick={() => setGlobeTheme(mode.id)}
                className={`rounded-lg px-2.5 py-1 text-xs font-medium transition whitespace-nowrap shrink-0 ${
                  globeTheme === mode.id
                    ? 'bg-sky-400/25 text-sky-100'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {mode.label}
              </button>
            ))}
          </div>

          <button
            type="button"
            onClick={() => setReducedMotion((prev) => !prev)}
            aria-pressed={reducedMotion}
            className="inline-flex items-center gap-1.5 rounded-xl border border-slate-700/80 bg-slate-950/80 px-3 py-2 text-xs font-medium text-slate-200 transition hover:border-sky-300/40 hover:text-white whitespace-nowrap shrink-0"
          >
            {reducedMotion ? (
              <>
                <Play className="h-3.5 w-3.5 text-emerald-300" />
                Resume Snow Motion
              </>
            ) : (
              <>
                <Pause className="h-3.5 w-3.5 text-amber-300" />
                Reduced Motion Mode
              </>
            )}
          </button>
        </div>

        <p className="mt-2 text-xs text-slate-300">
          Drag or move your pointer across the crystal dome to swirl the snow, spin the Winter Ferris Wheel, and rotate the Palace Village
          {swirlCount > 0 ? ` · ${swirlCount} snow swirls cast` : ''}
        </p>
      </div>
    </div>
  );
};
