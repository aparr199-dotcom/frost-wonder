# Frost & Wonder — The Magical Christmas Countdown & Family Gift Planner for macOS

**Handshake Student Technology Competition Submission**

An enchanted winter kingdom Christmas countdown, interactive 3D snow globe centerpiece, holiday milestone planner, family gift manager, zero-double-counting budget command center, and macOS desktop companion.

---

## Quick Start (Local Development on macOS)

1. **Install dependencies:**
   ```bash
   npm install
   ```

2. **Start the development server (Port 3000):**
   ```bash
   npm run dev
   ```

3. **Run the automated unit test suite (`node:test`):**
   ```bash
   npx --yes tsx --test src/utils/holidayLogic.test.ts
   ```

4. **Build for production / standalone PWA:**
   ```bash
   npm run build
   ```

---

## Signature Competition Features

1. **The Enchanted 3D Snow Globe (`src/components/EnchantedSnowGlobe.tsx`)**
   - Real-time 3D spherical projection of a glowing Ice Palace, shimmering castle windows, 3D snow-covered evergreens, and 150 depth-sorted snowflakes.
   - Interactive drag rotation, pointer vortex snow physics, **Shake Snow Globe** impulse, 3 lighting atmospheres (*Icy Twilight*, *Lavender Aurora*, *Champagne Gold*), and **Reduced Motion Mode** accessibility.

2. **Handshake Judge Demo Mode (`src/components/JudgeDemoTourOverlay.tsx`)**
   - Click **"Experience the Magic — Start Demo"** to launch a guided 60-second, 6-step interactive tour.
   - Runs in a strictly isolated fictional family sandbox (*Aria, Theo, & Elena*) so demo actions never overwrite or expose private local storage records.

3. **Christmas Countdown & Holiday Milestones (`src/components/CountdownHeroAndMilestones.tsx`)**
   - Mathematically accurate local-timezone countdown to December 25 with seasonal magic escalation (Levels 1–5) and a special Christmas Morning celebration mode.
   - Create, edit, complete, delete, and reorder custom mini countdown milestones.

4. **Family Gift Manager & Secret Santa Cloak (`src/components/FamilyGiftManager.tsx`)**
   - Individual child profiles with bespoke winter storybook avatars, wishlists, stocking stuffer tracking, and a 7-stage gift pipeline (`WISH LIST` → `PLANNED` → `PURCHASED` → `SHIPPED` → `DELIVERED` → `WRAPPED` → `READY FOR CHRISTMAS`).
   - Instant **Secret Santa Mode** cloaks gift names, prices, stores, and notes when someone walks into the room.

5. **Christmas Budget Command Center (`src/components/BudgetCommandCenter.tsx`)**
   - Zero-double-counting financial engine that cleanly separates **Confirmed Spent** from **Estimated Cost of Remaining Gifts** and tracks shared household gifts.

6. **macOS Desktop, Screen Saver & Native SwiftUI Extensions (`src/components/MacExperienceStudio.tsx` & `macos-native/`)**
   - Includes an installable standalone PWA, Full-Screen Animated Christmas Screen Saver, 4K Coordinated Lock-Screen Wallpaper PNG Exporter, and companion SwiftUI source files in `macos-native/` (`FrostWonderWidget.swift`, `FrostWonderMacApp.swift`, `FrostWonderSaverView.swift`).
